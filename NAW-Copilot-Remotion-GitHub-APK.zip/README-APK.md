# NAW STUDIO v22.2.5

Local 2D/3D motion graphics editor for Android.

- No Gemini/API key dependency.
- Local scene code editor with Scene Lock.
- Color palette, custom HSL controls and SVG gradient editor.
- Local numeric parameter editor.
- Native H.264 CRF export and ProRes MOV export.
- Direct Gallery save to `Movies/NAW STUDIO`.
- Mandatory Update Now flow using signed GitHub Release APKs.
- App id remains `com.nawmanusia.copilot` so signed updates can upgrade older NAW Copilot installs.
