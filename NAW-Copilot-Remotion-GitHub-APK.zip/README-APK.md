# NAW STUDIO v22.2.7

Local 2D/3D motion graphics editor for Android.

- No Gemini/API key dependency.
- Local scene code editor with Scene Lock.
- Color palette, custom HSL controls and SVG gradient editor.
- Local numeric parameter editor.
- Native H.264 CRF export and H.264 MOV export.
- Direct Gallery save to `Movies/NAW STUDIO`.
- Mandatory Update Now flow using signed GitHub Release APKs.
- App id remains `com.nawmanusia.copilot` so signed updates can upgrade older NAW Copilot installs.

## v22.2.11 render compatibility
Studio browser rendering now uses Remotion `hardwareAcceleration: "if-possible"` instead of requiring/preferencing a hardware encoder. This allows compatible hardware acceleration when available while permitting a software encoder fallback on Android devices that reject a 4K H.264 hardware configuration.
