# NAW Copilot Remotion — Cloud APK Build

This project is prepared to build an Android APK with GitHub Actions, without Android Studio on your own device.

## Build from GitHub

1. Create a new GitHub repository.
2. Upload all files from this ZIP to the repository.
3. Open the **Actions** tab.
4. Select **Build Android APK**.
5. Press **Run workflow** (or push to `main`, which triggers it automatically).
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the artifact named **NAW-Copilot-Remotion-APK**.
8. Extract the downloaded ZIP and install `NAW-Copilot-Remotion-debug.apk` on Android.

The app is distributed outside Google Play. The app checks the GitHub Releases feed for newer APK versions and shows an Update button when a newer release is available.

## App identity

- App name: NAW Copilot Remotion
- Current app version: 22.1.0
- Interface language: English only
- Update channel: GitHub Releases
- Android application ID: `com.nawmanusia.copilot`
- Web output directory: `dist`
