import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.nawmanusia.copilot', appName: 'NAW STUDIO', webDir: 'dist', bundledWebRuntime: false, android: { allowMixedContent: false } };
export default config;
