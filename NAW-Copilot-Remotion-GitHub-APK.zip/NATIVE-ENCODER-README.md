# Native Encoder (legacy)

This legacy experimental encoder is no longer used by NAW STUDIO v22.2.12. Studio and Resize use browser-side Remotion/Mediabunny H.264 encoding instead.
