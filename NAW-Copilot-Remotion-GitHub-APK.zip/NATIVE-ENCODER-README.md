# Native H.264 export

NAW STUDIO v22.2.7 uses Android `MediaCodec` for the final H.264 encode.

- Remotion renders each frame as a lossless PNG.
- The Android native encoder performs the only video encoding pass.
- `File Size Scale` changes the target H.264 bitrate: 1×–5×.
- The MP4 is muxed natively and saved to `Movies/NAW STUDIO` through MediaStore.
- No FFmpeg dependency and no second video re-encode.

Because the encoder is CBR-targeted, actual file size can still vary slightly with container overhead/device encoder behavior, but it is no longer dependent on the browser's H.264 bitrate cap.
