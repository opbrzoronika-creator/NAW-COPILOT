# FFmpeg renderer notice

NAW STUDIO v22.2.5 uses the maintained Android FFmpegKit full-GPL package for native H.264 CRF and ProRes rendering.

Dependency: `dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.9`

The `-gpl` variant includes GPL components such as x264. Distribution of an application containing this dependency is subject to the applicable GPL obligations. See the upstream project and license before distributing the APK beyond personal/testing use.
