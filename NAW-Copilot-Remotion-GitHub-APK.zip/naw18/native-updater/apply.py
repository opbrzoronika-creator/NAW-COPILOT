from pathlib import Path
import shutil
import re

root = Path(__file__).resolve().parents[1]
android = root / 'android'
java_dir = android / 'app/src/main/java/com/nawmanusia/copilot'
res_xml = android / 'app/src/main/res/xml'
java_dir.mkdir(parents=True, exist_ok=True)
res_xml.mkdir(parents=True, exist_ok=True)

shutil.copy2(Path(__file__).with_name('NativeUpdaterPlugin.java'), java_dir / 'NativeUpdaterPlugin.java')
shutil.copy2(Path(__file__).with_name('NativeMediaPlugin.java'), java_dir / 'NativeMediaPlugin.java')
shutil.copy2(Path(__file__).with_name('provider_paths.xml'), res_xml / 'naw_file_paths.xml')

main = java_dir / 'MainActivity.java'
text = main.read_text()
if 'import android.os.Bundle;' not in text:
    text = text.replace('package com.nawmanusia.copilot;', 'package com.nawmanusia.copilot;\n\nimport android.os.Bundle;')
registration = '''    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NativeUpdaterPlugin.class);
        registerPlugin(NativeMediaPlugin.class);
        super.onCreate(savedInstanceState);
    }'''
if 'NativeUpdaterPlugin.class' in text or 'NativeMediaPlugin.class' in text:
    text = re.sub(r'    @Override\n    public void onCreate\(Bundle savedInstanceState\) \{.*?\n    \}', registration, text, count=1, flags=re.S)
else:
    text = text.replace('public class MainActivity extends BridgeActivity {\n}', 'public class MainActivity extends BridgeActivity {\n' + registration + '\n}')
main.write_text(text)

manifest = android / 'app/src/main/AndroidManifest.xml'
text = manifest.read_text()
perm = '    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n'
perm_net = '    <uses-permission android:name="android.permission.INTERNET" />\n'
if 'android.permission.REQUEST_INSTALL_PACKAGES' not in text:
    match = re.search(r'<manifest\b[^>]*>', text)
    if not match:
        raise RuntimeError('AndroidManifest.xml: <manifest> tag not found')
    insert_at = match.end()
    text = text[:insert_at] + '\n' + perm + perm_net + text[insert_at:]
if 'android.permission.INTERNET' not in text:
    match = re.search(r'<manifest\b[^>]*>', text)
    if not match:
        raise RuntimeError('AndroidManifest.xml: <manifest> tag not found')
    insert_at = match.end()
    text = text[:insert_at] + '\n' + perm_net + text[insert_at:]

provider = '''        <provider\n            android:name="androidx.core.content.FileProvider"\n            android:authorities="${applicationId}.fileprovider"\n            android:exported="false"\n            android:grantUriPermissions="true">\n            <meta-data\n                android:name="android.support.FILE_PROVIDER_PATHS"\n                android:resource="@xml/naw_file_paths" />\n        </provider>\n'''
if 'androidx.core.content.FileProvider' not in text:
    text = text.replace('</application>', provider + '    </application>')
manifest.write_text(text)

# Replace the Android launcher icon with the same vintage camera logo used by the web UI.
assets = Path(__file__).with_name('assets')
res_root = android / 'app/src/main/res'
icon_sizes = {
    'mipmap-mdpi': '48',
    'mipmap-hdpi': '72',
    'mipmap-xhdpi': '96',
    'mipmap-xxhdpi': '144',
    'mipmap-xxxhdpi': '192',
}
for folder, size in icon_sizes.items():
    target_dir = res_root / folder
    if target_dir.exists():
        source = assets / f'ic_launcher_{size}.png'
        if source.exists():
            shutil.copy2(source, target_dir / 'ic_launcher.png')
            shutil.copy2(source, target_dir / 'ic_launcher_round.png')

# Remove adaptive-icon XMLs so Android uses the replaced density-specific camera PNGs.
for folder_name in ('mipmap-anydpi-v26', 'mipmap-anydpi'):
    folder = res_root / folder_name
    if folder.exists():
        for name in ('ic_launcher.xml', 'ic_launcher_round.xml'):
            (folder / name).unlink(missing_ok=True)

print('Native updater applied.')
