Native updater for NAW Copilot.

The GitHub Actions workflow must run:
  python native-updater/apply.py
immediately after `npx cap sync android` and before the Android Gradle build.
