package com.nawmanusia.copilot;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "NativeUpdater")
public class NativeUpdaterPlugin extends Plugin {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean downloading = false;

    @PluginMethod
    public void ping(PluginCall call) {
        JSObject data = new JSObject();
        data.put("packageName", getContext().getPackageName());
        data.put("androidVersion", Build.VERSION.RELEASE);
        data.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(data);
    }

    @PluginMethod
    public void downloadAndInstall(PluginCall call) {
        String url = call.getString("url", "");
        if (url.isEmpty()) {
            call.reject("Missing update URL");
            return;
        }
        if (downloading) {
            call.reject("An update download is already running");
            return;
        }

        downloading = true;
        call.resolve();
        sendProgress(0, "Starting secure APK download...");

        executor.execute(() -> {
            try {
                File apk = downloadApk(url);
                sendProgress(100, "STEP 4/4 — APK download complete. Preparing Android installer...");
                downloading = false;
                getActivity().runOnUiThread(() -> openInstaller(apk));
            } catch (Exception e) {
                downloading = false;
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                sendProgress(0, "Download failed: " + message);
            }
        });
    }

    private File downloadApk(String urlString) throws IOException {
        HttpURLConnection connection = null;
        File dir = new File(getContext().getCacheDir(), "updates");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create update folder");

        File apk = new File(dir, "NAW-Copilot-update.apk");
        if (apk.exists()) apk.delete();

        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("Accept", "application/vnd.android.package-archive, application/octet-stream, */*");
            connection.setRequestProperty("User-Agent", "NAW-Copilot-Updater/22.2.1");
            connection.connect();

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);

            long total = connection.getContentLengthLong();
            long downloaded = 0;
            byte[] buffer = new byte[64 * 1024];

            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream output = new FileOutputStream(apk)) {
                int read;
                int lastPercent = -1;
                while ((read = input.read(buffer)) != -1) {
                    output.write(buffer, 0, read);
                    downloaded += read;
                    if (total > 0) {
                        int percent = (int) Math.min(99, (downloaded * 100L) / total);
                        if (percent != lastPercent) {
                            lastPercent = percent;
                            sendProgress(percent, "Downloading update... " + percent + "%");
                        }
                    } else if (downloaded % (1024 * 1024) < read) {
                        sendProgress(0, "Downloading update... " + (downloaded / 1024 / 1024) + " MB");
                    }
                }
            }

            if (!apk.exists() || apk.length() < 1024) throw new IOException("Downloaded APK is invalid or empty");
            return apk;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void sendProgress(int percent, String status) {
        JSObject data = new JSObject();
        data.put("percent", percent);
        data.put("status", status);
        notifyListeners("downloadProgress", data);
    }

    private void openInstaller(File apk) {
        Context context = getContext();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                settings.setData(Uri.parse("package:" + context.getPackageName()));
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(settings);
                sendProgress(100, "Allow installs from NAW Copilot, then tap Update now again.");
            } catch (Exception e) {
                sendProgress(100, "Allow installs from this source in Android settings.");
            }
            return;
        }

        try {
            Uri uri = FileProvider.getUriForFile(
                    context,
                    context.getPackageName() + ".fileprovider",
                    apk
            );
            Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            sendProgress(100, "Could not open the Android installer: " + e.getMessage());
        }
    }

    @Override
    protected void handleOnDestroy() {
        downloading = false;
        executor.shutdownNow();
        super.handleOnDestroy();
    }
}
