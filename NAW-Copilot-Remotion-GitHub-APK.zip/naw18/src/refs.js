// Referensi gambar/video -> frame JPEG (base64) untuk Gemini. Video diambil 4 frame merata (ringan untuk HP).
export const MAX_ITEMS = 3;
const VIDEO_FRAMES = 4;

const once = (el, ev, ms) => new Promise((res, rej) => {
  const to = setTimeout(() => { cleanup(); rej(new Error('timeout')); }, ms);
  const ok = () => { cleanup(); res(); }, bad = () => { cleanup(); rej(new Error('file tidak bisa dibaca')); };
  const cleanup = () => { clearTimeout(to); el.removeEventListener(ev, ok); el.removeEventListener('error', bad); };
  el.addEventListener(ev, ok); el.addEventListener('error', bad);
});

function snap(src, w, h, max, white = true) {
  const r = Math.min(1, max / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w * r)); c.height = Math.max(1, Math.round(h * r));
  const x = c.getContext('2d');
  if (white) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
  x.drawImage(src, 0, 0, c.width, c.height);
  return c;
}
const b64 = (c, q = 0.85) => c.toDataURL('image/jpeg', q).split(',')[1];
const thumbOf = (src, w, h) => snap(src, w, h, 96, true).toDataURL('image/jpeg', 0.7);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export async function fileToRef(file) {
  const url = URL.createObjectURL(file);
  try {
    if (file.type.startsWith('video/')) {
      const v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
      await once(v, 'loadedmetadata', 12000);
      const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : 1;
      const frames = []; let thumb = '';
      for (let i = 0; i < VIDEO_FRAMES; i++) {
        v.currentTime = Math.min(Math.max(0, dur - 0.05), ((i + 0.5) / VIDEO_FRAMES) * dur);
        await once(v, 'seeked', 10000);
        const w = v.videoWidth, h = v.videoHeight;
        if (!w || !h) throw new Error('video tidak didukung');
        frames.push(b64(snap(v, w, h, 768), 0.8));
        if (!thumb) thumb = thumbOf(v, w, h);
      }
      return { id: uid(), kind: 'video', name: file.name, thumb, frames, duration: dur };
    }
    if (file.type.startsWith('image/')) {
      const img = new Image(); img.src = url;
      await once(img, 'load', 12000);
      const w = img.naturalWidth, h = img.naturalHeight;
      return { id: uid(), kind: 'image', name: file.name, thumb: thumbOf(img, w, h), frames: [b64(snap(img, w, h, 1024))] };
    }
    throw new Error('format tidak didukung');
  } finally { setTimeout(() => URL.revokeObjectURL(url), 5000); }
}
