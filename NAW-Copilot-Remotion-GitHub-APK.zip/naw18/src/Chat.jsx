import React, { useEffect, useRef } from 'react';

export default function Chat({ t, chat, input, setInput, busy, status, onSend, onApply, mode, setMode, onClear, refs, reading, onAdd, onRemoveRef }) {
  const end = useRef(null);
  const fileIn = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [chat.length, busy]);
  const chips = t('chips');
  return (
    <div className="chat">
      <div className="msgs">
        {chat.length === 0 && <div className="hello">
          <div className="bub ai">{t('chatHello')}</div>
          <div className="chips">{chips.map(([l, p]) => <button key={l} onClick={() => setInput(p)}>{l}</button>)}</div>
        </div>}
        {chat.map((m, i) => (
          <div key={i} className={'bub ' + (m.role === 'user' ? 'me' : 'ai')}>
            {m.thumbs?.length > 0 && <div className="bthumbs">{m.thumbs.map((s, k) => <img key={k} src={s} alt="" />)}</div>}
            {m.text && <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>}
            {m.code && <>
              <details><summary>{t('viewCode')} ({m.mode?.toUpperCase()})</summary><pre>{m.code}</pre></details>
              <button className="btn apply" onClick={() => onApply(m)}>{t('applyView')}</button>
            </>}
          </div>
        ))}
        {busy && <div className="bub ai"><span className="dots"><i /><i /><i /></span> <small>{status || t('thinking')}</small></div>}
        <div ref={end} />
      </div>
      <div className="composer">
        <div className="crow">
          <div className="seg mini">{['2d', '3d'].map((m) => <button key={m} className={mode === m ? 'on' : ''} onClick={() => setMode(m)}>{m.toUpperCase()}</button>)}</div>
          <button className="link" onClick={onClear}>🗑 {t('clearChat')}</button>
        </div>
        {(refs.length > 0 || reading) && <div className="refs" style={{ margin: '0 0 6px' }}>
          {refs.map((r) => <div className="rchip" key={r.id}><img src={r.thumb} alt="" />{r.kind === 'video' && <em>▶</em>}<button onClick={() => onRemoveRef(r.id)}>×</button></div>)}
          {reading && <span className="msg" style={{ margin: 0, alignSelf: 'center' }}>{t('refReading')}</span>}
        </div>}
        <div className="cin">
          <button className="plus" disabled={reading} onClick={() => fileIn.current.click()} aria-label={t('addRef')}>＋</button>
          <input ref={fileIn} type="file" accept="image/*,video/*" multiple hidden onChange={(e) => { onAdd(e.target.files); e.target.value = ''; }} />
          <textarea rows={2} value={input} onChange={(e) => setInput(e.target.value)} placeholder={t('chatPh')}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && window.innerWidth > 700) { e.preventDefault(); onSend(); } }} />
          <button className="send" disabled={busy || (!input.trim() && !refs.length)} onClick={onSend} aria-label={t('send')}>➤</button>
        </div>
      </div>
    </div>
  );
}
