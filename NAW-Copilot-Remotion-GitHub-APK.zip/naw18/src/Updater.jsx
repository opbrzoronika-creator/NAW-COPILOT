import React, { useCallback, useEffect, useState } from 'react';
import { registerPlugin } from '@capacitor/core';
import packageJson from '../package.json';

const NativeUpdater = registerPlugin('NativeUpdater', {
  web: {
    async ping() { throw new Error('Native updater plugin is not available in this build.'); },
    async downloadAndInstall() { throw new Error('Native updater plugin is not available in this build.'); },
    async addListener() { return { remove() {} }; },
  },
});
const OWNER = 'opbrzoronika-creator';
const REPO = 'NAW-COPILOT';
const CHECK_URL = `https://api.github.com/repos/${OWNER}/${REPO}/releases/latest`;
const CACHE_KEY = 'naw_update_check';
const CHECK_INTERVAL = 60 * 1000;

function versionParts(v) { return String(v || '').replace(/^v/i, '').split(/[.-]/).slice(0, 3).map((x) => Number.parseInt(x, 10) || 0); }
function isNewer(latest, current) { const a = versionParts(latest); const b = versionParts(current); for (let i = 0; i < 3; i += 1) { if (a[i] > b[i]) return true; if (a[i] < b[i]) return false; } return false; }
function saveCheck(data) { try { localStorage.setItem(CACHE_KEY, JSON.stringify({ ...data, checkedAt: Date.now() })); } catch {} }
function readCheck() { try { const raw = localStorage.getItem(CACHE_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; } }

export default function Updater() {
  const currentVersion = packageJson.version;
  const [update, setUpdate] = useState(null);
  const [checking, setChecking] = useState(false);
  const [open, setOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('');
  const [diag, setDiag] = useState('');

  const check = useCallback(async (force = false) => {
    if (checking) return;
    const cached = readCheck();
    if (!force && cached?.checkedAt && Date.now() - cached.checkedAt < CHECK_INTERVAL) { if (cached.update) setUpdate(cached.update); return; }
    setChecking(true);
    try {
      const response = await fetch(CHECK_URL, { headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store' });
      if (!response.ok) throw new Error(`GitHub HTTP ${response.status}`);
      const release = await response.json();
      if (release?.draft || release?.prerelease || !release?.tag_name) { saveCheck({ update: null }); setUpdate(null); return; }
      const apk = Array.isArray(release.assets) ? release.assets.find((asset) => String(asset?.name || '').toLowerCase().endsWith('.apk') && String(asset?.name || '').startsWith('NAW-Copilot-') && asset?.browser_download_url) : null;
      const next = isNewer(release.tag_name, currentVersion) && apk ? { version: String(release.tag_name).replace(/^v/i, ''), notes: String(release.body || '').trim(), url: apk.browser_download_url, assetName: apk.name } : null;
      saveCheck({ update: next }); setUpdate(next); if (next) setOpen(true);
    } catch (error) {
      console.warn('NAW Copilot update check failed:', error);
      saveCheck({ update: null, error: String(error?.message || error) });
    } finally { setChecking(false); }
  }, [checking, currentVersion]);

  useEffect(() => {
    check(false);
    let listener;
    (async () => {
      try { listener = await NativeUpdater.addListener('downloadProgress', (data) => { setProgress(Number(data?.percent || 0)); setStatus(String(data?.status || 'Updater event received.')); }); }
      catch (e) { console.warn('Updater listener registration failed:', e); }
    })();
    const onVisible = () => { if (document.visibilityState === 'visible') check(false); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { document.removeEventListener('visibilitychange', onVisible); listener?.remove?.(); };
  }, [check]);

  const startDownload = async () => {
    if (!update?.url || downloading) return;
    setDownloading(true); setProgress(0); setDiag('STEP 1/4 — Button click received.'); setStatus('Checking native updater connection...');
    try {
      const ping = await Promise.race([
        NativeUpdater.ping(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Native updater did not respond to PING within 5 seconds.')), 5000)),
      ]);
      setDiag(`STEP 2/4 — Native plugin connected. ${ping?.packageName ? `Package: ${ping.packageName}.` : ''}`);
      setStatus(`Native updater is active on Android ${ping?.androidVersion || ''}. Starting APK download...`);

      const nativeCall = NativeUpdater.downloadAndInstall({ url: update.url });
      await Promise.race([
        nativeCall,
        new Promise((_, reject) => setTimeout(() => reject(new Error('Native updater did not acknowledge DOWNLOAD within 5 seconds.')), 5000)),
      ]);
      setDiag('STEP 3/4 — APK download started inside NAW Copilot.');
      setStatus('Downloading update APK. Keep NAW Copilot open...');
    } catch (error) {
      const message = String(error?.message || error || 'Unknown error');
      console.warn('Native updater diagnostic failed:', error);
      setDiag('FAILED — Native updater diagnostic stopped.');
      setStatus(message);
      setDownloading(false);
    }
  };

  if (!open || !update) return null;
  return (
    <div role="dialog" aria-modal="true" aria-label="NAW Copilot update" onClick={() => !downloading && setOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 99999, display: 'grid', placeItems: 'center', padding: 20, background: 'rgba(0,0,0,.58)', backdropFilter: 'blur(5px)' }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: 'min(440px, 100%)', borderRadius: 22, padding: 22, background: 'var(--card, #171717)', color: 'var(--text, #fff)', border: '1px solid rgba(255,255,255,.12)', boxShadow: '0 24px 70px rgba(0,0,0,.4)' }}>
        <div style={{ fontSize: 13, opacity: .65, marginBottom: 7 }}>NAW COPILOT · UPDATER DIAGNOSTIC</div>
        <h2 style={{ margin: '0 0 8px', fontSize: 22 }}>{downloading ? 'Updater diagnostic' : 'Update available'}</h2>
        {!downloading ? <>
          <p style={{ margin: '0 0 8px', lineHeight: 1.5 }}>Version <b>{update.version}</b> is ready. Your current version is <b>{currentVersion}</b>.</p>
          <p style={{ margin: '0 0 18px', lineHeight: 1.5, opacity: .72 }}>Diagnostic mode will verify the native Android updater before downloading the APK.</p>
          {update.notes && <details style={{ marginBottom: 18 }}><summary style={{ cursor: 'pointer' }}>Release notes</summary><pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: 12, opacity: .75, marginTop: 9 }}>{update.notes}</pre></details>}
          <div style={{ display: 'flex', gap: 10 }}>
            <button type="button" onClick={() => setOpen(false)} style={{ flex: 1, minHeight: 46, borderRadius: 13, border: '1px solid rgba(255,255,255,.15)', background: 'transparent', color: 'inherit', fontWeight: 700 }}>Later</button>
            <button type="button" onClick={startDownload} style={{ flex: 1.5, minHeight: 46, border: 0, borderRadius: 13, background: '#f04a2f', color: '#fff', fontWeight: 800, cursor: 'pointer', touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>Update now</button>
          </div>
          <button type="button" onClick={() => check(true)} disabled={checking} style={{ display: 'block', margin: '14px auto 0', border: 0, background: 'transparent', color: 'inherit', opacity: .55, fontSize: 12 }}>{checking ? 'Checking...' : 'Check again'}</button>
        </> : <>
          <div style={{ padding: 12, borderRadius: 14, background: 'rgba(255,255,255,.06)', marginBottom: 12, fontSize: 13, lineHeight: 1.5 }}><b>{diag}</b><br />{status}</div>
          <div style={{ height: 10, borderRadius: 999, overflow: 'hidden', background: 'rgba(255,255,255,.1)' }}><div style={{ width: `${Math.max(0, Math.min(100, progress))}%`, height: '100%', background: '#f04a2f', transition: 'width .25s ease' }} /></div>
          <div style={{ marginTop: 9, textAlign: 'right', fontSize: 12, opacity: .65 }}>{progress}%</div>
          <p style={{ margin: '14px 0 0', fontSize: 12, opacity: .58 }}>Do not close the app while the APK is downloading.</p>
        </>}
      </div>
    </div>
  );
}
