# NAW STUDIO v22.4.0 — Supabase username login

Adds a login gate using the deployed Supabase Edge Function `username-login`. The APK never contains the Supabase service-role key.

Endpoint: https://ooskrnbkrucicqctyxfk.supabase.co/functions/v1/username-login

Session and profile data are stored locally after successful login. Expired sessions return to the login screen.
