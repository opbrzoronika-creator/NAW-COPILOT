import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
Deno.serve(async (req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  try{
    const supabaseUrl=Deno.env.get('SUPABASE_URL')!;
    const anon=Deno.env.get('SUPABASE_ANON_KEY')!;
    const service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const auth=req.headers.get('Authorization')||'';
    const client=createClient(supabaseUrl,anon,{global:{headers:{Authorization:auth}}});
    const {data:{user:caller},error:ce}=await client.auth.getUser();
    if(ce||!caller) throw new Error('Unauthorized');
    const admin=createClient(supabaseUrl,service);
    const {data:profile,error:pe}=await admin.from('profiles').select('id,username,status,role').eq('id',caller.id).single();
    if(pe||!profile||profile.status!=='ACTIVE'||profile.role!=='ADMIN') throw new Error('Admin access required');
    const body=await req.json().catch(()=>({}));
    const username=String(body.username||'').trim().toLowerCase();
    if(!username) throw new Error('Username is required');
    const {data:target,error:te}=await admin.from('profiles').select('id,username,role,status').eq('username',username).single();
    if(te||!target) throw new Error('User not found');
    if(target.id===caller.id) throw new Error('You cannot delete your own admin account');
    if(target.role==='ADMIN') throw new Error('Admin accounts are protected');
    const {error:de}=await admin.auth.admin.deleteUser(target.id);
    if(de) throw de;
    return new Response(JSON.stringify({success:true,username}),{headers:{...cors,'Content-Type':'application/json'}});
  }catch(e){return new Response(JSON.stringify({success:false,error:e?.message||String(e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
});
