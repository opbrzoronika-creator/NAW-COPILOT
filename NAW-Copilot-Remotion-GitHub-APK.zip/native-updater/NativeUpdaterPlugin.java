package com.nawmanusia.copilot;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;

@CapacitorPlugin(name = "NativeUpdater")
public class NativeUpdaterPlugin extends Plugin {
    private BroadcastReceiver receiver;
    private long downloadId = -1L;

    @PluginMethod
    public void downloadAndInstall(PluginCall call) {
        String url = call.getString("url", "");
        if (url.isEmpty()) {
            call.reject("Missing update URL");
            return;
        }

        if (receiver != null) {
            call.reject("An update download is already running");
            return;
        }

        Context context = getContext();
        DownloadManager manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (manager == null) {
            call.reject("Download Manager is unavailable");
            return;
        }

        String fileName = "NAW-Copilot-update.apk";
        File oldFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName);
        if (oldFile.exists()) oldFile.delete();

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setTitle("NAW Copilot update");
        request.setDescription("Downloading the latest signed APK...");
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setMimeType("application/vnd.android.package-archive");
        request.setAllowedOverMetered(true);
        request.setAllowedOverRoaming(true);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

        downloadId = manager.enqueue(request);
        call.resolve();

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
                if (id != downloadId) return;
                sendProgress(100, "Download complete. Opening installer...");
                unregisterReceiverSafe();
                installDownloadedApk();
            }
        };

        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            context.registerReceiver(receiver, filter);
        }

        sendProgress(0, "Downloading update...");
    }

    private void sendProgress(int percent, String status) {
        JSObject data = new JSObject();
        data.put("percent", percent);
        data.put("status", status);
        notifyListeners("downloadProgress", data);
    }

    private void installDownloadedApk() {
        Context context = getContext();
        File apk = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NAW-Copilot-update.apk");
        if (!apk.exists()) {
            sendProgress(0, "Downloaded APK not found.");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                settings.setData(Uri.parse("package:" + context.getPackageName()));
                settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(settings);
                sendProgress(100, "Allow installs from NAW Copilot, then tap Update again.");
            } catch (Exception e) {
                sendProgress(100, "Allow installs from this source in Android settings.");
            }
            return;
        }

        try {
            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", apk);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            sendProgress(100, "Could not open the Android installer: " + e.getMessage());
        }
    }

    private void unregisterReceiverSafe() {
        if (receiver == null) return;
        try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) {}
        receiver = null;
    }

    @Override
    protected void handleOnDestroy() {
        unregisterReceiverSafe();
        super.handleOnDestroy();
    }
}
