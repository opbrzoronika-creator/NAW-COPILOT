from pathlib import Path
import shutil,re
root=Path(__file__).resolve().parents[1]
android=root/'android'
java_dir=android/'app/src/main/java/com/nawmanusia/copilot'
res_xml=android/'app/src/main/res/xml'
java_dir.mkdir(parents=True,exist_ok=True);res_xml.mkdir(parents=True,exist_ok=True)
for name in ('NativeUpdaterPlugin.java','NativeMediaPlugin.java'):
    shutil.copy2(Path(__file__).with_name(name),java_dir/name)
shutil.copy2(Path(__file__).with_name('provider_paths.xml'),res_xml/'naw_file_paths.xml')
main=java_dir/'MainActivity.java'
if not main.exists():
    candidates=list((android/'app/src/main/java').rglob('MainActivity.java'))
    if not candidates: raise RuntimeError('MainActivity.java not found')
    src=candidates[0]
    text=src.read_text().replace('package com.nawmanusia.studio;','package com.nawmanusia.copilot;')
    if src.resolve()!=main.resolve(): src.unlink()
    main.write_text(text)
else:
    text=main.read_text()
if 'import android.os.Bundle;' not in text:
    text=text.replace('package com.nawmanusia.copilot;','package com.nawmanusia.copilot;\n\nimport android.os.Bundle;')
regs='''
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NativeUpdaterPlugin.class);
        registerPlugin(NativeMediaPlugin.class);
        super.onCreate(savedInstanceState);
    }
'''
if 'registerPlugin(NativeUpdaterPlugin.class)' not in text or 'registerPlugin(NativeMediaPlugin.class)' not in text:
    empty=r'public class MainActivity extends BridgeActivity\s*\{\s*\}'
    if re.search(empty,text):
        text=re.sub(empty,'public class MainActivity extends BridgeActivity {'+regs+'\n}',text,count=1)
    else:
        idx=text.rfind('}')
        if idx<0: raise RuntimeError('MainActivity closing brace not found')
        text=text[:idx]+regs+text[idx:]
main.write_text(text)
manifest=android/'app/src/main/AndroidManifest.xml';mt=manifest.read_text()
for perm in ('REQUEST_INSTALL_PACKAGES','INTERNET'):
    full='android.permission.'+perm
    if full not in mt:
        m=re.search(r'<manifest\b[^>]*>',mt)
        if not m: raise RuntimeError('manifest tag missing')
        mt=mt[:m.end()]+f'\n    <uses-permission android:name="{full}" />'+mt[m.end():]
provider='''        <provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/naw_file_paths" /></provider>\n'''
if 'androidx.core.content.FileProvider' not in mt: mt=mt.replace('</application>',provider+'    </application>')
manifest.write_text(mt)
# Studio uses Remotion WebCodecs/Mediabunny. Resize also uses browser-side Mediabunny conversion; no native H.264 encoder is required.
# Launcher assets
assets=Path(__file__).with_name('assets');res=android/'app/src/main/res'
sizes={'mipmap-mdpi':'48','mipmap-hdpi':'72','mipmap-xhdpi':'96','mipmap-xxhdpi':'144','mipmap-xxxhdpi':'192'}
for folder,n in sizes.items():
    d=res/folder;src=assets/f'ic_launcher_{n}.png'
    if d.exists() and src.exists():
        shutil.copy2(src,d/'ic_launcher.png');shutil.copy2(src,d/'ic_launcher_round.png')
for folder in ('mipmap-anydpi-v26','mipmap-anydpi'):
    d=res/folder
    if d.exists():
        for n in ('ic_launcher.xml','ic_launcher_round.xml'):(d/n).unlink(missing_ok=True)
print('Native updater + Gallery MediaStore applied.')
