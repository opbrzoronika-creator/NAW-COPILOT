from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[1]
android = root / 'android'
java_dir = android / 'app/src/main/java/com/nawmanusia/copilot'
res_xml = android / 'app/src/main/res/xml'
java_dir.mkdir(parents=True, exist_ok=True)
res_xml.mkdir(parents=True, exist_ok=True)

shutil.copy2(Path(__file__).with_name('NativeUpdaterPlugin.java'), java_dir / 'NativeUpdaterPlugin.java')
shutil.copy2(Path(__file__).with_name('provider_paths.xml'), res_xml / 'naw_file_paths.xml')

main = java_dir / 'MainActivity.java'
text = main.read_text()
if 'NativeUpdaterPlugin' not in text:
    text = text.replace('import com.getcapacitor.BridgeActivity;', 'import android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;')
    text = text.replace('public class MainActivity extends BridgeActivity {\n}', 'public class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        registerPlugin(NativeUpdaterPlugin.class);\n        super.onCreate(savedInstanceState);\n    }\n}')
    main.write_text(text)

manifest = android / 'app/src/main/AndroidManifest.xml'
text = manifest.read_text()
perm = '    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n'
if 'android.permission.REQUEST_INSTALL_PACKAGES' not in text:
    text = text.replace('<manifest ', '<manifest ', 1)
    first_tag_end = text.find('>')
    text = text[:first_tag_end + 1] + '\n' + perm + text[first_tag_end + 1:]
provider = '''        <provider\n            android:name="androidx.core.content.FileProvider"\n            android:authorities="${applicationId}.fileprovider"\n            android:exported="false"\n            android:grantUriPermissions="true">\n            <meta-data\n                android:name="android.support.FILE_PROVIDER_PATHS"\n                android:resource="@xml/naw_file_paths" />\n        </provider>\n'''
if 'androidx.core.content.FileProvider' not in text:
    text = text.replace('</application>', provider + '    </application>')
manifest.write_text(text)
print('Native updater applied.')
