package com.nawmanusia.copilot;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * Native one-pass H.264 encoder.
 * Remotion renders each frame as a lossless PNG; this plugin performs the only
 * video encoding pass and writes the resulting MP4 directly to MediaStore.
 */
@CapacitorPlugin(name = "NativeEncoder")
public class NativeEncoderPlugin extends Plugin {
    private MediaCodec codec;
    private MediaMuxer muxer;
    private int trackIndex = -1;
    private boolean muxerStarted = false;
    private File tempFile;
    private int width, height, fps;
    private long frameIndex;
    private int colorFormat;
    private boolean active = false;
    private String displayName;

    @PluginMethod
    public synchronized void startEncoder(PluginCall call) {
        if (active) { call.reject("Native encoder is already active."); return; }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            call.reject("Native H.264 encoder requires Android 5.0 or newer."); return;
        }
        try {
            width = even(call.getInt("width", 1920));
            height = even(call.getInt("height", 1080));
            fps = Math.max(1, call.getInt("fps", 30));
            int bitrate = Math.max(500_000, call.getInt("bitrate", 12_000_000));
            displayName = call.getString("displayName", "NAW_STUDIO_video.mp4");

            MediaCodecInfo info = findEncoder("video/avc");
            if (info == null) throw new Exception("No Android H.264 encoder found.");
            colorFormat = chooseColorFormat(info.getCapabilitiesForType("video/avc"));
            if (colorFormat == 0) throw new Exception("This device's H.264 encoder does not expose a supported YUV420 input format.");

            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            if (Build.VERSION.SDK_INT >= 21) {
                try { format.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR); } catch (Exception ignored) {}
            }

            codec = MediaCodec.createByCodecName(info.getName());
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();

            tempFile = new File(getContext().getCacheDir(), "naw-render-" + System.currentTimeMillis() + ".mp4");
            muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            trackIndex = -1;
            muxerStarted = false;
            frameIndex = 0;
            active = true;
            call.resolve();
        } catch (Exception e) {
            releaseEncoder();
            call.reject("Could not start native H.264 encoder: " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void writeFrame(PluginCall call) {
        if (!active || codec == null) { call.reject("Native encoder is not active."); return; }
        String base64 = call.getString("base64", "");
        if (base64.isEmpty()) { call.reject("Empty frame."); return; }
        try {
            byte[] encoded = Base64.decode(base64, Base64.DEFAULT);
            Bitmap source = BitmapFactory.decodeByteArray(encoded, 0, encoded.length);
            if (source == null) throw new Exception("Could not decode rendered frame.");
            Bitmap frame = source;
            if (source.getWidth() != width || source.getHeight() != height) {
                frame = Bitmap.createScaledBitmap(source, width, height, true);
            }
            byte[] yuv = bitmapToYuv420(frame, colorFormat);
            if (frame != source) frame.recycle();
            source.recycle();

            long ptsUs = (frameIndex * 1_000_000L) / fps;
            queueInput(yuv, ptsUs);
            drain(false);
            frameIndex++;
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not encode frame " + frameIndex + ": " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void finishEncoder(PluginCall call) {
        if (!active || codec == null) { call.reject("Native encoder is not active."); return; }
        try {
            int index = codec.dequeueInputBuffer(10_000);
            if (index >= 0) {
                ByteBuffer input = codec.getInputBuffer(index);
                if (input != null) input.clear();
                codec.queueInputBuffer(index, 0, 0, (frameIndex * 1_000_000L) / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            } else {
                throw new Exception("Timed out waiting for encoder input buffer.");
            }
            drain(true);
            if (muxerStarted) muxer.stop();
            if (muxer != null) muxer.release();
            muxer = null;
            if (codec != null) { codec.stop(); codec.release(); codec = null; }
            active = false;

            long bytes = tempFile.length();
            boolean save = call.getBoolean("save", true);
            Uri uri = null;
            if (save) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw new Exception("Gallery saving requires Android 10 or newer.");
                uri = saveToMediaStore(tempFile, displayName);
                if (tempFile.exists()) tempFile.delete();
                tempFile = null;
            }
            com.getcapacitor.JSObject out = new com.getcapacitor.JSObject().put("displayName", displayName).put("bytes", bytes);
            if (uri != null) out.put("uri", uri.toString());
            call.resolve(out);
        } catch (Exception e) {
            releaseEncoder();
            call.reject("Could not finish native H.264 render: " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void abortEncoder(PluginCall call) {
        releaseEncoder();
        call.resolve();
    }

    private void queueInput(byte[] data, long ptsUs) throws Exception {
        long deadline = System.currentTimeMillis() + 15_000;
        while (true) {
            int index = codec.dequeueInputBuffer(10_000);
            if (index >= 0) {
                ByteBuffer input = codec.getInputBuffer(index);
                if (input == null || input.capacity() < data.length) throw new Exception("Encoder input buffer is too small for this frame.");
                input.clear();
                input.put(data);
                codec.queueInputBuffer(index, 0, data.length, ptsUs, 0);
                return;
            }
            if (System.currentTimeMillis() > deadline) throw new Exception("Timed out waiting for encoder input buffer.");
            drain(false);
        }
    }

    private void drain(boolean endOfStream) throws Exception {
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        long deadline = System.currentTimeMillis() + (endOfStream ? 20_000 : 2_000);
        while (true) {
            int out = codec.dequeueOutputBuffer(bufferInfo, 10_000);
            if (out == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream || System.currentTimeMillis() > deadline) return;
                continue;
            }
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new Exception("Encoder output format changed twice.");
                trackIndex = muxer.addTrack(codec.getOutputFormat());
                muxer.start();
                muxerStarted = true;
                continue;
            }
            if (out < 0) continue;
            ByteBuffer encoded = codec.getOutputBuffer(out);
            if (encoded != null && bufferInfo.size > 0 && muxerStarted && (bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                encoded.position(bufferInfo.offset);
                encoded.limit(bufferInfo.offset + bufferInfo.size);
                muxer.writeSampleData(trackIndex, encoded, bufferInfo);
            }
            boolean eos = (bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            codec.releaseOutputBuffer(out, false);
            if (eos) return;
        }
    }

    private Uri saveToMediaStore(File file, String name) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NAW STUDIO");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        ContentResolver resolver = getContext().getContentResolver();
        Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Could not create Gallery entry.");
        try (FileInputStream in = new FileInputStream(file); OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new Exception("Could not open Gallery output.");
            byte[] buf = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) { if (n > 0) out.write(buf, 0, n); }
            out.flush();
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.Video.Media.IS_PENDING, 0);
        resolver.update(uri, done, null, null);
        return uri;
    }

    private static MediaCodecInfo findEncoder(String mime) {
        MediaCodecListCompat list = new MediaCodecListCompat();
        return list.find(mime);
    }

    private static int chooseColorFormat(MediaCodecInfo.CodecCapabilities caps) {
        int[] preferred = new int[] { MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar };
        for (int p : preferred) for (int f : caps.colorFormats) if (f == p) return p;
        return 0;
    }

    private static byte[] bitmapToYuv420(Bitmap bitmap, int format) {
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int[] argb = new int[w * h];
        bitmap.getPixels(argb, 0, w, 0, 0, w, h);
        byte[] out = new byte[w * h * 3 / 2];
        int frameSize = w * h;
        for (int j = 0; j < h; j++) {
            int uvRow = (j >> 1) * w;
            for (int i = 0; i < w; i++) {
                int c = argb[j * w + i];
                int r = Color.red(c), g = Color.green(c), b = Color.blue(c);
                int y = clamp(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
                out[j * w + i] = (byte)y;
                if ((j & 1) == 0 && (i & 1) == 0) {
                    int u = clamp(((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128);
                    int v = clamp(((112 * r - 94 * g - 18 * b + 128) >> 8) + 128);
                    int uv = frameSize + uvRow + i;
                    if (format == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
                        int q = frameSize + (j >> 1) * (w >> 1) + (i >> 1);
                        out[q] = (byte)u;
                        out[frameSize + frameSize / 4 + (j >> 1) * (w >> 1) + (i >> 1)] = (byte)v;
                    } else {
                        out[uv] = (byte)u;
                        out[uv + 1] = (byte)v;
                    }
                }
            }
        }
        return out;
    }

    private static int clamp(int x) { return x < 0 ? 0 : (x > 255 ? 255 : x); }
    private static int even(int x) { return Math.max(2, (x / 2) * 2); }

    private synchronized void releaseEncoder() {
        active = false;
        try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) {}
        try { if (muxer != null) { if (muxerStarted) muxer.stop(); muxer.release(); } } catch (Exception ignored) {}
        codec = null; muxer = null; muxerStarted = false; trackIndex = -1;
        if (tempFile != null && tempFile.exists()) tempFile.delete();
        tempFile = null;
    }

    @Override protected void handleOnDestroy() { releaseEncoder(); super.handleOnDestroy(); }

    private static final class MediaCodecListCompat {
        MediaCodecInfo find(String mime) {
            android.media.MediaCodecList list = new android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS);
            for (MediaCodecInfo i : list.getCodecInfos()) {
                if (i.isEncoder()) for (String t : i.getSupportedTypes()) if (mime.equalsIgnoreCase(t)) return i;
            }
            return null;
        }
    }
}
