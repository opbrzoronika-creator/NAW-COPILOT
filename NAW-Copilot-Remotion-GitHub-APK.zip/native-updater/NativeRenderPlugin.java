package com.nawmanusia.copilot;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Locale;

@CapacitorPlugin(name="NativeRender")
public class NativeRenderPlugin extends Plugin {
  private File inputFile; private OutputStream inputStream;
  @PluginMethod public synchronized void startInput(PluginCall call){try{File dir=new File(getContext().getCacheDir(),"naw-render");if(!dir.exists())dir.mkdirs();inputFile=new File(dir,"source.mp4");inputStream=new FileOutputStream(inputFile,false);call.resolve();}catch(Exception e){call.reject("Could not start render input: "+e.getMessage());}}
  @PluginMethod public synchronized void writeInputChunk(PluginCall call){if(inputStream==null){call.reject("Render input is not active.");return;}try{String b64=call.getString("base64","");if(b64.isEmpty()){call.reject("Empty render chunk.");return;}inputStream.write(Base64.decode(b64,Base64.DEFAULT));call.resolve();}catch(Exception e){call.reject("Could not write render input: "+e.getMessage());}}
  @PluginMethod public synchronized void finishInput(PluginCall call){try{if(inputStream!=null){inputStream.flush();inputStream.close();inputStream=null;}call.resolve();}catch(Exception e){call.reject("Could not finish render input: "+e.getMessage());}}
  @PluginMethod public synchronized void abortInput(PluginCall call){try{if(inputStream!=null)inputStream.close();}catch(Exception ignored){}inputStream=null;if(inputFile!=null)inputFile.delete();inputFile=null;call.resolve();}
  @PluginMethod public void encodeToGallery(PluginCall call){if(inputFile==null||!inputFile.exists()){call.reject("No render input file.");return;}if(Build.VERSION.SDK_INT<Build.VERSION_CODES.Q){call.reject("Gallery export requires Android 10 or newer.");return;}final String format=call.getString("format","h264");final int crf=Math.max(12,Math.min(30,call.getInt("crf",18)));final String preset=safePreset(call.getString("preset","medium"));final String profile=call.getString("proresProfile","lt");final String displayName=call.getString("displayName",format.equals("h264")?"NAW_STUDIO.mp4":"NAW_STUDIO.mov");File output=new File(inputFile.getParentFile(),"output."+(format.equals("h264")?"mp4":"mov"));String command;
    if("h264".equals(format)){command=String.format(Locale.US,"-y -i %s -map 0:v:0 -an -c:v libx264 -preset %s -crf %d -pix_fmt yuv420p -movflags +faststart %s",q(inputFile.getAbsolutePath()),preset,crf,q(output.getAbsolutePath()));}
    else {int p=profile.equals("422")?2:profile.equals("hq")?3:profile.equals("4444")?4:1;String pix=profile.equals("4444")?"yuva444p10le":"yuv422p10le";command=String.format(Locale.US,"-y -i %s -map 0:v:0 -an -c:v prores_ks -profile:v %d -pix_fmt %s %s",q(inputFile.getAbsolutePath()),p,pix,q(output.getAbsolutePath()));}
    FFmpegKit.executeAsync(command,session->{if(ReturnCode.isSuccess(session.getReturnCode())){try{long bytes=saveToGallery(output,displayName,format.equals("h264")?"video/mp4":"video/quicktime");cleanup();JSObject r=new JSObject();r.put("size",bytes);r.put("displayName",displayName);call.resolve(r);}catch(Exception e){cleanup();call.reject("Could not save encoded video to Gallery: "+e.getMessage());}}else{String fail=session.getFailStackTrace();cleanup();call.reject("FFmpeg encode failed: "+(fail==null?"unknown error":fail));}},log->{},statistics->{if(statistics!=null&&statistics.getTime()>0){JSObject p=new JSObject();p.put("timeMs",statistics.getTime());notifyListeners("renderProgress",p);}});
  }
  private long saveToGallery(File output,String name,String mime)throws Exception{ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,mime);v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/NAW STUDIO");v.put(MediaStore.Video.Media.IS_PENDING,1);ContentResolver r=getContext().getContentResolver();Uri uri=r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception("MediaStore insert failed");try(InputStream in=Files.newInputStream(output.toPath());OutputStream out=r.openOutputStream(uri)){if(out==null)throw new Exception("MediaStore output failed");byte[] buf=new byte[1024*1024];int n;long total=0;while((n=in.read(buf))!=-1){out.write(buf,0,n);total+=n;}out.flush();v.clear();v.put(MediaStore.Video.Media.IS_PENDING,0);r.update(uri,v,null,null);return total;}catch(Exception e){r.delete(uri,null,null);throw e;}}
  private static String q(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}private static String safePreset(String p){return (p.equals("ultrafast")||p.equals("superfast")||p.equals("veryfast")||p.equals("faster")||p.equals("fast")||p.equals("medium")||p.equals("slow")||p.equals("slower"))?p:"medium";}private void cleanup(){try{if(inputStream!=null)inputStream.close();}catch(Exception ignored){}inputStream=null;if(inputFile!=null)inputFile.delete();inputFile=null;}
  @Override protected void handleOnDestroy(){cleanup();super.handleOnDestroy();}
}
