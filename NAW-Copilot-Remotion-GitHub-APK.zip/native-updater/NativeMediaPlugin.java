package com.nawmanusia.copilot;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;

@CapacitorPlugin(name = "NativeMedia")
public class NativeMediaPlugin extends Plugin {
    private Uri pendingUri;
    private OutputStream outputStream;

    @PluginMethod
    public synchronized void startVideoSave(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("Gallery saving requires Android 10 or newer.");
            return;
        }
        if (outputStream != null || pendingUri != null) {
            call.reject("A gallery save is already in progress.");
            return;
        }

        String displayName = call.getString("displayName", "NAW_Copilot_video.mp4");
        String mimeType = call.getString("mimeType", "video/mp4");

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, mimeType);
            values.put(MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/NAW STUDIO");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            ContentResolver resolver = getContext().getContentResolver();
            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Could not create Gallery entry");

            OutputStream stream = resolver.openOutputStream(uri);
            if (stream == null) {
                resolver.delete(uri, null, null);
                throw new Exception("Could not open Gallery file");
            }

            pendingUri = uri;
            outputStream = stream;
            call.resolve();
        } catch (Exception e) {
            pendingUri = null;
            outputStream = null;
            call.reject("Could not start Gallery save: " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void writeVideoChunk(PluginCall call) {
        if (outputStream == null || pendingUri == null) {
            call.reject("No Gallery save is active.");
            return;
        }

        String base64 = call.getString("base64", "");
        if (base64.isEmpty()) {
            call.reject("Empty video chunk.");
            return;
        }

        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            outputStream.write(data);
            outputStream.flush();
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not write video data: " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void finishVideoSave(PluginCall call) {
        if (outputStream == null || pendingUri == null) {
            call.reject("No Gallery save is active.");
            return;
        }

        Uri uri = pendingUri;
        try {
            outputStream.flush();
            outputStream.close();
            outputStream = null;

            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContext().getContentResolver().update(uri, values, null, null);

            pendingUri = null;
            call.resolve();
        } catch (Exception e) {
            try { outputStream.close(); } catch (Exception ignored) {}
            outputStream = null;
            try { getContext().getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            pendingUri = null;
            call.reject("Could not finish Gallery save: " + e.getMessage());
        }
    }

    @PluginMethod
    public synchronized void abortVideoSave(PluginCall call) {
        Uri uri = pendingUri;
        try {
            if (outputStream != null) outputStream.close();
        } catch (Exception ignored) {}

        outputStream = null;
        pendingUri = null;

        if (uri != null) {
            try { getContext().getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
        }
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        Uri uri = pendingUri;
        try { if (outputStream != null) outputStream.close(); } catch (Exception ignored) {}
        outputStream = null;
        pendingUri = null;
        if (uri != null) {
            try { getContext().getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
        }
        super.handleOnDestroy();
    }
}
