# NAW STUDIO v22.3.1

Visual Scene Editor prototype for the Android APK.

## Visual Editor
- Tap objects directly in the preview to select them.
- Object strip provides a fallback selection list.
- Move X/Y, scale, rotation, opacity, fill and stroke.
- Hide/delete, duplicate, lock/unlock, bring front/send back.
- Reset the selected object override.
- Visual overrides are applied to Studio export without changing the original Scene Lock code.

## Existing features preserved
- Studio and Editor tabs.
- H.264 MP4 rendering.
- ProRes 422 LT MOV rendering.
- ProRes 4444 Alpha workflow.
- Scene Lock / Base Scene.
- Color & Gradient Editor.
