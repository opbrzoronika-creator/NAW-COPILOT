import React, { useCallback, useEffect, useMemo, useState } from 'react';

const FUNCTIONS = {
  list: 'admin-list-users',
  create: 'admin-create-user',
  block: 'admin-block-user',
  activate: 'admin-activate-user',
  reset: 'admin-reset-password',
};
const BASE = 'https://ooskrnbkrucicqctyxfk.supabase.co/functions/v1/';

async function callFunction(name, token, body) {
  const r = await fetch(BASE + name, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body || {}),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.success) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
}

function fmtDate(value) {
  if (!value) return 'Never';
  try { return new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); }
  catch { return String(value); }
}

export default function AdminPanel({ session, onBack, onLogout, themeIcon, toggleTheme }) {
  const token = session?.access_token || '';
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busyUser, setBusyUser] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [showReset, setShowReset] = useState(null);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetPassword, setResetPassword] = useState('');
  const [query, setQuery] = useState('');

  const loadUsers = useCallback(async () => {
    if (!token) return;
    setLoading(true); setError('');
    try {
      const data = await callFunction(FUNCTIONS.list, token, {});
      setUsers(Array.isArray(data.users) ? data.users : []);
    } catch (e) {
      setError(e?.message || 'Failed to load users.');
      if (/session|unauthorized/i.test(e?.message || '')) setTimeout(onLogout, 600);
    } finally { setLoading(false); }
  }, [token, onLogout]);

  useEffect(() => { loadUsers(); }, [loadUsers]);

  const run = async (username, fn, body, successText) => {
    setBusyUser(username); setError(''); setMessage('');
    try {
      await callFunction(fn, token, body);
      setMessage(successText);
      await loadUsers();
    } catch (e) {
      setError(e?.message || 'Action failed.');
      if (/session|unauthorized/i.test(e?.message || '')) setTimeout(onLogout, 600);
    } finally { setBusyUser(''); }
  };

  const createUser = async (e) => {
    e.preventDefault();
    if (!newUsername.trim() || !newPassword) return setError('Enter username and password.');
    setBusyUser('__create__'); setError(''); setMessage('');
    try {
      await callFunction(FUNCTIONS.create, token, { username: newUsername.trim(), password: newPassword });
      setMessage(`User "${newUsername.trim().toLowerCase()}" created.`);
      setNewUsername(''); setNewPassword(''); setShowCreate(false); await loadUsers();
    } catch (e) { setError(e?.message || 'Failed to create user.'); }
    finally { setBusyUser(''); }
  };

  const doReset = async (e) => {
    e.preventDefault();
    if (!showReset || !resetPassword) return setError('Enter a new password.');
    setBusyUser(showReset); setError(''); setMessage('');
    try {
      await callFunction(FUNCTIONS.reset, token, { username: showReset, new_password: resetPassword });
      setMessage(`Password reset for "${showReset}".`);
      setResetPassword(''); setShowReset(null);
    } catch (e) { setError(e?.message || 'Failed to reset password.'); }
    finally { setBusyUser(''); }
  };

  const filtered = useMemo(() => users.filter(u => !query || String(u.username || '').toLowerCase().includes(query.toLowerCase())), [users, query]);
  const stats = useMemo(() => ({ total: users.length, active: users.filter(u => u.status === 'ACTIVE').length, blocked: users.filter(u => u.status === 'BLOCKED').length }), [users]);

  return <div className="admin-screen">
    <div className="top"><div className="head rise" style={{'--i':0}}>
      <button className="logo" onClick={onBack} aria-label="Back to Studio"><img src="/logo.png" alt="NAW Studio"/></button>
      <div className="brand"><b>NAW <span>STUDIO</span></b><small>ADMIN PANEL</small></div>
      <div className="account-chip" title="ADMIN"><span>admin</span><button onClick={onLogout} aria-label="Sign out">↪</button></div>
      <button className="iconbtn" onClick={toggleTheme} aria-label="Theme">{themeIcon}</button>
    </div></div>

    <main className="admin-wrap">
      <div className="admin-title-row">
        <div><div className="admin-kicker">ADMINISTRATION</div><h1>User Management</h1><p>Manage authorized NAW STUDIO accounts.</p></div>
        <button className="btn" onClick={()=>setShowCreate(true)}>＋ CREATE USER</button>
      </div>

      <div className="admin-stats">
        <div className="admin-stat"><span>Total</span><b>{stats.total}</b></div>
        <div className="admin-stat"><span>Active</span><b>{stats.active}</b></div>
        <div className="admin-stat"><span>Blocked</span><b>{stats.blocked}</b></div>
      </div>

      {message && <div className="admin-alert ok">{message}</div>}
      {error && <div className="admin-alert err">{error}</div>}

      <div className="card admin-card">
        <div className="admin-list-head"><div><div className="title">Users</div><div className="msg">{loading ? 'Refreshing…' : `${users.length} account${users.length===1?'':'s'}`}</div></div><button className="btn o" onClick={loadUsers} disabled={loading}>↻ REFRESH</button></div>
        <input className="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search username..."/>
        <div className="admin-users">
          {filtered.map(u => <div className="admin-user" key={u.id}>
            <div className="admin-avatar">{String(u.username || '?').slice(0,1).toUpperCase()}</div>
            <div className="admin-user-main">
              <div className="admin-user-top"><b>{u.username}</b><span className={`status ${String(u.status).toLowerCase()}`}>{u.status}</span><span className="role">{u.role}</span></div>
              <div className="admin-user-meta">{u.account_type} · Created {fmtDate(u.created_at)} · Last login {fmtDate(u.last_login_at)}</div>
              {u.role !== 'ADMIN' && <div className="admin-actions">
                {u.status === 'ACTIVE' ? <button className="danger" disabled={busyUser===u.username} onClick={()=>run(u.username, FUNCTIONS.block, {username:u.username}, `User "${u.username}" blocked.`)}>BLOCK</button> : <button className="success" disabled={busyUser===u.username} onClick={()=>run(u.username, FUNCTIONS.activate, {username:u.username}, `User "${u.username}" activated.`)}>ACTIVATE</button>}
                <button disabled={busyUser===u.username} onClick={()=>{setShowReset(u.username);setResetPassword('')}}>RESET PASSWORD</button>
              </div>}
            </div>
          </div>)}
          {!filtered.length && <div className="empty">No users found.</div>}
        </div>
      </div>
      <button className="btn o admin-back" onClick={onBack}>← BACK TO STUDIO</button>
    </main>

    {showCreate && <div className="admin-modal" onClick={()=>setShowCreate(false)}><form className="admin-modal-card" onSubmit={createUser} onClick={e=>e.stopPropagation()}>
      <div className="title">Create User</div><p className="msg">Lifetime account · USER role</p>
      <label className="login-field"><span>USERNAME</span><input autoFocus value={newUsername} onChange={e=>setNewUsername(e.target.value)} placeholder="username"/></label>
      <label className="login-field"><span>PASSWORD</span><input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} placeholder="Minimum 8 characters"/></label>
      <div className="btns"><button type="button" className="btn o" onClick={()=>setShowCreate(false)}>CANCEL</button><button className="btn" disabled={busyUser==='__create__'}>{busyUser==='__create__'?'CREATING…':'CREATE USER'}</button></div>
    </form></div>}

    {showReset && <div className="admin-modal" onClick={()=>setShowReset(null)}><form className="admin-modal-card" onSubmit={doReset} onClick={e=>e.stopPropagation()}>
      <div className="title">Reset Password</div><p className="msg">User: <b>{showReset}</b></p>
      <label className="login-field"><span>NEW PASSWORD</span><input autoFocus type="password" value={resetPassword} onChange={e=>setResetPassword(e.target.value)} placeholder="Minimum 8 characters"/></label>
      <div className="btns"><button type="button" className="btn o" onClick={()=>setShowReset(null)}>CANCEL</button><button className="btn" disabled={busyUser===showReset}>{busyUser===showReset?'RESETTING…':'RESET PASSWORD'}</button></div>
    </form></div>}
  </div>;
}
