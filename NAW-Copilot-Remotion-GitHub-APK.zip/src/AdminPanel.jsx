import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';

const FUNCTIONS = { list:'admin-list-users', create:'admin-create-user', block:'admin-block-user', activate:'admin-activate-user', reset:'admin-reset-password', delete:'admin-delete-user' };
const BASE = 'https://ooskrnbkrucicqctyxfk.supabase.co/functions/v1/';

async function callFunction(name, token, body) {
  const r = await fetch(BASE + name, { method:'POST', headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`}, body:JSON.stringify(body||{}) });
  const data = await r.json().catch(()=>({}));
  if (!r.ok || !data.success) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
}
function fmtDate(value){if(!value)return 'Never';try{return new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'})}catch{return String(value)}}
function xmlEsc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;')}
function excelCell(v,type='String'){return `<Cell><Data ss:Type="${type}">${xmlEsc(v)}</Data></Cell>`}
function exportExcel(users){
  const headers=['Username','Role','Status','Account Type','Created','Last Login'];
  const rows=users.map(u=>[u.username,u.role,u.status,u.account_type,u.created_at?new Date(u.created_at).toISOString():'',u.last_login_at?new Date(u.last_login_at).toISOString():'']);
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?>
  <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
   <Worksheet ss:Name="Users"><Table><Row>${headers.map(h=>excelCell(h)).join('')}</Row>${rows.map(r=>`<Row>${r.map(v=>excelCell(v)).join('')}</Row>`).join('')}</Table></Worksheet>
  </Workbook>`;
  const blob=new Blob([xml],{type:'application/vnd.ms-excel'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`NAW-STUDIO-users-${new Date().toISOString().slice(0,10)}.xls`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}

function exportCsv(users){
  const headers=['Username','Role','Status','Account Type','Created','Last Login'];
  const esc=v=>`"${String(v??'').replace(/"/g,'""')}"`;
  const rows=users.map(u=>[u.username,u.role,u.status,u.account_type,u.created_at?new Date(u.created_at).toISOString():'',u.last_login_at?new Date(u.last_login_at).toISOString():'']);
  const csv=[headers,...rows].map(r=>r.map(esc).join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`NAW-STUDIO-users-${new Date().toISOString().slice(0,10)}.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}

function parseCsv(text){
  const rows=[];let row=[],cell='',quote=false;
  for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'&&quote&&n==='"'){cell+='"';i++;continue}if(c==='"'){quote=!quote;continue}if(c===','&&!quote){row.push(cell);cell='';continue}if((c==='\n'||c==='\r')&&!quote){if(c==='\r'&&n==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell='';continue}cell+=c}if(cell||row.length){row.push(cell);if(row.some(x=>x.trim()))rows.push(row)}return rows}
async function parseExcelFile(file){
  const text=await file.text();
  if(file.name.toLowerCase().endsWith('.csv')){const rows=parseCsv(text);if(!rows.length)return[];const headers=rows[0].map(x=>x.trim().toLowerCase());return rows.slice(1).map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??'']))).filter(x=>x.username)}
  const doc=new DOMParser().parseFromString(text,'application/xml');
  if(doc.querySelector('parsererror'))throw new Error('Excel file tidak dikenali. Gunakan Excel XML .xls atau CSV.');
  const rows=[...doc.getElementsByTagNameNS('*','Row')];if(!rows.length)throw new Error('Tidak ada data user pada file Excel.');
  const values=rows.map(r=>[...r.getElementsByTagNameNS('*','Data')].map(d=>d.textContent||''));const headers=values.shift().map(x=>x.trim().toLowerCase());
  return values.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??'']))).filter(x=>x.username);
}

export default function AdminPanel({session,onBack,onLogout,themeIcon,toggleTheme}){
 const token=session?.access_token||'';const [users,setUsers]=useState([]),[loading,setLoading]=useState(false),[busyUser,setBusyUser]=useState(''),[message,setMessage]=useState(''),[error,setError]=useState(''),[showCreate,setShowCreate]=useState(false),[showReset,setShowReset]=useState(null),[newUsername,setNewUsername]=useState(''),[newPassword,setNewPassword]=useState(''),[resetPassword,setResetPassword]=useState(''),[query,setQuery]=useState(''),[statusFilter,setStatusFilter]=useState('ALL');
 const fileRef=useRef(null);
 const loadUsers=useCallback(async()=>{if(!token)return;setLoading(true);setError('');try{const data=await callFunction(FUNCTIONS.list,token,{});setUsers(Array.isArray(data.users)?data.users:[])}catch(e){setError(e?.message||'Failed to load users.');if(/session|unauthorized/i.test(e?.message||''))setTimeout(onLogout,600)}finally{setLoading(false)}},[token,onLogout]);
 useEffect(()=>{loadUsers()},[loadUsers]);
 const run=async(username,fn,body,successText)=>{setBusyUser(username);setError('');setMessage('');try{await callFunction(fn,token,body);setMessage(successText);await loadUsers()}catch(e){setError(e?.message||'Action failed.');if(/session|unauthorized/i.test(e?.message||''))setTimeout(onLogout,600)}finally{setBusyUser('')}};
 const createUser=async e=>{e.preventDefault();if(!newUsername.trim()||!newPassword)return setError('Enter username and password.');setBusyUser('__create__');setError('');setMessage('');try{await callFunction(FUNCTIONS.create,token,{username:newUsername.trim(),password:newPassword});setMessage(`User "${newUsername.trim().toLowerCase()}" created.`);setNewUsername('');setNewPassword('');setShowCreate(false);await loadUsers()}catch(e){setError(e?.message||'Failed to create user.')}finally{setBusyUser('')}};
 const doReset=async e=>{e.preventDefault();if(!showReset||!resetPassword)return setError('Enter a new password.');setBusyUser(showReset);setError('');setMessage('');try{await callFunction(FUNCTIONS.reset,token,{username:showReset,new_password:resetPassword});setMessage(`Password reset for "${showReset}".`);setResetPassword('');setShowReset(null)}catch(e){setError(e?.message||'Failed to reset password.')}finally{setBusyUser('')}};
 const deleteUser=async username=>{if(!username||!window.confirm(`Delete account \"${username}\" permanently?`))return;await run(username,FUNCTIONS.delete,{username},`User \"${username}\" deleted.`)};
 const filtered=useMemo(()=>users.filter(u=>(!query||String(u.username||'').toLowerCase().includes(query.toLowerCase()))&&(statusFilter==='ALL'||u.status===statusFilter)),[users,query,statusFilter]);
 const stats=useMemo(()=>({total:users.length,active:users.filter(u=>u.status==='ACTIVE').length,blocked:users.filter(u=>u.status==='BLOCKED').length}),[users]);
 const importExcel=async e=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;setError('');setMessage('');try{const rows=await parseExcelFile(file);let done=0;for(const r of rows){const username=String(r.username||r['user name']||'').trim().toLowerCase();if(!username)continue;const wanted=String(r.status||'').trim().toUpperCase();const current=users.find(u=>u.username.toLowerCase()===username);if(!current)continue;if(wanted==='BLOCKED'&&current.status==='ACTIVE'&&current.role!=='ADMIN'){await callFunction(FUNCTIONS.block,token,{username});done++}else if(wanted==='ACTIVE'&&current.status==='BLOCKED'&&current.role!=='ADMIN'){await callFunction(FUNCTIONS.activate,token,{username});done++}}await loadUsers();setMessage(`Import selesai. ${done} status user diperbarui. User baru tidak dibuat karena file Excel tidak menyimpan password.`)}catch(err){setError(err?.message||'Import Excel gagal.')}};
 return <div className="admin-screen">
  <div className="top"><div className="head rise" style={{'--i':0}}><button className="logo" onClick={onBack} aria-label="Back to Studio"><img src="/logo.png" alt="NAW Studio"/></button><div className="brand"><b>NAW <span>STUDIO</span></b><small>ADMIN PANEL</small></div><div className="head-actions"><div className="account-chip" title="ADMIN"><span>{(()=>{try{return JSON.parse(localStorage.getItem('naw_auth_user')||'{}')?.username||'admin'}catch{return'admin'}})()}</span><button onClick={onLogout} aria-label="Sign out">↪</button></div><button className="iconbtn" onClick={toggleTheme} aria-label="Theme">{themeIcon}</button></div></div></div>
  <main className="admin-wrap">
   <section className="admin-hero rise" style={{'--i':1}}><div><div className="admin-kicker">ADMINISTRATION</div><h1>User Management</h1><p>Manage authorized NAW STUDIO accounts.</p></div><button className="btn" onClick={()=>setShowCreate(true)}>＋ CREATE USER</button></section>
   <section className="admin-stats"><div className="admin-stat"><span>Total</span><b>{stats.total}</b></div><div className="admin-stat"><span>Active</span><b>{stats.active}</b></div><div className="admin-stat"><span>Blocked</span><b>{stats.blocked}</b></div></section>
   {message&&<div className="admin-alert ok">✓ {message}</div>}{error&&<div className="admin-alert err">! {error}</div>}
   <section className="card admin-card rise" style={{'--i':2}}>
    <div className="admin-list-head"><div><div className="title">Users</div><div className="msg">{loading?'Refreshing…':`${filtered.length} of ${users.length} account${users.length===1?'':'s'}`}</div></div><div className="admin-tools"><button className="btn o" onClick={()=>exportCsv(filtered)} disabled={!filtered.length}>↓ CSV</button><button className="btn o" onClick={()=>exportExcel(filtered)} disabled={!filtered.length}>↓ EXCEL</button><button className="btn o" onClick={()=>fileRef.current?.click()}>↑ IMPORT EXCEL</button><button className="btn o" onClick={loadUsers} disabled={loading}>↻ REFRESH</button><input ref={fileRef} type="file" accept=".xls,.xml,.csv,text/csv,application/vnd.ms-excel" hidden onChange={importExcel}/></div></div>
    <div className="admin-filters"><input className="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search username..."/><div className="seg admin-status-filter"><button className={statusFilter==='ALL'?'on':''} onClick={()=>setStatusFilter('ALL')}>All</button><button className={statusFilter==='ACTIVE'?'on':''} onClick={()=>setStatusFilter('ACTIVE')}>Active</button><button className={statusFilter==='BLOCKED'?'on':''} onClick={()=>setStatusFilter('BLOCKED')}>Blocked</button></div></div>
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Account</th><th>Created</th><th>Last Login</th><th>Actions</th></tr></thead><tbody>{filtered.map(u=><tr key={u.id}><td><div className="user-cell"><span className="admin-avatar">{String(u.username||'?').slice(0,1).toUpperCase()}</span><div><b>{u.username}</b><small>{u.id}</small></div></div></td><td><span className="role-pill">{u.role}</span></td><td><span className={`status-pill ${String(u.status).toLowerCase()}`}>{u.status}</span></td><td>{u.account_type}</td><td>{fmtDate(u.created_at)}</td><td>{fmtDate(u.last_login_at)}</td><td>{u.role==='ADMIN'?<span className="admin-protected">Protected</span>:<div className="table-actions">{u.status==='ACTIVE'?<button className="table-danger" disabled={busyUser===u.username} onClick={()=>run(u.username,FUNCTIONS.block,{username:u.username},`User "${u.username}" blocked.`)}>BLOCK</button>:<button className="table-success" disabled={busyUser===u.username} onClick={()=>run(u.username,FUNCTIONS.activate,{username:u.username},`User "${u.username}" activated.`)}>ACTIVATE</button>}<button disabled={busyUser===u.username} onClick={()=>{setShowReset(u.username);setResetPassword('')}}>RESET</button><button className="table-danger" disabled={busyUser===u.username} onClick={()=>deleteUser(u.username)}>DELETE</button></div>}</td></tr>)}{!filtered.length&&<tr><td colSpan="7"><div className="empty">No users found.</div></td></tr>}</tbody></table></div>
    <div className="admin-import-note">Excel export contains account metadata only. Import can safely update existing users' ACTIVE/BLOCKED status; passwords are never exported or imported.</div>
   </section>
   <button className="btn o admin-back" onClick={onBack}>← BACK TO DASHBOARD</button>
  </main>
  {showCreate&&<div className="admin-modal" onClick={()=>setShowCreate(false)}><form className="admin-modal-card" onSubmit={createUser} onClick={e=>e.stopPropagation()}><div className="title">Create User</div><p className="msg">Lifetime account · USER role</p><label className="login-field"><span>USERNAME</span><input autoFocus value={newUsername} onChange={e=>setNewUsername(e.target.value)} placeholder="username"/></label><label className="login-field"><span>PASSWORD</span><input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} placeholder="Minimum 8 characters"/></label><div className="btns"><button type="button" className="btn o" onClick={()=>setShowCreate(false)}>CANCEL</button><button className="btn" disabled={busyUser==='__create__'}>{busyUser==='__create__'?'CREATING…':'CREATE USER'}</button></div></form></div>}
  {showReset&&<div className="admin-modal" onClick={()=>setShowReset(null)}><form className="admin-modal-card" onSubmit={doReset} onClick={e=>e.stopPropagation()}><div className="title">Reset Password</div><p className="msg">User: <b>{showReset}</b></p><label className="login-field"><span>NEW PASSWORD</span><input autoFocus type="password" value={resetPassword} onChange={e=>setResetPassword(e.target.value)} placeholder="Minimum 8 characters"/></label><div className="btns"><button type="button" className="btn o" onClick={()=>setShowReset(null)}>CANCEL</button><button className="btn" disabled={busyUser===showReset}>{busyUser===showReset?'RESETTING…':'RESET PASSWORD'}</button></div></form></div>}
 </div>
}
