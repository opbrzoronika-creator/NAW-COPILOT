const MODEL = 'gemini-3.6-flash';
const RETRY = [429, 500, 502, 503, 504];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const RULES = (mode) => `Scene rules:
- Define exactly: function Scene() { ... } returning a React element built with h(type, props, ...children) (h = React.createElement). NO JSX, NO imports.
- Available identifiers: h, React, useCurrentFrame, useVideoConfig, interpolate, spring, ThreeCanvas, THREE, Math.
- Get const frame = useCurrentFrame(); const { width, height, durationInFrames } = useVideoConfig();
- Animate ONLY from frame (no Date/random per frame; use seeded math). Seamless loop: p = frame / durationInFrames, use Math.sin(p*2*Math.PI) and integer cycles.
- Size everything relative to u = Math.min(width, height) so every aspect ratio (16:9, 9:16, 1:1, 3:4, 4:3) works. Keep key content inside the frame.
- Client-side renderer limits: no CSS backgrounds/filters on divs, no zIndex, no <div> layout. ${mode === '3d'
  ? 'MODE 3D: return h(ThreeCanvas, { width, height, camera: { position: [0,0,6], fov: 45 } }, ...) with React Three Fiber elements as strings (mesh, boxGeometry, sphereGeometry, torusKnotGeometry, meshStandardMaterial, ambientLight, directionalLight, pointLight, group, color). Set background with h("color", { attach: "background", args: ["#hex"] }). Rotate objects via props computed from frame (never useFrame).'
  : 'MODE 2D: return a single full-frame <svg width={width} height={height} viewBox="0 0 width height"> (use h("svg", ...)). Draw everything inside the SVG (gradients, paths, circles, text). SVG filters are OK.'}
- Keep it simple and fast: under ~60 objects, no heavy loops.
- If reference images or video frames are attached: they only show the desired look (colors, shapes, composition, motion). Recreate that look with code. NEVER copy logos, brands, trademarks, copyrighted characters or readable text from them.`;

export const SYSTEM = (mode) => `You write ONE JavaScript function for a Remotion video scene. Output ONLY raw code (no markdown, no explanation).\n${RULES(mode)}`;

export const CHAT_SYSTEM = (mode) => `You are the scene assistant inside NAW COPILOT, helping stock-footage contributors (Adobe Stock) create video scene code.
Niche knowledge (general guidance, NOT live market data): buyers commonly search for abstract/gradient backgrounds, business & finance charts, technology/data/AI networks, seasonal and holiday themes (Christmas, New Year, Black Friday, Ramadan/Eid, Valentine), nature-like particles, calm loopable backgrounds, social-media vertical 9:16 clips, and clips with empty copy space for text. Strong stock clips: seamless loop, clean composition, smooth motion, no logos/brands/trademarks/copyrighted characters, little or no text, and visibly different compositions between clips (vary shapes/layout/camera, not just color) to avoid near-duplicate rejections. If asked about current demand or rules, say you have no live data, give general guidance, and suggest checking Adobe Stock search results and the contributor guidelines.
Reply in English only. Format: at most 3 short sentences of advice/explanation. When the user wants a scene created or changed, ALSO include exactly ONE fenced code block (\`\`\`js ... \`\`\`) with the full function Scene(). If the user only asks a question, answer without code.
${RULES(mode)}`;

export async function callGemini({ keys, startIndex, system, contents, onStatus = () => {}, temperature = 0.5 }) {
  let idx = startIndex, last = 0;
  const body = JSON.stringify({ contents, systemInstruction: { parts: [{ text: system }] }, generationConfig: { temperature } });
  for (let attempt = 1; attempt <= 5; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 90000);
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': keys[idx] }, body, signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        const out = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('');
        if (!out.trim()) throw new Error('Respons kosong dari Gemini.');
        return { text: out, keyIndex: idx };
      }
      last = res.status;
      if (res.status === 404) throw new Error('404: model ' + MODEL + ' was not found or this key has no access.');
      if ([400, 401, 403].includes(res.status)) throw new Error('API key is invalid or has no access (' + res.status + ').');
      if (!RETRY.includes(res.status)) throw new Error('API Error: ' + res.status);
    } catch (e) {
      clearTimeout(timer);
      const net = e.name === 'AbortError' || e instanceof TypeError;
      if (!net && !RETRY.includes(last)) throw e;
      if (net) last = e.name === 'AbortError' ? 408 : 0;
    }
    if (attempt === 5) break;
    if (keys.length > 1 && (last === 429 || attempt >= 2)) idx = (idx + 1) % keys.length;
    const wait = Math.min(2 ** attempt, 15);
    for (let s = wait; s > 0; s--) { onStatus(`Server sibuk (${last || 'jaringan'}). Coba lagi ${attempt}/4 dalam ${s}s...`); await sleep(1000); }
  }
  throw new Error(last === 429 ? 'Kuota API habis di semua key.' : `Server Google masih sibuk (${last || 'jaringan'}). Coba lagi nanti.`);
}

export const refParts = (refs = []) => refs.flatMap((r, i) => [
  { text: `[Reference ${i + 1}: ${r.kind === 'video' ? r.frames.length + ' frames sampled evenly in order from a ' + r.duration.toFixed(1) + 's video; infer the motion' : 'image'}]` },
  ...r.frames.map((d) => ({ inlineData: { mimeType: 'image/jpeg', data: d } })),
]);
const strip = (t) => t.replace(/^```[a-z]*\n?/i, '').replace(/```\s*$/, '').trim();

export async function askGemini({ keys, startIndex, mode, prompt, current, onStatus, refs = [] }) {
  const text = current ? `Current code:\n${current}\n\nModify it according to this request (return the full new code): ${prompt}` : `Create a new scene: ${prompt}`;
  const r = await callGemini({ keys, startIndex, system: SYSTEM(mode), contents: [{ role: 'user', parts: [...refParts(refs), { text }] }], onStatus });
  return { code: strip(r.text), keyIndex: r.keyIndex };
}

export async function chatGemini({ keys, startIndex, mode, history, currentCode, onStatus, refs = [] }) {
  let msgs = history.slice(-10).map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text || '(scene)' }] }));
  while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  const lastU = msgs.length - 1;
  if (currentCode && msgs[lastU]) msgs[lastU].parts[0].text += `\n\n[Current scene code in the preview, modify it only if the request is about changing the scene]\n${currentCode}`;
  if (refs.length && msgs[lastU]) msgs[lastU].parts.unshift(...refParts(refs));
  const r = await callGemini({ keys, startIndex, system: CHAT_SYSTEM(mode), contents: msgs, onStatus, temperature: 0.6 });
  return { text: r.text, keyIndex: r.keyIndex };
}
