import React, { useEffect, useState } from 'react';
import { DICT, LANGUAGES, initialLang } from './i18n.js';
import Studio from './App.jsx';
import Updater from './Updater.jsx';
import AdminPanel from './AdminPanel.jsx';

const LOGIN_ENDPOINT = 'https://ooskrnbkrucicqctyxfk.supabase.co/functions/v1/username-login';

function Login({ onLogin, t, theme, toggleTheme, lang, setLang }) {
  const savedRemember = localStorage.getItem('naw_remember_login') === '1';
  const [username, setUsername] = useState(() => savedRemember ? (localStorage.getItem('naw_remember_username') || '') : '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(savedRemember);
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async (e) => {
    e.preventDefault(); if (busy) return; setError('');
    if (!username.trim() || !password) { setError(t('loginRequired')); return; }
    setBusy(true);
    try {
      const r = await fetch(LOGIN_ENDPOINT, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username:username.trim(),password}) });
      const data = await r.json().catch(()=>({}));
      if (!r.ok || !data.success || !data.session || !data.user) throw new Error(data.error || t('loginFailed'));
      if (remember) { localStorage.setItem('naw_remember_login','1'); localStorage.setItem('naw_remember_username', username.trim()); } else { localStorage.removeItem('naw_remember_login'); localStorage.removeItem('naw_remember_username'); }
      localStorage.setItem('naw_auth_session', JSON.stringify(data.session));
      localStorage.setItem('naw_auth_user', JSON.stringify(data.user));
      onLogin(data.user, data.session);
    } catch(err) { setError(err?.message || t('loginFailed')); }
    finally { setBusy(false); }
  };
  return <div className="login-screen">
    <div className="login-tools"><select value={lang} onChange={e=>setLang(e.target.value)} aria-label={t('language')}>
      {LANGUAGES.map(x=><option key={x.code} value={x.code}>{x.label}</option>)}
    </select><button className="iconbtn" onClick={toggleTheme} aria-label={t('theme')}>{theme==='dark'?'☀':'☾'}</button></div>
    <div className="login-card rise" style={{'--i':1}}>
      <div className="login-logo"><img src="/logo.png" alt="NAW Studio"/></div><h1>NAW <span>STUDIO</span></h1>
      <p className="login-sub">{t('loginSub')}</p>
      <form onSubmit={submit}>
        <label className="login-field"><span>{t('username').toUpperCase()}</span><input autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} placeholder={t('username')} disabled={busy}/></label>
        <label className="login-field password-wrap"><span>{t('password').toUpperCase()}</span><input type={showPassword?'text':'password'} autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} placeholder={t('password')} disabled={busy}/><button type="button" className="password-eye" onClick={()=>setShowPassword(v=>!v)} aria-label="Show password">{showPassword?'◉':'◌'}</button></label><label className="remember-row"><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)}/><span>Remember Login</span></label>
        {error&&<div className="login-error">{error}</div>}
        <button className="btn big login-btn" type="submit" disabled={busy}>{busy?t('signingIn'):t('signIn')}</button>
      </form><small className="login-note">{t('authorized')}</small>
    </div>
  </div>;
}

function Dashboard({ t, authUser, theme, toggleTheme, lang, setLang, onStudio, onEditor, onLogout, onAdmin }) {
  return <div className="dashboard-screen">
    <div className="top"><div className="head rise" style={{'--i':0}}>
      <div className="brand"><button className="logo" onClick={()=>{}} aria-label="NAW Studio"><img src="/logo.png" alt="NAW Studio"/></button><div><b>NAW <span>STUDIO</span></b><small>{t('tagShort')}</small></div></div>
      <div className="head-actions"><div className="account-chip" title={authUser?.role||'USER'}><span>{authUser?.username||'user'}</span><button onClick={onLogout} aria-label={t('signOut')}>↪</button></div><select className="lang-select" value={lang} onChange={e=>setLang(e.target.value)} aria-label={t('language')} title={LANGUAGES.find(x=>x.code===lang)?.label||lang}>{LANGUAGES.map(x=><option key={x.code} value={x.code}>{x.code.toUpperCase()}</option>)}</select><button className="iconbtn" onClick={toggleTheme} aria-label={t('theme')}>{theme==='dark'?'☀':'☾'}</button></div>
    </div></div>
    <main className="dashboard-body">
      <section className="dashboard-hero rise" style={{'--i':1}}><div><div className="eyebrow">{t('dashboard')}</div><h1>{t('welcomeTitle')}</h1><p>{t('welcomeDesc')}</p></div><div className="dash-avatar">{String(authUser?.username||'N').slice(0,1).toUpperCase()}</div></section>
      <section className="dashboard-grid">
        <button className="dash-card primary rise" style={{'--i':2}} onClick={onStudio}><span className="dash-icon">✦</span><strong>{t('openStudio')}</strong><small>{t('studioDesc')}</small><b>→</b></button>
        <button className="dash-card rise" style={{'--i':3}} onClick={onEditor}><span className="dash-icon">✎</span><strong>{t('openEditor')}</strong><small>{t('editorDesc')}</small><b>→</b></button>
        <div className="dash-card info rise" style={{'--i':4}}><span className="dash-icon">▣</span><strong>{t('localFirst')}</strong><small>{t('localDesc')}</small></div>
      </section>
      {authUser?.role==='ADMIN'&&<button className="dash-card admin-dashboard-card rise" style={{'--i':5}} onClick={onAdmin}><span className="dash-icon">⚙</span><strong>{t('adminPanel')}</strong><small>{t('adminDesc')}</small><b>→</b></button>}<div className="dashboard-foot">{t('dashboardFoot')}</div>
    </main>
  </div>;
}

const initialTheme=()=>localStorage.getItem('naw_theme')||(window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light');
export default function Root(){
 const [lang,setLangState]=useState(()=>{const saved=localStorage.getItem('naw_lang'); return saved&&DICT[saved]?saved:initialLang()});
 const setLang=v=>{setLangState(v);localStorage.setItem('naw_lang',v)};
 const t=k=>DICT[lang]?.[k]||DICT.en[k]||k;
 const [theme,setTheme]=useState(initialTheme);
 const [auth,setAuth]=useState(()=>{try{const user=JSON.parse(localStorage.getItem('naw_auth_user')||'null');const session=JSON.parse(localStorage.getItem('naw_auth_session')||'null');if(!user||!session||!session.access_token)return null;if(session.expires_at&&Date.now()/1000>=Number(session.expires_at))return null;return {user,session}}catch{return null}});
 const [view,setView]=useState('dashboard');
 const [studioTab,setStudioTab]=useState('studio');
 const [leaving,setLeaving]=useState(false),[fs,setFs]=useState(!!document.fullscreenElement);
 const fsSupported=!!document.documentElement.requestFullscreen;
 const enterFs=()=>{const el=document.documentElement;if(!document.fullscreenElement&&el.requestFullscreen)el.requestFullscreen({navigationUI:'hide'}).catch(()=>{})};
 const toggleFs=()=>{if(document.fullscreenElement)document.exitFullscreen?.();else enterFs()};
 const toggleTheme=()=>setTheme(x=>x==='dark'?'light':'dark'); const themeIcon=theme==='dark'?'☀':'☾';
 useEffect(()=>{document.documentElement.lang=lang;localStorage.setItem('naw_theme',theme);document.documentElement.dataset.theme=theme;document.querySelector('meta[name=theme-color]')?.setAttribute('content',theme==='dark'?'#0c0a09':'#f0401f')},[theme,lang]);
 useEffect(()=>{const f=()=>setFs(!!document.fullscreenElement);document.addEventListener('fullscreenchange',f);return()=>document.removeEventListener('fullscreenchange',f)},[]);
 const logout=()=>{localStorage.removeItem('naw_auth_session');localStorage.removeItem('naw_auth_user');setAuth(null);setView('dashboard')};
 const login=(user,session)=>{setAuth({user,session});setView('dashboard');setLeaving(false)};
 const openStudio=()=>{setStudioTab('studio');setLeaving(true);setTimeout(()=>{setView('studio');setLeaving(false);setTimeout(enterFs,80)},260)};
 const openAdmin=()=>{setLeaving(true);setTimeout(()=>{setView('admin');setLeaving(false)},260)};
 const openEditor=()=>{setStudioTab('editor');setLeaving(true);setTimeout(()=>{setView('studio');setLeaving(false);setTimeout(enterFs,80)},260)};
 const backDashboard=()=>{if(document.fullscreenElement)document.exitFullscreen?.();setLeaving(true);setTimeout(()=>{setView('dashboard');setLeaving(false);window.scrollTo(0,0)},260)};
 const authState=auth?.user?.id||'guest';
 return <><Updater authState={authState}/>{!auth ? <Login onLogin={login} t={t} theme={theme} toggleTheme={toggleTheme} lang={lang} setLang={setLang}/> : view==='admin' && auth.user?.role==='ADMIN' ? <AdminPanel session={auth.session} onBack={backDashboard} onLogout={logout} themeIcon={themeIcon} toggleTheme={toggleTheme}/> : <div className={'screen'+(leaving?' out':'')}>{view==='dashboard'?<Dashboard t={t} authUser={auth.user} theme={theme} toggleTheme={toggleTheme} lang={lang} setLang={setLang} onStudio={openStudio} onEditor={openEditor} onAdmin={openAdmin} onLogout={logout}/>:<Studio initialTab={studioTab} t={t} themeIcon={themeIcon} toggleTheme={toggleTheme} fs={fs} fsSupported={fsSupported} toggleFs={toggleFs} onBack={backDashboard} authUser={auth.user} onLogout={logout} lang={lang} setLang={setLang}/>}</div>}</>;
}
