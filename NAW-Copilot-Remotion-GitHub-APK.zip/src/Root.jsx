import React, { useEffect, useState } from 'react';
import { DICT } from './i18n.js';
import Studio from './App.jsx';

const APP_VERSION = '22.1.0';
const RELEASES_URL = 'https://api.github.com/repos/opbrzoronika-creator/NAW-COPILOT/releases/latest';

const initialTheme = () => localStorage.getItem('naw_theme') || (window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
const versionNumber = (v) => String(v || '').replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
const isNewer = (latest, current) => {
  const a = versionNumber(latest), b = versionNumber(current);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) > (b[i] || 0);
  }
  return false;
};

export default function Root() {
  const [theme, setTheme] = useState(initialTheme);
  const [view, setView] = useState('welcome');
  const [leaving, setLeaving] = useState(false);
  const [evt, setEvt] = useState(null);
  const [update, setUpdate] = useState(null);
  const [fs, setFs] = useState(!!document.fullscreenElement);
  const fsSupported = !!document.documentElement.requestFullscreen;
  const t = (k) => DICT.en[k];
  const standalone = window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone;
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const enterFs = () => { const el = document.documentElement; if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen({ navigationUI: 'hide' }).catch(() => {}); };
  const toggleFs = () => { if (document.fullscreenElement) document.exitFullscreen?.(); else enterFs(); };
  const toggleTheme = () => setTheme((x) => (x === 'dark' ? 'light' : 'dark'));
  const themeIcon = theme === 'dark' ? '☀' : '☾';

  useEffect(() => {
    const f = (e) => { if (!e.target.closest?.('textarea,input,.bub')) e.preventDefault(); };
    document.addEventListener('contextmenu', f);
    return () => document.removeEventListener('contextmenu', f);
  }, []);
  useEffect(() => { document.documentElement.lang = 'en'; }, []);
  useEffect(() => {
    localStorage.setItem('naw_theme', theme);
    document.documentElement.dataset.theme = theme;
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', theme === 'dark' ? '#0c0a09' : '#f0401f');
  }, [theme]);
  useEffect(() => {
    const f = () => setFs(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', f);
    return () => document.removeEventListener('fullscreenchange', f);
  }, []);
  useEffect(() => {
    const f = (e) => { e.preventDefault(); setEvt(e); };
    window.addEventListener('beforeinstallprompt', f);
    window.addEventListener('appinstalled', () => setEvt(null));
    return () => window.removeEventListener('beforeinstallprompt', f);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      try {
        const res = await fetch(RELEASES_URL, { cache: 'no-store', headers: { Accept: 'application/vnd.github+json' } });
        if (!res.ok) return;
        const rel = await res.json();
        const latest = String(rel.tag_name || '').replace(/^v/i, '');
        if (!cancelled && latest && isNewer(latest, APP_VERSION)) {
          const apk = (rel.assets || []).find((a) => /\.apk$/i.test(a.name || ''));
          setUpdate({ version: latest, url: apk?.browser_download_url || rel.html_url, name: apk?.name || 'Latest APK', notes: rel.body || '' });
        }
      } catch { /* update check is optional */ }
    };
    check();
    const timer = setInterval(check, 6 * 60 * 60 * 1000);
    return () => { cancelled = true; clearInterval(timer); };
  }, []);

  const go = (v) => { if (leaving) return; if (v === 'studio') enterFs(); setLeaving(true); setTimeout(() => { setView(v); setLeaving(false); window.scrollTo(0, 0); }, 420); };
  const install = async () => { if (!evt) return; evt.prompt(); await evt.userChoice; setEvt(null); };
  const openUpdate = () => { if (!update?.url) return; window.open(update.url, '_blank', 'noopener,noreferrer'); };
  const r = (n) => ({ className: 'rise', style: { '--i': n } });

  if (view === 'studio') return (
    <div className={'screen' + (leaving ? ' out' : '')}>
      <Studio t={t} onBack={() => go('welcome')} theme={theme} themeIcon={themeIcon} toggleTheme={toggleTheme} fs={fs} fsSupported={fsSupported} toggleFs={toggleFs} />
    </div>
  );

  return (
    <div className={'welcome screen' + (leaving ? ' out' : '')}>
      <button className="iconbtn w-theme rise" style={{ '--i': 9 }} onClick={toggleTheme} aria-label="Theme">{themeIcon}</button>
      <div className="w-top">
        <div className="w-logo rise">N</div>
        <h1 {...r(1)}>NAW <span>COPILOT</span></h1>
        <small {...r(2)}>{t('tag')}</small>
        <h2 {...r(3)}>{t('welcomeTitle')}</h2>
        <p {...r(4)}>{t('welcomeDesc')}</p>
        <ul>{['f1', 'f2', 'f3'].map((k, n) => <li key={k} {...r(5 + n)}><i>✦</i>{t(k)}</li>)}</ul>
        {update && <div className="update-card rise" style={{ '--i': 8 }}>
          <div className="update-title">↗ {t('updateTitle')} <strong>v{update.version}</strong></div>
          <div className="update-text">{t('updateDesc')}</div>
          <button className="btn big" onClick={openUpdate}>{t('updateBtn')}</button>
        </div>}
        {standalone ? <p className="w-note rise" style={{ '--i': 9 }}>✓ {t('installed')}</p>
          : evt ? <button className="btn o w-install rise" style={{ '--i': 9 }} onClick={install}>⬇ {t('install')}</button>
          : isIos ? <p className="w-note rise" style={{ '--i': 9 }}>{t('iosHint')}</p> : null}
      </div>
      <div className="w-bottom rise" style={{ '--i': 10 }}><button className="btn big" onClick={() => go('studio')}>{t('enter')} →</button></div>
    </div>
  );
}
