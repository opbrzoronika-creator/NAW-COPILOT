import React, { useEffect, useState } from 'react';
import { DICT } from './i18n.js';
import Studio from './App.jsx';
import Updater from './Updater.jsx';
import AdminPanel from './AdminPanel.jsx';

const LOGIN_ENDPOINT = 'https://ooskrnbkrucicqctyxfk.supabase.co/functions/v1/username-login';

function Login({ onLogin, t, theme, toggleTheme }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    setError('');
    if (!username.trim() || !password) {
      setError('Enter username and password.');
      return;
    }
    setBusy(true);
    try {
      const r = await fetch(LOGIN_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok || !data.success || !data.session || !data.user) {
        throw new Error(data.error || 'Login failed.');
      }
      localStorage.setItem('naw_auth_session', JSON.stringify(data.session));
      localStorage.setItem('naw_auth_user', JSON.stringify(data.user));
      onLogin(data.user, data.session);
    } catch (err) {
      setError(err?.message || 'Login failed.');
    } finally {
      setBusy(false);
    }
  };

  return <div className="login-screen">
    <button className="iconbtn login-theme" onClick={toggleTheme} aria-label="Theme">{theme==='dark'?'☀':'☾'}</button>
    <div className="login-card rise" style={{'--i':1}}>
      <div className="login-logo"><img src="/logo.png" alt="NAW Studio"/></div>
      <h1>NAW <span>STUDIO</span></h1>
      <p className="login-sub">Sign in to continue</p>
      <form onSubmit={submit}>
        <label className="login-field"><span>USERNAME</span><input autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" disabled={busy}/></label>
        <label className="login-field"><span>PASSWORD</span><input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" disabled={busy}/></label>
        {error&&<div className="login-error">{error}</div>}
        <button className="btn big login-btn" type="submit" disabled={busy}>{busy?'SIGNING IN…':'SIGN IN →'}</button>
      </form>
      <small className="login-note">Authorized accounts only</small>
    </div>
  </div>;
}
const initialTheme=()=>localStorage.getItem('naw_theme')||(window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light');
export default function Root(){
 const lang='id',t=k=>DICT[lang][k];
 const [theme,setTheme]=useState(initialTheme);
 const [auth,setAuth]=useState(()=>{try{const user=JSON.parse(localStorage.getItem('naw_auth_user')||'null');const session=JSON.parse(localStorage.getItem('naw_auth_session')||'null');if(!user||!session||!session.access_token)return null;if(session.expires_at&&Date.now()/1000>=Number(session.expires_at))return null;return {user,session}}catch{return null}});
 const [view,setView]=useState('studio');
 const [leaving,setLeaving]=useState(false),[evt,setEvt]=useState(null),[fs,setFs]=useState(!!document.fullscreenElement);
 const fsSupported=!!document.documentElement.requestFullscreen;
 const isIos=/iphone|ipad|ipod/i.test(navigator.userAgent);
 const enterFs=()=>{const el=document.documentElement;if(!document.fullscreenElement&&el.requestFullscreen)el.requestFullscreen({navigationUI:'hide'}).catch(()=>{})};
 const toggleFs=()=>{if(document.fullscreenElement)document.exitFullscreen?.();else enterFs()};
 const toggleTheme=()=>setTheme(x=>x==='dark'?'light':'dark');
 const themeIcon=theme==='dark'?'☀':'☾';
 useEffect(()=>{document.documentElement.lang='en';localStorage.setItem('naw_theme',theme);document.documentElement.dataset.theme=theme;document.querySelector('meta[name=theme-color]')?.setAttribute('content',theme==='dark'?'#0c0a09':'#f0401f')},[theme]);
 useEffect(()=>{const f=()=>setFs(!!document.fullscreenElement);document.addEventListener('fullscreenchange',f);return()=>document.removeEventListener('fullscreenchange',f)},[]);
 useEffect(()=>{const f=e=>{e.preventDefault();setEvt(e)};const g=()=>setEvt(null);window.addEventListener('beforeinstallprompt',f);window.addEventListener('appinstalled',g);return()=>{window.removeEventListener('beforeinstallprompt',f);window.removeEventListener('appinstalled',g)}},[]);
 const logout=()=>{localStorage.removeItem('naw_auth_session');localStorage.removeItem('naw_auth_user');setAuth(null);setView('studio')};
 const go=v=>{if(leaving)return;if(v==='studio')enterFs();setLeaving(true);setTimeout(()=>{setView(v);setLeaving(false);window.scrollTo(0,0)},420)};
 const login=(user,session)=>{setAuth({user,session});setView('studio');setLeaving(false);setTimeout(enterFs,80)};
 if(!auth) return <><Updater/><Login onLogin={login} t={t} theme={theme} toggleTheme={toggleTheme}/></>;
 if(view==='admin' && auth.user?.role==='ADMIN') return <><Updater/><AdminPanel session={auth.session} onBack={()=>go('studio')} onLogout={logout} themeIcon={themeIcon} toggleTheme={toggleTheme}/></>;
 return <><Updater/><div className={'screen'+(leaving?' out':'')}><Studio t={t} themeIcon={themeIcon} toggleTheme={toggleTheme} fs={fs} fsSupported={fsSupported} toggleFs={toggleFs} onBack={()=>go('studio')} authUser={auth.user} onLogout={logout} onAdmin={()=>go('admin')}/></div></>;
}
