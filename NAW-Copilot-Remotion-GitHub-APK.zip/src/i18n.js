export const DICT = {
  en: {
    tag: 'PRO AI MOTION ENGINE', tagShort: 'PRO AI ENGINE', welcomeTitle: 'Create motion graphics with AI',
    welcomeDesc: 'NAW COPILOT turns your text prompts into 2D and 3D animations and exports them as MP4 video up to 4K, right from your browser or phone.',
    f1: 'AI Copilot: type an idea, get a 2D or 3D animation', f2: 'MP4 export up to 4K, 24/30/60 fps, 5 aspect ratios', f3: 'Installable on your phone and works offline (except Copilot)',
    lang: 'Language', install: 'Install on phone', iosHint: 'On iPhone: tap Share, then "Add to Home Screen".', installed: 'App already installed', enter: 'ENTER APP',
    viewport: 'VIEWPORT PREVIEW', copilot: 'Copilot Prompt', reset: '↺ Reset Scene',
    ph: 'Write a prompt... e.g. glossy red 3D ornament, slow rotation, dark green background, seamless loop',
    make: 'CREATE SCENE', busyAi: 'PROCESSING...', refine: 'REFINE', codeEdit: 'Scene code (manual edit)', applyCode: 'APPLY CODE', cancel: 'CANCEL',
    res: 'Render Resolution', ratio: 'Aspect Ratio', fps: 'Frame Rate', dur: 'Animation Duration', sec: 'Seconds',
    exportBtn: 'EXPORT MP4', rendering: 'RENDERING...',
    keyTitle: 'Gemini API Key', close: 'Close', save: 'SAVE', keyPh: 'One key per line. Stored only in this browser.', keyNote: 'Multiple keys = automatic switch when quota runs out.',
    needKey: 'Enter your Gemini API key first.', needPrompt: 'Write a prompt first.', writing: 'Writing scene...', refining: 'Refining scene...', applied: 'Scene applied.',
    preparing: 'Preparing...', done: 'Done', fixCode: 'Fix the code error first.', back: '← Home',
    "copyAll": "Copy", "paste": "Paste", "clearAll": "Clear all", "pasteFail": "Can't read the clipboard. Paste manually: long-press inside the code box.", "copied": "Code copied.",
    "addRef": "Reference", "refNote": "References are only used to imitate style, color and motion. Use your own material; don't copy logos, brands or others' work.", "refMax": "Maximum 3 references.", "refErr": "Could not read the reference file", "refReading": "Reading reference...", "refDefault": "Create a scene in the style of this reference.",
    "tabStudio": "Studio", "tabChat": "AI Chat", "tabFiles": "Files", "chatHello": "Hi! I'm the scene assistant for stock contributors. Tell me your clip idea and I'll write the scene code and give niche tips.", "chatPh": "Describe a scene or ask a question...", "send": "Send", "thinking": "AI is writing...", "applyView": "APPLY & VIEW", "viewCode": "View code", "clearChat": "Clear chat", "chips": [["Finance neon", "3D neon bar chart on a futuristic grid floor, glowing bars rising with a trend line, slow camera orbit, seamless loop, no text"], ["Abstract loop", "Abstract flowing gradient background, soft light particles, calm and elegant, seamless loop, lots of copy space"], ["Minimal Christmas", "Minimal Christmas close-up: one glossy red ornament swinging gently, dark green background, soft snow, seamless loop, no text"], ["Tech network", "Technology data network of glowing nodes and lines on dark blue background, slow drifting motion, seamless loop, no text"]], "filesGen": "Generated", "filesTrash": "Trash", "emptyGen": "No scenes yet. Scenes from Studio and Chat are saved here automatically.", "emptyTrash": "Trash is empty.", "open": "Open", "rename": "Rename", "del": "Delete", "restore": "Restore", "delForever": "Delete forever", "emptyBtn": "Empty trash", "trashNote": "Items in trash are deleted automatically after 30 days.", "backup": "Export backup", "importBtn": "Import backup", "renamePrompt": "New name:", "confirmDel": "Delete permanently?", "imported": "Backup imported.", "badFile": "Invalid backup file.",
  },
};

export const initialLang = () => 'en';
