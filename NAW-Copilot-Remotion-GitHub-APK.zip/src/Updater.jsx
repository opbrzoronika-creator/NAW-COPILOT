import React,{useEffect,useRef,useState} from 'react';
import { registerPlugin } from '@capacitor/core';
import packageJson from '../package.json';

const OWNER='opbrzoronika-creator';
const REPO='NAW-COPILOT';
const CHECK_URL=`https://api.github.com/repos/${OWNER}/${REPO}/releases`;
const NativeUpdater=registerPlugin('NativeUpdater');

function vp(v){return String(v||'').replace(/^v/i,'').split(/[.-]/).slice(0,3).map(x=>parseInt(x,10)||0)}
function newer(a,b){const x=vp(a),y=vp(b);for(let i=0;i<3;i++){if(x[i]>y[i])return true;if(x[i]<y[i])return false}return false}

async function fetchUpdate(){
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),12000);
  try{
    const r=await fetch(`${CHECK_URL}?per_page=10&t=${Date.now()}`,{
      headers:{Accept:'application/vnd.github+json'},cache:'no-store',signal:controller.signal
    });
    if(!r.ok)throw new Error(`GitHub HTTP ${r.status}`);
    const releases=await r.json();
    if(!Array.isArray(releases))return null;
    const candidates=releases
      .filter(rel=>rel?.tag_name&&!rel.draft&&!rel.prerelease&&Array.isArray(rel.assets))
      .map(rel=>{
        const apk=rel.assets.find(a=>/\.apk$/i.test(String(a?.name||''))&&a?.browser_download_url);
        return apk?{rel,apk}:null;
      }).filter(Boolean)
      .filter(({rel})=>newer(rel.tag_name,packageJson.version))
      .sort((a,b)=>{
        const x=vp(a.rel.tag_name),y=vp(b.rel.tag_name);
        for(let i=0;i<3;i++){if(x[i]!==y[i])return y[i]-x[i]}
        return 0;
      });
    if(!candidates.length)return null;
    const {rel,apk}=candidates[0];
    return {version:String(rel.tag_name).replace(/^v/i,''),url:apk.browser_download_url,notes:String(rel.body||'').trim()};
  }finally{clearTimeout(timeout)}
}

export default function Updater(){
  const [update,setUpdate]=useState(null);
  const running=useRef(false);
  const mounted=useRef(true);
  useEffect(()=>()=>{mounted.current=false},[]);
  useEffect(()=>{
    let active=true;
    const check=async()=>{
      if(!active||running.current)return;
      running.current=true;
      try{const next=await fetchUpdate();if(active&&mounted.current)setUpdate(next)}
      catch(e){console.warn('NAW STUDIO update check failed',e?.message||e)}
      finally{running.current=false}
    };
    check();
    const id=setInterval(check,10*60*1000);
    const onVisible=()=>{if(document.visibilityState==='visible')check()};
    document.addEventListener('visibilitychange',onVisible);
    return()=>{active=false;clearInterval(id);document.removeEventListener('visibilitychange',onVisible)};
  },[]);
  if(!update)return null;
  const openDownload=async()=>{
    try{if(NativeUpdater?.downloadAndInstall){await NativeUpdater.downloadAndInstall({url:update.url});return}}
    catch(e){console.warn('Native updater unavailable, using browser fallback',e)}
    window.open(update.url,'_blank','noopener,noreferrer');
  };
  return <div role="dialog" aria-modal="true" style={{position:'fixed',inset:0,zIndex:99999,display:'grid',placeItems:'center',padding:20,background:'rgba(0,0,0,.62)',backdropFilter:'blur(6px)'}}>
    <div style={{width:'min(430px,100%)',borderRadius:22,padding:22,background:'var(--card,#171717)',color:'var(--ink,#fff)',border:'1px solid rgba(255,255,255,.12)',boxShadow:'0 24px 70px rgba(0,0,0,.4)'}}>
      <img src="/logo.png" alt="" style={{width:62,height:62,borderRadius:18,display:'block',marginBottom:12}}/>
      <div style={{fontSize:13,opacity:.65,marginBottom:7}}>NAW STUDIO</div>
      <h2 style={{margin:'0 0 8px',fontSize:22}}>Update available</h2>
      <p style={{margin:'0 0 8px',lineHeight:1.5}}>Version <b>{update.version}</b> is ready. Your current version is <b>{packageJson.version}</b>.</p>
      <p style={{margin:'0 0 18px',lineHeight:1.5,opacity:.72}}>Update NAW STUDIO to the latest official signed APK.</p>
      {update.notes&&<details style={{marginBottom:18}}><summary>Release notes</summary><pre style={{whiteSpace:'pre-wrap',fontFamily:'inherit',fontSize:12,opacity:.75,marginTop:9}}>{update.notes}</pre></details>}
      <button type="button" onClick={openDownload} style={{width:'100%',minHeight:52,border:0,borderRadius:13,background:'#f04a2f',color:'#fff',fontWeight:800,fontSize:15}}>Update Now</button>
    </div>
  </div>;
}
