import React, { useCallback, useEffect, useState } from 'react';
import packageJson from '../package.json';

const OWNER = 'opbrzoronika-creator';
const REPO = 'NAW-COPILOT';
const CHECK_URL = `https://api.github.com/repos/${OWNER}/${REPO}/releases/latest`;
const CACHE_KEY = 'naw_update_check';
const CHECK_INTERVAL = 6 * 60 * 60 * 1000;

function versionParts(v) {
  return String(v || '')
    .replace(/^v/i, '')
    .split(/[.-]/)
    .slice(0, 3)
    .map((x) => Number.parseInt(x, 10) || 0);
}

function isNewer(latest, current) {
  const a = versionParts(latest);
  const b = versionParts(current);
  for (let i = 0; i < 3; i += 1) {
    if (a[i] > b[i]) return true;
    if (a[i] < b[i]) return false;
  }
  return false;
}

function saveCheck(data) {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify({ ...data, checkedAt: Date.now() })); } catch {}
}

function readCheck() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export default function Updater() {
  const currentVersion = packageJson.version;
  const [update, setUpdate] = useState(null);
  const [checking, setChecking] = useState(false);
  const [open, setOpen] = useState(false);

  const check = useCallback(async (force = false) => {
    if (checking) return;
    const cached = readCheck();
    if (!force && cached?.checkedAt && Date.now() - cached.checkedAt < CHECK_INTERVAL) {
      if (cached.update) setUpdate(cached.update);
      return;
    }

    setChecking(true);
    try {
      const response = await fetch(CHECK_URL, {
        headers: { Accept: 'application/vnd.github+json' },
        cache: 'no-store',
      });
      if (!response.ok) throw new Error(`GitHub HTTP ${response.status}`);

      const release = await response.json();
      if (release?.draft || release?.prerelease || !release?.tag_name) {
        saveCheck({ update: null });
        setUpdate(null);
        return;
      }

      const apk = Array.isArray(release.assets)
        ? release.assets.find((asset) =>
            String(asset?.name || '').toLowerCase().endsWith('.apk') &&
            String(asset?.name || '').startsWith('NAW-Copilot-') &&
            asset?.browser_download_url
          )
        : null;

      const next = isNewer(release.tag_name, currentVersion) && apk
        ? {
            version: String(release.tag_name).replace(/^v/i, ''),
            notes: String(release.body || '').trim(),
            url: apk.browser_download_url,
            assetName: apk.name,
          }
        : null;

      saveCheck({ update: next });
      setUpdate(next);
      if (next) setOpen(true);
    } catch (error) {
      console.warn('NAW Copilot update check failed:', error);
      saveCheck({ update: null, error: String(error?.message || error) });
    } finally {
      setChecking(false);
    }
  }, [checking, currentVersion]);

  useEffect(() => {
    check(false);
    const onVisible = () => { if (document.visibilityState === 'visible') check(false); };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [check]);

  const openDownload = async () => {
    if (!update?.url) return;
    const a = document.createElement('a');
    a.href = update.url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  if (!open || !update) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="NAW Copilot update"
      onClick={() => setOpen(false)}
      style={{
        position: 'fixed', inset: 0, zIndex: 99999, display: 'grid', placeItems: 'center',
        padding: 20, background: 'rgba(0,0,0,.58)', backdropFilter: 'blur(5px)'
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 'min(430px, 100%)', borderRadius: 22, padding: 22,
          background: 'var(--card, #171717)', color: 'var(--text, #fff)',
          border: '1px solid rgba(255,255,255,.12)', boxShadow: '0 24px 70px rgba(0,0,0,.4)'
        }}
      >
        <div style={{ fontSize: 13, opacity: .65, marginBottom: 7 }}>NAW COPILOT</div>
        <h2 style={{ margin: '0 0 8px', fontSize: 22 }}>Update available</h2>
        <p style={{ margin: '0 0 8px', lineHeight: 1.5 }}>
          Version <b>{update.version}</b> is ready. Your current version is <b>{currentVersion}</b>.
        </p>
        <p style={{ margin: '0 0 18px', lineHeight: 1.5, opacity: .72 }}>
          Download the signed APK. Android will ask you to confirm the installation.
        </p>
        {update.notes && (
          <details style={{ marginBottom: 18 }}>
            <summary style={{ cursor: 'pointer' }}>Release notes</summary>
            <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: 12, opacity: .75, marginTop: 9 }}>{update.notes}</pre>
          </details>
        )}
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            type="button"
            onClick={() => setOpen(false)}
            style={{ flex: 1, minHeight: 46, borderRadius: 13, border: '1px solid rgba(255,255,255,.15)', background: 'transparent', color: 'inherit', fontWeight: 700 }}
          >
            Later
          </button>
          <button
            type="button"
            onClick={openDownload}
            style={{ flex: 1.5, minHeight: 46, border: 0, borderRadius: 13, background: '#f04a2f', color: '#fff', fontWeight: 800 }}
          >
            Download update
          </button>
        </div>
        <button
          type="button"
          onClick={() => check(true)}
          disabled={checking}
          style={{ display: 'block', margin: '14px auto 0', border: 0, background: 'transparent', color: 'inherit', opacity: .55, fontSize: 12 }}
        >
          {checking ? 'Checking...' : 'Check again'}
        </button>
      </div>
    </div>
  );
}
