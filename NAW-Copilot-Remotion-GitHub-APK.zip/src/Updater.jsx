import React,{useCallback,useEffect,useRef,useState} from 'react';
import { registerPlugin } from '@capacitor/core';
import packageJson from '../package.json';

const NativeUpdater=registerPlugin('NativeUpdater');
const OWNER='opbrzoronika-creator',REPO='NAW-COPILOT';
const RELEASES_URL=`https://api.github.com/repos/${OWNER}/${REPO}/releases`;

function vp(v){return String(v||'').replace(/^v/i,'').split(/[.-]/).slice(0,3).map(x=>parseInt(x,10)||0)}
function newer(a,b){const x=vp(a),y=vp(b);for(let i=0;i<3;i++){if(x[i]>y[i])return true;if(x[i]<y[i])return false}return false}
function pickRelease(releases,currentVersion){
  return (Array.isArray(releases)?releases:[])
    .filter(rel=>rel&&!rel.draft&&!rel.prerelease&&rel.tag_name&&newer(rel.tag_name,currentVersion))
    .sort((a,b)=>newer(b.tag_name,a.tag_name)?1:-1)
    .map(rel=>({rel,apk:(Array.isArray(rel.assets)?rel.assets:[]).find(a=>/\.apk$/i.test(String(a?.name||''))&&a?.browser_download_url)}))
    .find(x=>x.apk)?.rel||null;
}

export default function Updater({authState}){
  const currentVersion=packageJson.version;
  const [update,setUpdate]=useState(null);
  const [checking,setChecking]=useState(false);
  const mounted=useRef(true);
  const running=useRef(false);

  const check=useCallback(async(reason='manual')=>{
    if(running.current)return null;
    running.current=true;
    if(mounted.current)setChecking(true);
    try{
      const url=`${RELEASES_URL}?per_page=10&_=${Date.now()}`;
      const r=await fetch(url,{headers:{Accept:'application/vnd.github+json'},cache:'no-store'});
      if(!r.ok)throw new Error(`GitHub HTTP ${r.status}`);
      const releases=await r.json();
      const rel=pickRelease(releases,currentVersion);
      const apk=rel&&Array.isArray(rel.assets)?rel.assets.find(a=>/\.apk$/i.test(String(a?.name||''))&&a?.browser_download_url):null;
      const next=rel&&apk?{version:String(rel.tag_name).replace(/^v/i,''),url:apk.browser_download_url,notes:String(rel.body||'').trim()}:null;
      if(mounted.current)setUpdate(next);
      return next;
    }catch(e){
      console.warn(`NAW STUDIO update check failed (${reason})`,e);
      return null;
    }finally{
      running.current=false;
      if(mounted.current)setChecking(false);
    }
  },[currentVersion]);

  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false}},[]);

  // Always check on app start, after login/logout transitions, foregrounding, and periodically.
  useEffect(()=>{
    check('startup/auth-transition');
    const interval=setInterval(()=>check('interval'),5*60*1000);
    const onVisible=()=>{if(document.visibilityState==='visible')check('foreground')};
    document.addEventListener('visibilitychange',onVisible);
    window.addEventListener('focus',onVisible);
    return()=>{clearInterval(interval);document.removeEventListener('visibilitychange',onVisible);window.removeEventListener('focus',onVisible)};
  },[check,authState]);

  if(!update)return null;

  const openDownload=async()=>{
    try{
      if(NativeUpdater?.downloadAndInstall){
        await NativeUpdater.downloadAndInstall({url:update.url});
        return;
      }
    }catch(e){console.warn('Native updater failed, using browser fallback',e)}
    window.open(update.url,'_blank','noopener,noreferrer');
  };

  return <div role="dialog" aria-modal="true" style={{position:'fixed',inset:0,zIndex:99999,display:'grid',placeItems:'center',padding:20,background:'rgba(0,0,0,.62)',backdropFilter:'blur(6px)'}}><div style={{width:'min(430px,100%)',borderRadius:22,padding:22,background:'var(--card,#171717)',color:'var(--ink,#fff)',border:'1px solid rgba(255,255,255,.12)',boxShadow:'0 24px 70px rgba(0,0,0,.4)'}} onClick={e=>e.stopPropagation()}><img src="/logo.png" alt="" style={{width:62,height:62,borderRadius:18,display:'block',marginBottom:12}}/><div style={{fontSize:13,opacity:.65,marginBottom:7}}>NAW STUDIO</div><h2 style={{margin:'0 0 8px',fontSize:22}}>Update required</h2><p style={{margin:'0 0 8px',lineHeight:1.5}}>Version <b>{update.version}</b> is ready. Your current version is <b>{currentVersion}</b>.</p><p style={{margin:'0 0 18px',lineHeight:1.5,opacity:.72}}>You must update NAW STUDIO to continue. Tap <b>Update Now</b> to install the official signed APK.</p>{update.notes&&<details style={{marginBottom:18}}><summary>Release notes</summary><pre style={{whiteSpace:'pre-wrap',fontFamily:'inherit',fontSize:12,opacity:.75,marginTop:9}}>{update.notes}</pre></details>}<button type="button" onClick={openDownload} disabled={checking} style={{width:'100%',minHeight:52,border:0,borderRadius:13,background:'#f04a2f',color:'#fff',fontWeight:800,fontSize:15}}>{checking?'Checking…':'Update Now'}</button></div></div>
}
