import React, { useEffect, useMemo, useRef, useState } from 'react';
import '@fontsource/inter/400.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';
import '@fontsource/fira-code/400.css';
import './index.css';
import { Player } from '@remotion/player';
import { renderMediaOnWeb } from '@remotion/web-renderer';
import { useCurrentFrame, useVideoConfig, interpolate, spring } from 'remotion';
import { registerPlugin } from '@capacitor/core';
import { DEFAULT_2D } from './defaults.js';
import { loadFiles, saveFiles, newFile } from './store.js';

const NativeMedia = registerPlugin('NativeMedia', { web: {
  async startVideoSave(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async writeVideoChunk(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async finishVideoSave(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async abortVideoSave(){},
  async addListener(){ return { remove(){} }; }
} });

const NativeRender = registerPlugin('NativeRender', { web: {
  async startInput(){ throw new Error('ProRes rendering is only available in the Android app.'); },
  async writeInputChunk(){ throw new Error('ProRes rendering is only available in the Android app.'); },
  async finishInput(){ throw new Error('ProRes rendering is only available in the Android app.'); },
  async abortInput(){},
  async encodeToGallery(){ throw new Error('ProRes rendering is only available in the Android app.'); },
  async addListener(){ return { remove(){} }; }
} });

const h=React.createElement;
const RATIOS={'16:9':[16,9],'9:16':[9,16],'1:1':[1,1],'3:4':[3,4],'4:3':[4,3]};
const RES={1080:'1080p',1440:'2K',2160:'4K'};
const even=n=>Math.max(2,Math.round(n/2)*2);
const size=(ratio,short)=>{const [w,hh]=RATIOS[ratio];return w>=hh?{width:even(short*w/hh),height:even(short)}:{width:even(short),height:even(short*hh/w)}};
function compile(code){const fn=new Function('React','h','useCurrentFrame','useVideoConfig','interpolate','spring','"use strict";\n'+code+'\n;return typeof Scene==="function"?Scene:null;');const S=fn(React,h,useCurrentFrame,useVideoConfig,interpolate,spring);if(!S)throw new Error('Kode harus mendefinisikan function Scene()');return S;}
function createEditorH(ctl){return function editorH(type,props,...children){if(typeof type!=='string')return React.createElement(type,props,...children);if(['svg','defs','linearGradient','radialGradient','stop'].includes(type))return React.createElement(type,props,...children);const id=props?.['data-naw-object-id']||`naw-${String(type).replace(/[^a-z0-9]/gi,'')}-${ctl.nextId++}`;const ov=ctl.overrides[id]||{};if(ov.hidden)return null;const label=props?.['aria-label']||props?.id||props?.['data-name']||`${type} #${id.split('-').pop()}`;if(ctl.register)ctl.register({id,type,label});const select=e=>{e.stopPropagation();ctl.select({id,type,label})};const p={...(props||{}),'data-naw-object-id':id,'data-naw-object-type':type,'data-naw-object-label':label,onClick:select};if(props?.onClick){const original=props.onClick;p.onClick=e=>{e.stopPropagation();ctl.select({id,type,label});original(e)}}if(ov.opacity!=null)p.opacity=ov.opacity;if(ov.fill!=null)p.fill=ov.fill;if(ov.stroke!=null)p.stroke=ov.stroke;if(ov.z!=null){p.style={...(props?.style||{}),zIndex:ov.z};p['data-naw-z']=String(ov.z);}if(ov.rotation!=null||ov.scale!=null||ov.x!=null||ov.y!=null){const x=ov.x||0,y=ov.y||0,r=ov.rotation||0,sc=ov.scale==null?1:ov.scale;const tr=`translate(${x} ${y}) rotate(${r}) scale(${sc})`;if(type==='div'||type==='span'||type==='img'||type==='section'){p.style={...(props?.style||{}),transform:tr,transformOrigin:'center center'}}else p.transform=tr}if(ov.locked)p['data-naw-locked']='1';const element=React.createElement(type,p,...children);if(ov.duplicate&&type!=='svg'&&type!=='defs'){const dp={...p,'data-naw-object-id':`${id}-copy`,'data-naw-duplicate':'1',key:`${id}-copy`};const dx=(ov.duplicateOffsetX==null?24:ov.duplicateOffsetX),dy=(ov.duplicateOffsetY==null?24:ov.duplicateOffsetY);if(type==='div'||type==='span'||type==='img'||type==='section')dp.style={...(dp.style||{}),transform:`translate(${dx}px, ${dy}px)`};else dp.transform=`translate(${dx} ${dy}) ${p.transform||''}`;return React.createElement(React.Fragment,null,element,React.createElement(type,dp,...children))}return element}}
function compileEditor(code,ctl){const eh=createEditorH(ctl);const fn=new Function('React','h','useCurrentFrame','useVideoConfig','interpolate','spring','"use strict";\n'+code+'\n;return typeof Scene==="function"?Scene:null;');const S=fn(React,eh,useCurrentFrame,useVideoConfig,interpolate,spring);if(!S)throw new Error('Kode harus mendefinisikan function Scene()');return function EditorScene(props){ctl.nextId=0;return React.createElement(S,props)}}
class Boundary extends React.Component{state={err:null};static getDerivedStateFromError(err){return{err}}componentDidUpdate(p){if(p.code!==this.props.code&&this.state.err)this.setState({err:null})}render(){return this.state.err?h('div',{className:'err'},'Error scene: '+this.state.err.message):this.props.children}}
const Opt=({label,children})=><div className="opt"><label>{label}</label>{children}</div>;
const P={fill:'none',stroke:'currentColor',strokeWidth:1.9,strokeLinecap:'round',strokeLinejoin:'round'};
const Ico=({n})=><svg width="26" height="26" viewBox="0 0 24 24" {...P}>{n==='studio'&&<><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z"/></>}{n==='editor'&&<><path d="M4 19h16"/><path d="M6 16.5l8.8-8.8 3.5 3.5-8.8 8.8H6z"/><path d="M13.8 8.7l1.6-1.6a1.8 1.8 0 0 1 2.6 0l.9.9a1.8 1.8 0 0 1 0 2.6l-1.6 1.6"/></>}{n==='files'&&<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17z"/>}{n==='resize'&&<><path d="M7 7h10v10"/><path d="M17 7 7 17"/><path d="M5 19h14"/></>}</svg>;

const PALETTES={Basic:['#000000','#ffffff','#ff0000','#ff7a00','#ffd400','#00c853','#00b8ff','#2457ff','#7c3aed','#ff2d92'],Pastel:['#ffd6e7','#ffe5b4','#fff3a3','#c7f9cc','#bde0fe','#c8b6ff','#f1c0e8','#d9f99d','#bae6fd','#e9d5ff'],Neon:['#ff0055','#ff4d00','#ffe600','#00ff66','#00eaff','#4d5bff','#a100ff','#ff00cc','#7cff00','#00fff0'],Cinematic:['#0b1020','#172554','#1e3a8a','#312e81','#4c1d95','#7f1d1d','#9a3412','#b45309','#d4a017','#e5e7eb'],Medical:['#ffffff','#e5f2ff','#bde3ff','#63c5da','#00a8cc','#0077b6','#90be6d','#f94144','#f9c74f','#577590']};
function hexToHsl(hex){let x=hex.replace('#','');if(x.length===8)x=x.slice(0,6);if(x.length===3)x=x.split('').map(v=>v+v).join('');let r=parseInt(x.slice(0,2),16)/255,g=parseInt(x.slice(2,4),16)/255,b=parseInt(x.slice(4,6),16)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,l=(max+min)/2,s=0,hh=0;if(d){s=d/(1-Math.abs(2*l-1));switch(max){case r:hh=60*(((g-b)/d)%6);break;case g:hh=60*((b-r)/d+2);break;default:hh=60*((r-g)/d+4)}}if(hh<0)hh+=360;return[Math.round(hh),Math.round(s*100),Math.round(l*100)]}
function hslToRgb(h,s,l){h=+h/360;s=+s/100;l=+l/100;let c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h*6)%2-1)),m=l-c/2,r=0,g=0,b=0,q=h*6;if(q<1){r=c;g=x}else if(q<2){r=x;g=c}else if(q<3){g=c;b=x}else if(q<4){g=x;b=c}else if(q<5){r=x;b=c}else{r=c;b=x}return[r,g,b].map(v=>Math.round((v+m)*255))}
function hslToHex(h,s,l){return '#'+hslToRgb(h,s,l).map(v=>v.toString(16).padStart(2,'0')).join('')}
function hslToCss(h,s,l,a=100){const[r,g,b]=hslToRgb(h,s,l);return a>=100?hslToHex(h,s,l):`rgba(${r},${g},${b},${(a/100).toFixed(2)})`}
function colorTokens(code){const re=/#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/g,out=[];let m;while((m=re.exec(code)))out.push({value:m[0].toUpperCase(),index:m.index,occurrence:out.filter(x=>x.value===m[0].toUpperCase()).length+1});return out}
function replaceOccurrence(code,token,occurrence,replacement){const re=new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi');let n=0;return code.replace(re,m=>(++n===occurrence?replacement:m))}
function addGradient(code,token,occurrence,stops,angle,type){if(!/h\(\s*['"]svg['"]/.test(code))throw new Error('Gradient editor membutuhkan scene SVG 2D.');const id='nawGradient1';let c=replaceOccurrence(code,token,occurrence,`url(#${id})`);const stopCode=stops.map(s=>`h('stop',{offset:'${s.pos}%',stopColor:'${s.color}'})`).join(',');const grad=type==='radial'?`h('radialGradient',{id:'${id}'},${stopCode})`:`h('linearGradient',{id:'${id}',x1:'0%',y1:'0%',x2:'100%',y2:'0%',gradientTransform:'rotate(${angle} .5 .5)'},${stopCode})`;if(/h\(\s*['"]defs['"]\s*,\s*null\s*,/.test(c))return c.replace(/h\(\s*(['"])defs\1\s*,\s*null\s*,/,(m)=>m+grad+',');const svg=/h\(\s*(['"])svg\1\s*,\s*\{[\s\S]*?\}\s*,/m;if(!svg.test(c))throw new Error('Root SVG tidak ditemukan.');return c.replace(svg,m=>m+`h('defs',null,${grad}),`) }
function timestampName(){const d=new Date();const p=n=>String(n).padStart(2,'0');const ms=String(d.getMilliseconds()).padStart(3,'0');return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${ms}.mp4`}
function bitrateFor(res,fps){return Math.round((res>=2160?40000000:res>=1440?24000000:14000000)*(fps/30))}
function proresSourceBitrateFor(res,fps){return Math.round((res>=2160?80000000:res>=1440?50000000:30000000)*(fps/30))}

function Preview({Scene,error,code,ratio,res,fps,dur,frame,setFrame,playing,setPlaying,busy,msg,fsSupported,fs,toggleFs,player,t}){const preview=useMemo(()=>size(ratio,720),[ratio]);const frames=Math.max(1,Math.round(dur*fps));return <><div className="stage rise" style={{'--i':1}}><div className="badge l"><span className="dot"/>{t('viewport')}</div><div className="badge r">{RES[res]} · {ratio}</div>{fsSupported&&<button className="fsbtn" onClick={toggleFs}>{fs?'⤡':'⛶'}</button>}{busy&&<div className="loading"><div className="spin"/><span>{msg}</span></div>}<div className="view" onClick={()=>player.current?.toggle()}>{Scene?<Boundary code={code}><Player ref={player} component={Scene} durationInFrames={frames} fps={fps} compositionWidth={preview.width} compositionHeight={preview.height} style={{width:'100%',height:'100%'}} loop autoPlay acknowledgeRemotionLicense/></Boundary>:<div className="err">Error kode: {error}</div>}</div></div><div className="timeline rise" style={{'--i':2}}><button className="play" onClick={()=>player.current?.toggle()}>{playing?'❚❚':'▶'}</button><span className="time">{(frame/fps).toFixed(2)}s</span><input type="range" min={0} max={frames-1} value={Math.min(frame,frames-1)} onChange={e=>{player.current?.pause();player.current?.seekTo(+e.target.value)}}/><span className="time d">{dur.toFixed(2)}s</span></div></>}

function VisualEditor({Scene,error,ratio,res,fps,dur,frame,setFrame,playing,setPlaying,busy,player,t,selected,setSelected,overrides,setOverrides,editorVersion,setEditorVersion}){
 const preview=useMemo(()=>size(ratio,720),[ratio]);
 const frames=Math.max(1,Math.round(dur*fps));
 const stageRef=useRef(null);
 const [box,setBox]=useState(null);
 const [objects,setObjects]=useState([]);
 const historyRef=useRef([]);
 const draggingRef=useRef(null);
 const selectedOv=selected?(overrides[selected.id]||{}):{};

 const commitOverrides=(updater)=>{
   setOverrides(prev=>{
     const next=typeof updater==='function'?updater(prev):updater;
     if(JSON.stringify(next)!==JSON.stringify(prev)) historyRef.current=[prev,...historyRef.current].slice(0,50);
     return next;
   });
   setEditorVersion(v=>v+1);
 };

 const setOv=(patch)=>{
   if(!selected)return;
   const current=overrides[selected.id]||{};
   if(current.locked&&!Object.prototype.hasOwnProperty.call(patch,'locked'))return;
   commitOverrides(prev=>({...prev,[selected.id]:{...(prev[selected.id]||{}),...patch}}));
 };

 const undo=()=>{
   const previous=historyRef.current.shift();
   if(previous===undefined)return;
   setOverrides(previous);
   setEditorVersion(v=>v+1);
 };

 const refresh=()=>{
   if(!stageRef.current){setObjects([]);return}
   const els=Array.from(stageRef.current.querySelectorAll('[data-naw-object-id]'));
   setObjects(els.map(el=>({
     id:el.getAttribute('data-naw-object-id'),
     type:el.getAttribute('data-naw-object-type'),
     label:el.getAttribute('data-naw-object-label')||el.getAttribute('data-naw-object-type')+' #'+(el.getAttribute('data-naw-object-id')||'').split('-').pop()
   })));
 };

 const updateBox=()=>{
   if(!selected||!stageRef.current){setBox(null);return}
   const els=stageRef.current.querySelectorAll('[data-naw-object-id]');
   const el=Array.from(els).find(x=>x.getAttribute('data-naw-object-id')===selected.id);
   if(!el){setBox(null);return}
   const a=el.getBoundingClientRect(),b=stageRef.current.getBoundingClientRect();
   setBox({left:a.left-b.left,top:a.top-b.top,width:a.width,height:a.height});
 };

 useEffect(()=>{
   refresh(); updateBox();
   const id=setTimeout(()=>{refresh();updateBox()},80);
   return()=>clearTimeout(id);
 },[selected,frame,editorVersion,Scene]);

 useEffect(()=>{
   const pl=player.current;if(!pl)return;
   const f=e=>setFrame(e.detail.frame),a=()=>setPlaying(true),b=()=>setPlaying(false);
   pl.addEventListener('frameupdate',f);pl.addEventListener('play',a);pl.addEventListener('pause',b);
   return()=>{pl.removeEventListener('frameupdate',f);pl.removeEventListener('play',a);pl.removeEventListener('pause',b)}
 },[player,Scene]);

 useEffect(()=>{
   const onKey=e=>{
     if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!busy){
       e.preventDefault();undo();
     }
   };
   window.addEventListener('keydown',onKey);
   return()=>window.removeEventListener('keydown',onKey);
 },[busy,overrides]);

 const beginDrag=e=>{
   if(!selected||busy)return;
   if(selectedOv.locked)return;
   e.preventDefault(); e.stopPropagation();
   const stage=stageRef.current;if(!stage)return;
   const r=stage.getBoundingClientRect();
   historyRef.current=[overrides,...historyRef.current].slice(0,50);
   draggingRef.current={
     startX:e.clientX,startY:e.clientY,
     x:Number(selectedOv.x||0),y:Number(selectedOv.y||0),
     sx:preview.width/r.width,sy:preview.height/r.height
   };
   try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}
 };

 const moveDrag=e=>{
   const d=draggingRef.current;if(!d)return;
   e.preventDefault();e.stopPropagation();
   const nx=d.x+(e.clientX-d.startX)*d.sx;
   const ny=d.y+(e.clientY-d.startY)*d.sy;
   setOverrides(prev=>({...prev,[selected.id]:{...(prev[selected.id]||{}),x:Math.round(nx),y:Math.round(ny)}}));
   setEditorVersion(v=>v+1);
 };

 const endDrag=e=>{
   if(!draggingRef.current)return;
   draggingRef.current=null;
   try{e.currentTarget.releasePointerCapture(e.pointerId)}catch{}
 };

 const reset=()=>{if(!selected)return;commitOverrides(prev=>{const n={...prev};delete n[selected.id];return n})};
 const remove=()=>setOv({hidden:true});
 const duplicate=()=>setOv({duplicate:true});
 const label=selected?.label||'';
 const fill=typeof selectedOv.fill==='string'&&/^#[0-9a-f]{6}$/i.test(selectedOv.fill)?selectedOv.fill:'#ff7a00';
 const stroke=typeof selectedOv.stroke==='string'&&/^#[0-9a-f]{6}$/i.test(selectedOv.stroke)?selectedOv.stroke:'#ffffff';

 return <><div className="editor-toolbar">
   <span className="editmode">✦ VISUAL EDITOR</span>
   <button onClick={()=>setSelected(null)}>CLEAR</button>
   <button onClick={undo} disabled={!historyRef.current.length||busy}>UNDO</button>
   <button onClick={reset} disabled={!selected}>RESET</button>
 </div>
 <div className="object-strip">{objects.slice(0,24).map(o=><button key={o.id} className={selected?.id===o.id?'on':''} onClick={()=>setSelected(o)}>{o.type} #{o.id.split('-').pop()}</button>)}</div>
 <div className="stage editor-stage" ref={stageRef}>
   <div className="badge l"><span className="dot"/>{t('visualEditor')}</div>
   <div className="badge r">{RES[res]} · {ratio}</div>
   {busy&&<div className="loading"><div className="spin"/><span>{t('rendering')}</span></div>}
   <div className="view editor-view" onClick={()=>setSelected(null)}>
     {Scene?<Boundary code={String(editorVersion)}><Player ref={player} component={Scene} inputProps={{nawEditorVersion:editorVersion}} durationInFrames={frames} fps={fps} compositionWidth={preview.width} compositionHeight={preview.height} style={{width:'100%',height:'100%',pointerEvents:'auto'}} loop autoPlay acknowledgeRemotionLicense/></Boundary>:<div className="err">Error kode: {error}</div>}
     {box&&<div className="selection-box" onPointerDown={beginDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} style={{left:box.left,top:box.top,width:box.width,height:box.height,cursor:selectedOv.locked?'not-allowed':'move',touchAction:'none'}}>
       <i className="handle tl"/><i className="handle tr"/><i className="handle bl"/><i className="handle br"/><span>{label}</span>
     </div>}
   </div>
 </div>
 <div className="timeline rise" style={{'--i':2}}>
   <button className="play" onClick={()=>player.current?.toggle()}>{playing?'❚❚':'▶'}</button>
   <span className="time">{(frame/fps).toFixed(2)}s</span>
   <input type="range" min={0} max={frames-1} value={Math.min(frame,frames-1)} onChange={e=>{player.current?.pause();player.current?.seekTo(+e.target.value)}}/>
   <span className="time d">{dur.toFixed(2)}s</span>
 </div>
 {selected?<div className="card visual-panel">
   <div className="row"><div><div className="title">{label}</div><div className="msg">{selected.type} · {selected.id}</div></div><div className="object-actions"><button onClick={remove}>Delete</button><button onClick={()=>setOv({hidden:true})}>Hide</button></div></div>
   <div className="visual-grid"><label>X<input type="number" value={selectedOv.x||0} onChange={e=>setOv({x:+e.target.value})}/></label><label>Y<input type="number" value={selectedOv.y||0} onChange={e=>setOv({y:+e.target.value})}/></label><label>Scale<input type="number" step="0.05" min="0.05" value={selectedOv.scale==null?1:selectedOv.scale} onChange={e=>setOv({scale:+e.target.value})}/></label><label>Rotate<input type="number" value={selectedOv.rotation||0} onChange={e=>setOv({rotation:+e.target.value})}/></label></div>
   <div className="slider-row"><label>Opacity</label><input type="range" min="0" max="1" step="0.01" value={selectedOv.opacity==null?1:selectedOv.opacity} onChange={e=>setOv({opacity:+e.target.value})}/><b>{Math.round((selectedOv.opacity==null?1:selectedOv.opacity)*100)}%</b></div>
   <div className="color-edit-row"><label>Fill</label><input type="color" value={fill} onChange={e=>setOv({fill:e.target.value})}/><code>{fill}</code><label>Stroke</label><input type="color" value={stroke} onChange={e=>setOv({stroke:e.target.value})}/><code>{stroke}</code></div>
   <div className="btns"><button className="btn" onClick={duplicate}>DUPLICATE</button><button className="btn o" onClick={()=>setOv({duplicateOffsetX:40,duplicateOffsetY:40,duplicate:true})}>DUPLICATE + MOVE</button></div>
   <div className="btns"><button className="btn" onClick={()=>setOv({locked:!selectedOv.locked})}>{selectedOv.locked?'UNLOCK OBJECT':'LOCK OBJECT'}</button><button className="btn o" onClick={()=>setOv({z:(selectedOv.z||0)+1})}>BRING FRONT</button><button className="btn o" onClick={()=>setOv({z:(selectedOv.z||0)-1})}>SEND BACK</button></div>
 </div>:<div className="card visual-empty"><b>{t('selectObject')}</b><p>{t('selectObjectHint')}</p></div>}
</>
}

export default function App({t,onBack,themeIcon,toggleTheme,fs,fsSupported,toggleFs}){
 const [tab,setTab]=useState('studio'),[code,setCode]=useState(DEFAULT_2D),[draft,setDraft]=useState(DEFAULT_2D);
 const [baseCode,setBaseCode]=useState(()=>localStorage.getItem('naw_scene_base')||''),[sceneLocked,setSceneLocked]=useState(()=>localStorage.getItem('naw_scene_locked')==='1');
 const [ratio,setRatio]=useState('16:9'),[res,setRes]=useState(1080),[fps,setFps]=useState(30),[dur,setDur]=useState(10),[codec,setCodec]=useState('h264'),[alphaMode,setAlphaMode]=useState('solid');
 const [msg,setMsg]=useState(''),[busy,setBusy]=useState(false),[prog,setProg]=useState(0),[frame,setFrame]=useState(0),[playing,setPlaying]=useState(true),[files,setFiles]=useState(loadFiles);
 const [palette,setPalette]=useState('Basic'),[selectedColor,setSelectedColor]=useState(null),[colorMode,setColorMode]=useState('solid'),[hsl,setHsl]=useState([0,100,50]),[alpha,setAlpha]=useState(100),[gradType,setGradType]=useState('linear'),[gradAngle,setGradAngle]=useState(135),[stops,setStops]=useState([{pos:0,color:'#00A8FF'},{pos:50,color:'#7C3AED'},{pos:100,color:'#FF0055'}]);
 const player=useRef(null); const editorPlayer=useRef(null);
 const [selectedObject,setSelectedObject]=useState(null),[editorOverrides,setEditorOverrides]=useState({}),[editorVersion,setEditorVersion]=useState(0),[editorObjects,setEditorObjects]=useState([]);
 const editorCtl=useRef({nextId:0,overrides:{},select:()=>{},register:()=>{}}).current; editorCtl.overrides=editorOverrides; editorCtl.select=setSelectedObject; editorCtl.register=o=>{if(!editorCtl.objectsById)editorCtl.objectsById={};editorCtl.objectsById[o.id]=o};
 const {Scene,error}=useMemo(()=>{try{return{Scene:compile(code),error:''}}catch(e){return{Scene:null,error:e.message}}},[code]);const editorScene=useMemo(()=>{try{return{Scene:compileEditor(code,editorCtl),error:''}}catch(e){return{Scene:null,error:e.message}}},[code,editorCtl]);const frames=Math.max(1,Math.round(dur*fps));const colors=useMemo(()=>colorTokens(code),[code]);
 useEffect(()=>saveFiles(files),[files]);useEffect(()=>{if(baseCode)localStorage.setItem('naw_scene_base',baseCode);else localStorage.removeItem('naw_scene_base')},[baseCode]);useEffect(()=>localStorage.setItem('naw_scene_locked',sceneLocked?'1':'0'),[sceneLocked]);
 useEffect(()=>{const pl=player.current;if(!pl)return;const f=e=>setFrame(e.detail.frame),a=()=>setPlaying(true),b=()=>setPlaying(false);pl.addEventListener('frameupdate',f);pl.addEventListener('play',a);pl.addEventListener('pause',b);return()=>{pl.removeEventListener('frameupdate',f);pl.removeEventListener('play',a);pl.removeEventListener('pause',b)}},[Scene,frames,tab]);
 const apply=c=>{setCode(c);setDraft(c);setSelectedObject(null);setEditorOverrides({});setEditorVersion(v=>v+1)};const addFile=(name,c)=>setFiles(a=>a.some(f=>!f.trashed&&f.code===c)?a:[newFile(name,'2d',c),...a]);
 const baseFirst=()=>{if(!baseCode){setBaseCode(code);setSceneLocked(true);setMsg('Base scene locked locally.')}};
 const clearCode=()=>{setCode('');setDraft('');setMsg('Code deleted.');};
 const copyCode=async()=>{try{await navigator.clipboard.writeText(draft);setMsg(t('copied'))}catch{setMsg(t('pasteFail'))}};const pasteCode=async()=>{try{const x=await navigator.clipboard.readText();if(x)setDraft(x)}catch{setMsg(t('pasteFail'))}};
 const exportVideo=async()=>{const activeScene=Object.keys(editorOverrides).length?editorScene.Scene:Scene;if(!activeScene)return setMsg(t('fixCode'));const {width,height}=size(ratio,res);const isAlpha=alphaMode==='transparent';if(isAlpha&&codec!=='prores')setCodec('prores');const isProRes=codec==='prores';const frames=Math.max(1,Math.round(dur*fps));const stamp=timestampName().replace(/\.mp4$/,'');const name=isAlpha?`${stamp}_ProRes4444_Alpha.mov`:isProRes?`${stamp}_ProRes422LT.mov`:`${stamp}.mp4`;setBusy(true);setProg(0);setMsg(t('preparing'));let inputStarted=false;try{
  if(isAlpha){
    setMsg(t('encodingAlphaSource'));setProg(0.02);
    const {getBlob}=await renderMediaOnWeb({composition:{id:'scene-alpha',component:activeScene,durationInFrames:frames,fps,width,height},container:'webm',videoCodec:'vp9',videoBitrate:12000000,muted:true,transparent:true,keyframeIntervalInSeconds:1,licenseKey:'free-license',onProgress:p=>{const rendered=Number(p.renderedFrames||0);setProg(Math.min(.72,rendered/frames*.72));setMsg(`${t('encodingAlphaSource')} ${rendered}/${frames}`)}});
    const blob=await getBlob();setMsg(t('encodingAlphaProRes'));setProg(.74);await NativeRender.startInput({extension:'webm'});inputStarted=true;const bytes=new Uint8Array(await blob.arrayBuffer()),CHUNK_SIZE=256*1024;for(let offset=0;offset<bytes.length;offset+=CHUNK_SIZE){const endOffset=Math.min(offset+CHUNK_SIZE,bytes.length);const chunk=bytes.subarray(offset,endOffset);let binary='';for(let i=0;i<chunk.length;i+=0x8000)binary+=String.fromCharCode(...chunk.subarray(i,Math.min(i+0x8000,chunk.length)));await NativeRender.writeInputChunk({base64:btoa(binary)});setProg(.74+.08*(endOffset/bytes.length));}await NativeRender.finishInput();inputStarted=false;const r=await NativeRender.encodeToGallery({format:'prores-alpha',proresProfile:'4444',displayName:name});setProg(1);setMsg(`${t('saved')}: ${name} · ${(Number(r.size||0)/1048576).toFixed(1)} MB`);return;
  }
  const bitrate=isProRes?proresSourceBitrateFor(res,fps):bitrateFor(res,fps);const sourceName=`${stamp}_source.mp4`;setMsg(t('rendering'));const {getBlob}=await renderMediaOnWeb({composition:{id:'scene',component:activeScene,durationInFrames:frames,fps,width,height},container:'mp4',videoCodec:'h264',videoBitrate:bitrate,muted:true,keyframeIntervalInSeconds:1,licenseKey:'free-license',onProgress:p=>{const rendered=Number(p.renderedFrames||0);setProg(Math.min(isProRes?.55:.98,rendered/frames*(isProRes?.55:.98)));setMsg(`${isProRes?t('encodingSource'):t('rendering')} ${rendered}/${frames}`)}});const blob=await getBlob();if(isProRes){setMsg(t('encodingProRes'));setProg(.58);await NativeRender.startInput({extension:'mp4'});inputStarted=true;const bytes=new Uint8Array(await blob.arrayBuffer()),CHUNK_SIZE=256*1024;for(let offset=0;offset<bytes.length;offset+=CHUNK_SIZE){const endOffset=Math.min(offset+CHUNK_SIZE,bytes.length);const chunk=bytes.subarray(offset,endOffset);let binary='';for(let i=0;i<chunk.length;i+=0x8000)binary+=String.fromCharCode(...chunk.subarray(i,Math.min(i+0x8000,chunk.length)));await NativeRender.writeInputChunk({base64:btoa(binary)});setProg(.58+.12*(endOffset/bytes.length));}await NativeRender.finishInput();inputStarted=false;const r=await NativeRender.encodeToGallery({format:'prores',proresProfile:'lt',displayName:name});setProg(1);setMsg(`${t('saved')}: ${name} · ${(Number(r.size||0)/1048576).toFixed(1)} MB`);return;}const mb=Number(blob.size||0)/1048576;setMsg(`${t('saved')}: ${name} · ${mb.toFixed(1)} MB`);await NativeMedia.startVideoSave({displayName:name,mimeType:'video/mp4'});inputStarted=true;const bytes=new Uint8Array(await blob.arrayBuffer()),CHUNK_SIZE=256*1024;for(let offset=0;offset<bytes.length;offset+=CHUNK_SIZE){const endOffset=Math.min(offset+CHUNK_SIZE,bytes.length);const chunk=bytes.subarray(offset,endOffset);let binary='';for(let i=0;i<chunk.length;i+=0x8000)binary+=String.fromCharCode(...chunk.subarray(i,Math.min(i+0x8000,chunk.length)));await NativeMedia.writeVideoChunk({base64:btoa(binary)});setProg(.98+.02*(endOffset/bytes.length));}await NativeMedia.finishVideoSave();inputStarted=false;setProg(1);
 }catch(e){console.error(e);if(inputStarted)try{await NativeRender.abortInput()}catch{}setMsg('Error: '+(e?.message||e)+' — coba turunkan resolusi/fps.')}finally{setBusy(false)}};

 const selectColor=(token,occurrence,index)=>{setSelectedColor({token,occurrence,index});setColorMode('solid');setHsl(hexToHsl(token))};const applySolid=()=>{if(!selectedColor)return;const css=hslToCss(...hsl,alpha),next=replaceOccurrence(code,selectedColor.token,selectedColor.occurrence,css);apply(next);addFile(`Color edit ${css}`,next);setMsg('Color applied.')};const applyGradient=()=>{if(!selectedColor)return;try{const next=addGradient(code,selectedColor.token,selectedColor.occurrence,stops,gradAngle,gradType);apply(next);addFile('Gradient edit',next);setMsg('Gradient applied.')}catch(e){setMsg(e.message)}};
 const previewProps={Scene,error,code,ratio,res,fps,dur,frame,setFrame,playing,setPlaying,busy,msg,fsSupported,fs,toggleFs,player,t};
 return <div className="app"><div className="top"><div className="head rise" style={{'--i':0}}><button className="logo" onClick={onBack} aria-label="Home"><img src="/logo.png" alt="NAW Studio"/></button><div className="brand"><b>NAW <span>STUDIO</span></b><small>{t('tagShort')}</small></div><button className="iconbtn" onClick={toggleTheme} aria-label="Theme">{themeIcon}</button></div></div>
 {tab==='studio'&&<Preview {...previewProps}/>} 
 <div className="body"><div key={tab} className="pane">
 {tab==='studio'&&<>
  <div className="card"><div className="row"><div className="title"><i>✦</i> Scene · 2D</div><button className="link" onClick={()=>apply(DEFAULT_2D)}>{t('reset')}</button></div><div className="row"><div><strong>🔒 {t('sceneLocked')}</strong><div className="msg">{t('baseHint')}</div></div>{baseCode&&<button className="btn o" onClick={()=>apply(baseCode)}>{t('restore')}</button>}</div><div className="btns"><button className="btn" onClick={baseFirst}>Set Current as Base</button></div></div>
  <div className="card"><div className="row"><div className="title"><i>▣</i> {t('codeEdit')}</div><div className="ctools" style={{marginTop:0}}><button onClick={copyCode}>{t('copyAll')}</button><button onClick={pasteCode}>{t('paste')}</button></div></div><textarea className="code" rows={12} spellCheck={false} value={draft} onChange={e=>setDraft(e.target.value)}/><div className="btns"><button className="btn" onClick={()=>{apply(draft);if(!baseCode)baseFirst()}}>{t('applyCode')}</button><button className="btn o" onClick={()=>setDraft(code)}>{t('cancel')}</button><button className="btn dng" onClick={clearCode}>{t('deleteCode')}</button></div></div>
  <div className="card"><div className="row"><div className="title"><i>🎬</i> {t('render')}</div><div className="badge-static">{busy?'ACTIVE':'READY'}</div></div><div className="grid"><Opt label={t('res')}><select value={res} onChange={e=>setRes(+e.target.value)}><option value={1080}>1080p</option><option value={1440}>2K</option><option value={2160}>4K</option></select></Opt><Opt label={t('ratio')}><select value={ratio} onChange={e=>setRatio(e.target.value)}>{Object.keys(RATIOS).map(r=><option key={r}>{r}</option>)}</select></Opt><Opt label={t('fps')}><select value={fps} onChange={e=>setFps(+e.target.value)}><option value={24}>24 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></Opt><Opt label={t('dur')}><select value={dur} onChange={e=>setDur(+e.target.value)}><option value={5}>5 {t('sec')}</option><option value={8}>8 {t('sec')}</option><option value={10}>10 {t('sec')}</option><option value={15}>15 {t('sec')}</option></select></Opt></div><div className="row"><strong>{t('background')}</strong></div><div className="seg"><button className={alphaMode==='solid'?'on':''} onClick={()=>setAlphaMode('solid')}>{t('solidBackground')}</button><button className={alphaMode==='transparent'?'on':''} onClick={()=>{setAlphaMode('transparent');setCodec('prores')}}>{t('transparentBackground')}</button></div><div className="row"><strong>{t('codec')}</strong></div><div className="seg"><button disabled={alphaMode==='transparent'} className={codec==='h264'&&alphaMode==='solid'?'on':''} onClick={()=>setCodec('h264')}>{t('h264')}</button><button disabled={alphaMode==='transparent'} className={codec==='prores'&&alphaMode==='solid'?'on':''} onClick={()=>setCodec('prores')}>{t('prores')}</button>{alphaMode==='transparent'&&<button className="on">{t('proresAlpha')}</button>}</div><p className="msg">{alphaMode==='transparent'?t('alphaHint'):codec==='h264'?t('h264Hint'):t('proresHint')}</p><button className="btn big" disabled={busy} onClick={exportVideo}>{busy?t('rendering'):t('export')}</button>{(busy||prog>0)&&<div className="bar"><i style={{width:Math.round(prog*100)+'%'}}/></div>}<p className="msg">{msg}</p></div>
 </>}
 {tab==='editor'&&<><VisualEditor Scene={editorScene.Scene} error={editorScene.error} ratio={ratio} res={res} fps={fps} dur={dur} frame={frame} setFrame={setFrame} playing={playing} setPlaying={setPlaying} busy={busy} player={editorPlayer} t={t} selected={selectedObject} setSelected={setSelectedObject} overrides={editorOverrides} setOverrides={setEditorOverrides} editorVersion={editorVersion} setEditorVersion={setEditorVersion}/><div className="card"><div className="row"><div className="title"><i>🎨</i> {t('colorEditor')}</div><div className="seg mini" style={{margin:0}}><button className={colorMode==='solid'?'on':''} onClick={()=>setColorMode('solid')}>{t('solid')}</button><button className={colorMode==='gradient'?'on':''} onClick={()=>setColorMode('gradient')}>{t('gradient')}</button></div></div><div className="msg">{selectedColor?`${t('target')}: ${selectedColor.token} · occurrence ${selectedColor.occurrence}`:t('noColor')}</div><div className="palette-title">{t('palette')}</div><div className="swatches">{PALETTES[palette].map(c=><button key={c} className="swatch" style={{background:c}} aria-label={c} onClick={()=>{setHsl(hexToHsl(c));setAlpha(100)}}/>)}</div><div className="seg mini"><button className={palette==='Basic'?'on':''} onClick={()=>setPalette('Basic')}>Basic</button><button className={palette==='Pastel'?'on':''} onClick={()=>setPalette('Pastel')}>Pastel</button><button className={palette==='Neon'?'on':''} onClick={()=>setPalette('Neon')}>Neon</button><button className={palette==='Cinematic'?'on':''} onClick={()=>setPalette('Cinematic')}>Cine</button><button className={palette==='Medical'?'on':''} onClick={()=>setPalette('Medical')}>Medical</button></div><div className="color-list">{colors.map((c,i)=><button key={`${c.index}-${i}`} className={'color-row '+(selectedColor?.index===c.index?'on':'')} onClick={()=>selectColor(c.value,c.occurrence,c.index)}><span className="color-dot" style={{background:c.value}}/><span>{c.value}</span><small>#{c.occurrence}</small></button>)}</div>{selectedColor&&colorMode==='solid'&&<><div className="slider-row"><label>{t('hue')}</label><input type="range" min="0" max="360" value={hsl[0]} onChange={e=>setHsl([+e.target.value,hsl[1],hsl[2]])}/><b>{hsl[0]}°</b></div><div className="slider-row"><label>{t('sat')}</label><input type="range" min="0" max="100" value={hsl[1]} onChange={e=>setHsl([hsl[0],+e.target.value,hsl[2]])}/><b>{hsl[1]}%</b></div><div className="slider-row"><label>{t('light')}</label><input type="range" min="0" max="100" value={hsl[2]} onChange={e=>setHsl([hsl[0],hsl[1],+e.target.value])}/><b>{hsl[2]}%</b></div><div className="slider-row"><label>{t('alpha')}</label><input type="range" min="0" max="100" value={alpha} onChange={e=>setAlpha(+e.target.value)}/><b>{alpha}%</b></div><div className="color-preview" style={{background:hslToCss(...hsl,alpha)}}><code>{hslToCss(...hsl,alpha)}</code></div><button className="btn big" onClick={applySolid}>{t('apply')}</button></>}{selectedColor&&colorMode==='gradient'&&<><div className="grid"><Opt label={t('gradientType')}><select value={gradType} onChange={e=>setGradType(e.target.value)}><option value="linear">{t('linear')}</option><option value="radial">{t('radial')}</option></select></Opt><Opt label={t('angle')}><input type="number" min="0" max="360" value={gradAngle} onChange={e=>setGradAngle(+e.target.value)}/></Opt></div><div className="gradient-preview" style={{background:gradType==='radial'?`radial-gradient(circle,${stops.map(s=>s.color+' '+s.pos+'%').join(',')})`:`linear-gradient(${gradAngle}deg,${stops.map(s=>s.color+' '+s.pos+'%').join(',')})`}}/><div className="stops">{stops.map((s,i)=><div className="stop-row" key={i}><input type="color" value={s.color} onChange={e=>setStops(p=>p.map((x,j)=>j===i?{...x,color:e.target.value}:x))}/><input type="range" min="0" max="100" value={s.pos} onChange={e=>setStops(p=>p.map((x,j)=>j===i?{...x,pos:+e.target.value}:x))}/><b>{s.pos}%</b>{stops.length>2&&<button className="link" onClick={()=>setStops(p=>p.filter((_,j)=>j!==i))}>×</button>}</div>)}<button className="btn o" onClick={()=>setStops(p=>[...p,{pos:50,color:'#ffffff'}])}>{t('addStop')}</button></div><button className="btn big" onClick={applyGradient}>{t('apply')}</button><p className="msg">{t('gradient2d')}</p></>}</div></>}
 </div></div><nav className="tabbar">{[['studio','tabStudio'],['editor','tabEditor']].map(([k,l])=><button key={k} className={'tab '+(tab===k?'on':'')} onClick={()=>setTab(k)}><Ico n={k}/><span>{t(l)}</span></button>)}</nav></div>
}

function FilesPanel({t,files,setFiles,onOpen}){const [sub,setSub]=useState('gen');const [q,setQ]=useState('');const gen=files.filter(f=>!f.trashed),trash=files.filter(f=>f.trashed),list=(sub==='gen'?gen:trash).filter(f=>!q||String(f.name||'').toLowerCase().includes(q.toLowerCase()));const upd=(id,p)=>setFiles(a=>a.map(f=>f.id===id?{...f,...p}:f));const del=id=>setFiles(a=>a.filter(f=>f.id!==id));const rename=f=>{const n=window.prompt(t('renamePrompt'),f.name);if(n&&n.trim())upd(f.id,{name:n.trim().slice(0,60)})};return <div className="card" style={{marginTop:0}}><div className="seg" style={{marginTop:4}}><button className={sub==='gen'?'on':''} onClick={()=>setSub('gen')}>📁 {t('filesGen')} ({gen.length})</button><button className={sub==='trash'?'on':''} onClick={()=>setSub('trash')}>🗑 {t('filesTrash')} ({trash.length})</button></div>{sub==='trash'&&<p className="msg">{t('trashNote')}</p>}<input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search scenes..."/>{list.length?list.map(f=><div className="file" key={f.id}><div className="thumb m2d"><span>2D</span></div><div className="finfo"><b>{f.name}</b><small>{new Date(f.ts).toLocaleDateString()} · 2D</small><div className="facts">{sub==='gen'?<><button onClick={()=>onOpen(f)}>{t('open')}</button><button onClick={()=>rename(f)}>{t('rename')}</button><button className="dng" onClick={()=>upd(f.id,{trashed:true,trashedAt:Date.now()})}>{t('del')}</button></>:<><button onClick={()=>upd(f.id,{trashed:false,trashedAt:null})}>{t('restore')}</button><button className="dng" onClick={()=>del(f.id)}>{t('delForever')}</button></>}</div></div></div>):<div className="empty">{sub==='gen'?t('emptyGen'):t('emptyTrash')}</div>}</div>}
