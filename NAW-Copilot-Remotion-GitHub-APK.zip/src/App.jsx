import React, { useEffect, useMemo, useRef, useState } from 'react';
import '@fontsource/inter/400.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';
import '@fontsource/fira-code/400.css';
import './index.css';
import { Player } from '@remotion/player';
import { renderMediaOnWeb } from '@remotion/web-renderer';
import { useCurrentFrame, useVideoConfig, interpolate, spring } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import * as THREE from 'three';
import { DEFAULT_2D, DEFAULT_3D } from './defaults.js';
import { askGemini, chatGemini } from './gemini.js';
import { loadFiles, saveFiles, loadChat, saveChat, newFile } from './store.js';
import { fileToRef, MAX_ITEMS } from './refs.js';
import Chat from './Chat.jsx';
import Files from './Files.jsx';

const h = React.createElement;
const RATIOS = { '16:9': [16, 9], '9:16': [9, 16], '1:1': [1, 1], '3:4': [3, 4], '4:3': [4, 3] };
const even = (n) => Math.max(2, Math.round(n / 2) * 2);
const size = (ratio, short) => { const [w, hh] = RATIOS[ratio]; return w >= hh ? { width: even(short * w / hh), height: even(short) } : { width: even(short), height: even(short * hh / w) }; };

function compile(code) {
  const fn = new Function('React', 'h', 'useCurrentFrame', 'useVideoConfig', 'interpolate', 'spring', 'ThreeCanvas', 'THREE',
    '"use strict";\n' + code + '\n;return typeof Scene === "function" ? Scene : null;');
  const S = fn(React, h, useCurrentFrame, useVideoConfig, interpolate, spring, ThreeCanvas, THREE);
  if (!S) throw new Error('Kode harus mendefinisikan function Scene()');
  return S;
}

class Boundary extends React.Component {
  state = { err: null };
  static getDerivedStateFromError(err) { return { err }; }
  componentDidUpdate(prev) { if (prev.code !== this.props.code && this.state.err) this.setState({ err: null }); }
  render() { return this.state.err ? h('div', { className: 'err' }, 'Error scene: ' + this.state.err.message) : this.props.children; }
}

const Opt = ({ label, children }) => <div className="opt"><label>{label}</label>{children}</div>;
const RES = { 1080: '1080p', 1440: '2K', 2160: '4K' };
const P = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.9, strokeLinecap: 'round', strokeLinejoin: 'round' };
const Ico = ({ n }) => (
  <svg width="26" height="26" viewBox="0 0 24 24" {...P}>
    {n === 'studio' && <><rect x="3" y="5" width="18" height="14" rx="3" /><path d="M10 9.5v5l4.5-2.5z" /></>}
    {n === 'chat' && <path d="M12 3.5a8.5 8.5 0 1 0 4.2 15.9l4.3 1.1-1.2-3.9A8.5 8.5 0 0 0 12 3.5z" />}
    {n === 'files' && <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17z" />}
  </svg>
);

export default function App({ t, lang, setLang, onBack, themeIcon, toggleTheme, fs, fsSupported, toggleFs }) {
  const [tab, setTab] = useState('studio');
  const [mode, setMode] = useState('2d');
  const [code, setCode] = useState(DEFAULT_2D);
  const [draft, setDraft] = useState(DEFAULT_2D);
  const [prompt, setPrompt] = useState('');
  const [keysText, setKeysText] = useState(() => localStorage.getItem('naw_keys') || '');
  const [keyIdx, setKeyIdx] = useState(0);
  const [showKeys, setShowKeys] = useState(false);
  const [ratio, setRatio] = useState('16:9');
  const [res, setRes] = useState(1080);
  const [fps, setFps] = useState(30);
  const [dur, setDur] = useState(10);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState(false);
  const [prog, setProg] = useState(0);
  const [frame, setFrame] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [files, setFiles] = useState(loadFiles);
  const [chat, setChat] = useState(loadChat);
  const [chatInput, setChatInput] = useState('');
  const [chatBusy, setChatBusy] = useState(false);
  const [chatStatus, setChatStatus] = useState('');
  const [refs, setRefs] = useState([]);
  const [chatRefs, setChatRefs] = useState([]);
  const [reading, setReading] = useState(false);
  const refIn = useRef(null);
  const player = useRef(null);

  const { Scene, error } = useMemo(() => { try { return { Scene: compile(code), error: '' }; } catch (e) { return { Scene: null, error: e.message }; } }, [code]);
  const preview = useMemo(() => size(ratio, 720), [ratio]);
  const frames = Math.max(1, Math.round(dur * fps));
  const keys = keysText.split('\n').map((k) => k.trim()).filter(Boolean);

  useEffect(() => { saveFiles(files); }, [files]);
  useEffect(() => { saveChat(chat); }, [chat]);
  useEffect(() => {
    const pl = player.current; if (!pl) return;
    const f = (e) => setFrame(e.detail.frame), a = () => setPlaying(true), b = () => setPlaying(false);
    pl.addEventListener('frameupdate', f); pl.addEventListener('play', a); pl.addEventListener('pause', b);
    return () => { pl.removeEventListener('frameupdate', f); pl.removeEventListener('play', a); pl.removeEventListener('pause', b); };
  }, [Scene, frames, tab]);

  const apply = (c) => { setCode(c); setDraft(c); };
  const switchMode = (m) => { setMode(m); apply(m === '3d' ? DEFAULT_3D : DEFAULT_2D); };
  const saveKeys = (v) => { setKeysText(v); localStorage.setItem('naw_keys', v); };
  const toggle = () => player.current && player.current.toggle();
  const addRefs = (setter, current) => async (fileList) => {
    const list = [...fileList]; if (!list.length) return;
    setReading(true); const added = [];
    try { for (const f of list) { if (current.length + added.length >= MAX_ITEMS) { window.alert(t('refMax')); break; } added.push(await fileToRef(f)); } }
    catch (e) { window.alert(t('refErr') + (e?.message ? ' (' + e.message + ')' : '')); }
    finally { if (added.length) setter((p) => [...p, ...added].slice(0, MAX_ITEMS)); setReading(false); }
  };
  const copyCode = async () => { try { await navigator.clipboard.writeText(draft); setMsg(t('copied')); } catch { /* abaikan */ } };
  const pasteCode = async () => { try { const x = await navigator.clipboard.readText(); if (x) setDraft(x); } catch { window.alert(t('pasteFail')); } };
  const addFile = (p, m, c) => setFiles((a) => (a.some((f) => !f.trashed && f.code === c) ? a : [newFile(p, m, c), ...a]));

  const run = async (current, label) => {
    if (!keys.length) { setShowKeys(true); return setMsg(t('needKey')); }
    if (!prompt.trim() && !refs.length) return setMsg(t('needPrompt'));
    const p = prompt.trim() || t('refDefault');
    setAi(true); setMsg(label);
    try {
      const r = await askGemini({ keys, startIndex: keyIdx % keys.length, mode, prompt: p, current, onStatus: setMsg, refs });
      setKeyIdx(r.keyIndex); compile(r.code); apply(r.code); addFile(p, mode, r.code); setMsg(t('applied'));
    } catch (e) { setMsg('Gagal: ' + e.message); } finally { setAi(false); }
  };

  const sendChat = async () => {
    const text = chatInput.trim() || (chatRefs.length ? t('refDefault') : '');
    if (!text || chatBusy) return;
    const sendRefs = chatRefs;
    if (!keys.length) { setShowKeys(true); return; }
    const next = [...chat, { role: 'user', text, thumbs: sendRefs.map((r) => r.thumb) }];
    setChat(next); setChatRefs([]); setChatInput(''); setChatBusy(true); setChatStatus('');
    try {
      const r = await chatGemini({ keys, startIndex: keyIdx % keys.length, mode, history: next, currentCode: code, onStatus: setChatStatus, refs: sendRefs });
      setKeyIdx(r.keyIndex);
      const fence = /```(?:js|javascript)?\s*\n([\s\S]*?)```/.exec(r.text);
      const tail = !fence && r.text.includes('function Scene') ? r.text.slice(r.text.indexOf('function Scene')) : null;
      const c = (fence ? fence[1] : tail || '').trim();
      const m = { role: 'ai', text: r.text.replace(/```[\s\S]*$/, '').trim() };
      if (c) { try { compile(c); m.code = c; m.mode = mode; addFile(text, mode, c); } catch (e) { m.text += '\n⚠ ' + e.message; } }
      setChat([...next, m]);
    } catch (e) { setChat([...next, { role: 'ai', text: '⚠ ' + e.message }]); } finally { setChatBusy(false); setChatStatus(''); }
  };
  const applyFromChat = (m) => { setMode(m.mode || mode); apply(m.code); setTab('studio'); };
  const openFile = (f) => { setMode(f.mode); apply(f.code); setPrompt(f.prompt || ''); setTab('studio'); };

  const exportMp4 = async () => {
    if (!Scene) return setMsg(t('fixCode'));
    const { width, height } = size(ratio, res);
    const bitrate = Math.round((res >= 2160 ? 40e6 : res >= 1440 ? 24e6 : 14e6) * (fps / 30));
    setBusy(true); setProg(0); setMsg(t('preparing'));
    try {
      const { getBlob } = await renderMediaOnWeb({
        composition: { id: 'scene', component: Scene, durationInFrames: frames, fps, width, height },
        container: 'mp4', videoCodec: 'h264', videoBitrate: bitrate, muted: true, keyframeIntervalInSeconds: 2, licenseKey: 'free-license',
        onProgress: (p) => { setProg(p.renderedFrames / frames); setMsg(`Render frame ${p.renderedFrames}/${frames} (encode ${p.encodedFrames})`); },
      });
      const blob = await getBlob(); const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url;
      a.download = `NAW_Copilot_${mode}_${ratio.replace(':', 'x')}_${width}x${height}_${fps}fps.mp4`;
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 15000);
      setProg(1); setMsg(`${t('done')}: ${width}x${height} @ ${fps}fps (${(blob.size / 1048576).toFixed(1)} MB)`);
    } catch (e) { console.error(e); setMsg('Error: ' + (e?.message || e) + ' — coba turunkan resolusi/fps.'); } finally { setBusy(false); }
  };

  return (
    <div className="app">
      <div className="top">
        <div className="head rise" style={{ '--i': 0 }}>
          <button className="logo" onClick={onBack} aria-label="Home">NC</button>
          <div className="brand"><b>NAW <span>COPILOT</span></b><small>{t('tagShort')}</small></div>
          <button className="iconbtn" onClick={toggleTheme} aria-label="Theme">{themeIcon}</button>
          <button className="iconbtn" onClick={() => setShowKeys(true)} aria-label="API Key">🔑</button>
        </div>
        {tab === 'studio' && <>
          <div className="stage rise" style={{ '--i': 1 }}>
            <div className="badge l"><span className="dot" />{t('viewport')}</div>
            <div className="badge r">{RES[res]} · {ratio}</div>
            {fsSupported && <button className="fsbtn" onClick={toggleFs} aria-label="Fullscreen">{fs ? '⤡' : '⛶'}</button>}
            {ai && <div className="loading"><div className="spin" /><span>{msg}</span></div>}
            <div className="view" onClick={toggle}>
              {Scene ? <Boundary code={code}><Player ref={player} component={Scene} durationInFrames={frames} fps={fps} compositionWidth={preview.width} compositionHeight={preview.height}
                style={{ width: '100%', height: '100%' }} loop autoPlay acknowledgeRemotionLicense /></Boundary>
                : <div className="err">Error kode: {error}</div>}
            </div>
          </div>
          <div className="timeline rise" style={{ '--i': 2 }}>
            <button className="play" onClick={toggle}>{playing ? '❚❚' : '▶'}</button>
            <span className="time">{(frame / fps).toFixed(2)}s</span>
            <input type="range" min={0} max={frames - 1} value={Math.min(frame, frames - 1)} onChange={(e) => { player.current?.pause(); player.current?.seekTo(+e.target.value); }} />
            <span className="time d">{dur.toFixed(2)}s</span>
          </div>
        </>}
      </div>

      <div className={'body' + (tab === 'chat' ? ' chatbody' : '')}>
        <div key={tab} className="pane">
          {tab === 'studio' && <>
            <div className="card" style={{ marginTop: 0 }}>
              <div className="row"><div className="title"><i>✦</i> {t('copilot')}</div><button className="link" onClick={() => apply(mode === '3d' ? DEFAULT_3D : DEFAULT_2D)}>{t('reset')}</button></div>
              <div className="seg">{['2d', '3d'].map((m) => <button key={m} className={mode === m ? 'on' : ''} onClick={() => switchMode(m)}>{m === '2d' ? '2D · SVG' : '3D · Three.js'}</button>)}</div>
              <textarea className="ta" rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder={t('ph')} />
              <div className="refbar">
                <button className="btn o refadd" disabled={reading} onClick={() => refIn.current.click()}>＋ {t('addRef')}</button>
                <input ref={refIn} type="file" accept="image/*,video/*" multiple hidden onChange={(e) => { addRefs(setRefs, refs)(e.target.files); e.target.value = ''; }} />
                {reading && <span className="msg" style={{ margin: 0 }}>{t('refReading')}</span>}
                {prompt && <button className="link" style={{ marginLeft: 'auto' }} onClick={() => setPrompt('')}>✕ {t('clearAll')}</button>}
              </div>
              {refs.length > 0 && <>
                <div className="refs">{refs.map((r) => <div className="rchip" key={r.id}><img src={r.thumb} alt="" />{r.kind === 'video' && <em>▶</em>}<button onClick={() => setRefs((p) => p.filter((x) => x.id !== r.id))}>×</button></div>)}</div>
                <p className="msg" style={{ marginTop: 6 }}>{t('refNote')}</p>
              </>}
              <div className="btns">
                <button className="btn" disabled={ai || busy} onClick={() => run(null, t('writing'))}>{ai ? t('busyAi') : t('make')}</button>
                <button className="btn o" disabled={ai || busy} onClick={() => run(code, t('refining'))}>{t('refine')}</button>
              </div>
              <details><summary>{t('codeEdit')}</summary>
                <textarea className="code" rows={10} spellCheck={false} value={draft} onChange={(e) => setDraft(e.target.value)} />
                <div className="ctools">
                  <button onClick={copyCode}>{t('copyAll')}</button>
                  <button onClick={pasteCode}>{t('paste')}</button>
                  <button className="dng" onClick={() => setDraft('')}>{t('clearAll')}</button>
                </div>
                <div className="btns"><button className="btn" onClick={() => setCode(draft)}>{t('applyCode')}</button><button className="btn o" onClick={() => setDraft(code)}>{t('cancel')}</button></div>
              </details>
            </div>
            <div className="grid">
              <Opt label={t('res')}><select value={res} onChange={(e) => setRes(+e.target.value)}><option value={1080}>1080p (FHD)</option><option value={1440}>2K (QHD)</option><option value={2160}>4K (UHD)</option></select></Opt>
              <Opt label={t('ratio')}><select value={ratio} onChange={(e) => setRatio(e.target.value)}>{Object.keys(RATIOS).map((r) => <option key={r}>{r}</option>)}</select></Opt>
              <Opt label={t('fps')}><select value={fps} onChange={(e) => setFps(+e.target.value)}><option value={24}>24 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></Opt>
              <Opt label={t('dur')}><select value={dur} onChange={(e) => setDur(+e.target.value)}><option value={5}>5 {t('sec')}</option><option value={8}>8 {t('sec')}</option><option value={10}>10 {t('sec')}</option><option value={15}>15 {t('sec')}</option></select></Opt>
            </div>
            <div className="card" style={{ marginTop: 10 }}>
              <button className="btn big" disabled={busy || ai} onClick={exportMp4}>{busy ? t('rendering') : t('exportBtn')}</button>
              {(busy || prog > 0) && <div className="bar"><i style={{ width: Math.round(prog * 100) + '%' }} /></div>}
              <p className="msg">{msg}</p>
            </div>
          </>}
          {tab === 'chat' && <Chat t={t} chat={chat} input={chatInput} setInput={setChatInput} busy={chatBusy} status={chatStatus}
            onSend={sendChat} onApply={applyFromChat} refs={chatRefs} reading={reading} onAdd={addRefs(setChatRefs, chatRefs)} onRemoveRef={(id) => setChatRefs((p) => p.filter((x) => x.id !== id))} mode={mode} setMode={setMode} onClear={() => { if (!chat.length || window.confirm(t('clearChat') + '?')) setChat([]); }} />}
          {tab === 'files' && <Files t={t} lang={lang} files={files} setFiles={setFiles} onOpen={openFile} notify={(m) => { setMsg(m); window.alert(m); }} />}
        </div>
      </div>

      <nav className="tabbar">
        {[['studio', 'tabStudio'], ['chat', 'tabChat'], ['files', 'tabFiles']].map(([k, l]) => (
          <button key={k} className={'tab' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}><Ico n={k} /><span>{t(l)}</span></button>
        ))}
      </nav>

      {showKeys && <div className="sheet" onClick={() => setShowKeys(false)}><div className="card" onClick={(e) => e.stopPropagation()}>
        <div className="row"><div className="title"><i>🔑</i> {t('keyTitle')}</div><button className="link" onClick={() => setShowKeys(false)}>{t('close')}</button></div>
        <textarea className="ta" rows={4} value={keysText} onChange={(e) => saveKeys(e.target.value)} placeholder={t('keyPh')} />
        <p className="msg">{t('keyNote')}</p>
        <button className="btn big" onClick={() => setShowKeys(false)}>{t('save')}</button>
      </div></div>}
    </div>
  );
}
