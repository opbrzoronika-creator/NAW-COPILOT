import React, { useEffect, useMemo, useRef, useState } from 'react';
import '@fontsource/inter/400.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';
import '@fontsource/fira-code/400.css';
import './index.css';
import { Player } from '@remotion/player';
import { renderMediaOnWeb } from '@remotion/web-renderer';
import { useCurrentFrame, useVideoConfig, interpolate, spring } from 'remotion';
import { registerPlugin } from '@capacitor/core';
import { Input, ALL_FORMATS, BlobSource, Output, BufferTarget, Mp4OutputFormat, Conversion, canEncodeVideo } from 'mediabunny';
import { DEFAULT_2D } from './defaults.js';
import { loadFiles, saveFiles, newFile } from './store.js';

const NativeMedia = registerPlugin('NativeMedia', { web: {
  async startVideoSave(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async writeVideoChunk(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async finishVideoSave(){ throw new Error('Gallery saving is only available in the Android app.'); },
  async abortVideoSave(){},
  async addListener(){ return { remove(){} }; }
} });

const h=React.createElement;
const RATIOS={'16:9':[16,9],'9:16':[9,16],'1:1':[1,1],'3:4':[3,4],'4:3':[4,3]};
const RES={1080:'1080p',1440:'2K',2160:'4K'};
const even=n=>Math.max(2,Math.round(n/2)*2);
const size=(ratio,short)=>{const [w,hh]=RATIOS[ratio];return w>=hh?{width:even(short*w/hh),height:even(short)}:{width:even(short),height:even(short*hh/w)}};
function compile(code){const fn=new Function('React','h','useCurrentFrame','useVideoConfig','interpolate','spring','"use strict";\n'+code+'\n;return typeof Scene==="function"?Scene:null;');const S=fn(React,h,useCurrentFrame,useVideoConfig,interpolate,spring);if(!S)throw new Error('Kode harus mendefinisikan function Scene()');return S;}
class Boundary extends React.Component{state={err:null};static getDerivedStateFromError(err){return{err}}componentDidUpdate(p){if(p.code!==this.props.code&&this.state.err)this.setState({err:null})}render(){return this.state.err?h('div',{className:'err'},'Error scene: '+this.state.err.message):this.props.children}}
const Opt=({label,children})=><div className="opt"><label>{label}</label>{children}</div>;
const P={fill:'none',stroke:'currentColor',strokeWidth:1.9,strokeLinecap:'round',strokeLinejoin:'round'};
const Ico=({n})=><svg width="26" height="26" viewBox="0 0 24 24" {...P}>{n==='studio'&&<><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z"/></>}{n==='editor'&&<><path d="M4 19h16"/><path d="M6 16.5l8.8-8.8 3.5 3.5-8.8 8.8H6z"/><path d="M13.8 8.7l1.6-1.6a1.8 1.8 0 0 1 2.6 0l.9.9a1.8 1.8 0 0 1 0 2.6l-1.6 1.6"/></>}{n==='files'&&<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17z"/>}{n==='resize'&&<><path d="M7 7h10v10"/><path d="M17 7 7 17"/><path d="M5 19h14"/></>}</svg>;

const PALETTES={Basic:['#000000','#ffffff','#ff0000','#ff7a00','#ffd400','#00c853','#00b8ff','#2457ff','#7c3aed','#ff2d92'],Pastel:['#ffd6e7','#ffe5b4','#fff3a3','#c7f9cc','#bde0fe','#c8b6ff','#f1c0e8','#d9f99d','#bae6fd','#e9d5ff'],Neon:['#ff0055','#ff4d00','#ffe600','#00ff66','#00eaff','#4d5bff','#a100ff','#ff00cc','#7cff00','#00fff0'],Cinematic:['#0b1020','#172554','#1e3a8a','#312e81','#4c1d95','#7f1d1d','#9a3412','#b45309','#d4a017','#e5e7eb'],Medical:['#ffffff','#e5f2ff','#bde3ff','#63c5da','#00a8cc','#0077b6','#90be6d','#f94144','#f9c74f','#577590']};
function hexToHsl(hex){let x=hex.replace('#','');if(x.length===8)x=x.slice(0,6);if(x.length===3)x=x.split('').map(v=>v+v).join('');let r=parseInt(x.slice(0,2),16)/255,g=parseInt(x.slice(2,4),16)/255,b=parseInt(x.slice(4,6),16)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,l=(max+min)/2,s=0,hh=0;if(d){s=d/(1-Math.abs(2*l-1));switch(max){case r:hh=60*(((g-b)/d)%6);break;case g:hh=60*((b-r)/d+2);break;default:hh=60*((r-g)/d+4)}}if(hh<0)hh+=360;return[Math.round(hh),Math.round(s*100),Math.round(l*100)]}
function hslToRgb(h,s,l){h=+h/360;s=+s/100;l=+l/100;let c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h*6)%2-1)),m=l-c/2,r=0,g=0,b=0,q=h*6;if(q<1){r=c;g=x}else if(q<2){r=x;g=c}else if(q<3){g=c;b=x}else if(q<4){g=x;b=c}else if(q<5){r=x;b=c}else{r=c;b=x}return[r,g,b].map(v=>Math.round((v+m)*255))}
function hslToHex(h,s,l){return '#'+hslToRgb(h,s,l).map(v=>v.toString(16).padStart(2,'0')).join('')}
function hslToCss(h,s,l,a=100){const[r,g,b]=hslToRgb(h,s,l);return a>=100?hslToHex(h,s,l):`rgba(${r},${g},${b},${(a/100).toFixed(2)})`}
function colorTokens(code){const re=/#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/g,out=[];let m;while((m=re.exec(code)))out.push({value:m[0].toUpperCase(),index:m.index,occurrence:out.filter(x=>x.value===m[0].toUpperCase()).length+1});return out}
function replaceOccurrence(code,token,occurrence,replacement){const re=new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi');let n=0;return code.replace(re,m=>(++n===occurrence?replacement:m))}
function addGradient(code,token,occurrence,stops,angle,type){if(!/h\(\s*['"]svg['"]/.test(code))throw new Error('Gradient editor membutuhkan scene SVG 2D.');const id='nawGradient1';let c=replaceOccurrence(code,token,occurrence,`url(#${id})`);const stopCode=stops.map(s=>`h('stop',{offset:'${s.pos}%',stopColor:'${s.color}'})`).join(',');const grad=type==='radial'?`h('radialGradient',{id:'${id}'},${stopCode})`:`h('linearGradient',{id:'${id}',x1:'0%',y1:'0%',x2:'100%',y2:'0%',gradientTransform:'rotate(${angle} .5 .5)'},${stopCode})`;if(/h\(\s*['"]defs['"]\s*,\s*null\s*,/.test(c))return c.replace(/h\(\s*(['"])defs\1\s*,\s*null\s*,/,(m)=>m+grad+',');const svg=/h\(\s*(['"])svg\1\s*,\s*\{[\s\S]*?\}\s*,/m;if(!svg.test(c))throw new Error('Root SVG tidak ditemukan.');return c.replace(svg,m=>m+`h('defs',null,${grad}),`) }
function timestampName(){const d=new Date();const p=n=>String(n).padStart(2,'0');const ms=String(d.getMilliseconds()).padStart(3,'0');return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${ms}.mp4`}
function bitrateFor(res,fps){return Math.round((res>=2160?40000000:res>=1440?24000000:14000000)*(fps/30))}

function Preview({Scene,error,code,ratio,res,fps,dur,frame,setFrame,playing,setPlaying,busy,msg,fsSupported,fs,toggleFs,player,t}){const preview=useMemo(()=>size(ratio,720),[ratio]);const frames=Math.max(1,Math.round(dur*fps));return <><div className="stage rise" style={{'--i':1}}><div className="badge l"><span className="dot"/>{t('viewport')}</div><div className="badge r">{RES[res]} · {ratio}</div>{fsSupported&&<button className="fsbtn" onClick={toggleFs}>{fs?'⤡':'⛶'}</button>}{busy&&<div className="loading"><div className="spin"/><span>{msg}</span></div>}<div className="view" onClick={()=>player.current?.toggle()}>{Scene?<Boundary code={code}><Player ref={player} component={Scene} durationInFrames={frames} fps={fps} compositionWidth={preview.width} compositionHeight={preview.height} style={{width:'100%',height:'100%'}} loop autoPlay acknowledgeRemotionLicense/></Boundary>:<div className="err">Error kode: {error}</div>}</div></div><div className="timeline rise" style={{'--i':2}}><button className="play" onClick={()=>player.current?.toggle()}>{playing?'❚❚':'▶'}</button><span className="time">{(frame/fps).toFixed(2)}s</span><input type="range" min={0} max={frames-1} value={Math.min(frame,frames-1)} onChange={e=>{player.current?.pause();player.current?.seekTo(+e.target.value)}}/><span className="time d">{dur.toFixed(2)}s</span></div></>}

export default function App({t,onBack,themeIcon,toggleTheme,fs,fsSupported,toggleFs}){
 const [tab,setTab]=useState('studio'),[code,setCode]=useState(DEFAULT_2D),[draft,setDraft]=useState(DEFAULT_2D);
 const [baseCode,setBaseCode]=useState(()=>localStorage.getItem('naw_scene_base')||''),[sceneLocked,setSceneLocked]=useState(()=>localStorage.getItem('naw_scene_locked')==='1');
 const [ratio,setRatio]=useState('16:9'),[res,setRes]=useState(1080),[fps,setFps]=useState(30),[dur,setDur]=useState(10);
 const [msg,setMsg]=useState(''),[busy,setBusy]=useState(false),[prog,setProg]=useState(0),[frame,setFrame]=useState(0),[playing,setPlaying]=useState(true),[files,setFiles]=useState(loadFiles);
 const [palette,setPalette]=useState('Basic'),[selectedColor,setSelectedColor]=useState(null),[colorMode,setColorMode]=useState('solid'),[hsl,setHsl]=useState([0,100,50]),[alpha,setAlpha]=useState(100),[gradType,setGradType]=useState('linear'),[gradAngle,setGradAngle]=useState(135),[stops,setStops]=useState([{pos:0,color:'#00A8FF'},{pos:50,color:'#7C3AED'},{pos:100,color:'#FF0055'}]);
 const player=useRef(null);
 const {Scene,error}=useMemo(()=>{try{return{Scene:compile(code),error:''}}catch(e){return{Scene:null,error:e.message}}},[code]);const frames=Math.max(1,Math.round(dur*fps));const colors=useMemo(()=>colorTokens(code),[code]);
 useEffect(()=>saveFiles(files),[files]);useEffect(()=>{if(baseCode)localStorage.setItem('naw_scene_base',baseCode);else localStorage.removeItem('naw_scene_base')},[baseCode]);useEffect(()=>localStorage.setItem('naw_scene_locked',sceneLocked?'1':'0'),[sceneLocked]);
 useEffect(()=>{const pl=player.current;if(!pl)return;const f=e=>setFrame(e.detail.frame),a=()=>setPlaying(true),b=()=>setPlaying(false);pl.addEventListener('frameupdate',f);pl.addEventListener('play',a);pl.addEventListener('pause',b);return()=>{pl.removeEventListener('frameupdate',f);pl.removeEventListener('play',a);pl.removeEventListener('pause',b)}},[Scene,frames,tab]);
 const apply=c=>{setCode(c);setDraft(c)};const addFile=(name,c)=>setFiles(a=>a.some(f=>!f.trashed&&f.code===c)?a:[newFile(name,'2d',c),...a]);
 const baseFirst=()=>{if(!baseCode){setBaseCode(code);setSceneLocked(true);setMsg('Base scene locked locally.')}};
 const clearCode=()=>{setCode('');setDraft('');setMsg('Code deleted.');};
 const copyCode=async()=>{try{await navigator.clipboard.writeText(draft);setMsg(t('copied'))}catch{setMsg(t('pasteFail'))}};const pasteCode=async()=>{try{const x=await navigator.clipboard.readText();if(x)setDraft(x)}catch{setMsg(t('pasteFail'))}};
 const exportVideo=async()=>{if(!Scene)return setMsg(t('fixCode'));const {width,height}=size(ratio,res);const bitrate=bitrateFor(res,fps);const name=timestampName();setBusy(true);setProg(0);setMsg(t('preparing'));try{const {getBlob}=await renderMediaOnWeb({composition:{id:'scene',component:Scene,durationInFrames:frames,fps,width,height},container:'mp4',videoCodec:'h264',videoBitrate:bitrate,muted:true,keyframeIntervalInSeconds:2,licenseKey:'free-license',onProgress:p=>{const rendered=Number(p.renderedFrames||0);setProg(Math.min(0.98,rendered/frames));setMsg(`Render frame ${rendered}/${frames} (encode ${Number(p.encodedFrames||0)})`)}});const blob=await getBlob();setMsg('Saving video to Gallery…');const totalBytes=blob.size;await NativeMedia.startVideoSave({displayName:name,mimeType:'video/mp4'});try{const buffer=await blob.arrayBuffer();const bytes=new Uint8Array(buffer);const CHUNK_SIZE=256*1024;for(let offset=0;offset<bytes.length;offset+=CHUNK_SIZE){const endOffset=Math.min(offset+CHUNK_SIZE,bytes.length);const chunk=bytes.subarray(offset,endOffset);let binary='';const sub=0x8000;for(let i=0;i<chunk.length;i+=sub)binary+=String.fromCharCode(...chunk.subarray(i,Math.min(i+sub,chunk.length)));await NativeMedia.writeVideoChunk({base64:btoa(binary)});setProg(0.98+(endOffset/bytes.length)*0.02);setMsg(`Saving video to Gallery… ${Math.round((endOffset/bytes.length)*100)}%`)}await NativeMedia.finishVideoSave()}catch(saveError){try{await NativeMedia.abortVideoSave()}catch{}throw saveError}setProg(1);setMsg(`${t('saved')}: ${name} · ${(totalBytes/1048576).toFixed(1)} MB`)}catch(e){console.error(e);setMsg('Error: '+(e?.message||e)+' — coba turunkan resolusi/fps.')}finally{setBusy(false)}};

 const selectColor=(token,occurrence,index)=>{setSelectedColor({token,occurrence,index});setColorMode('solid');setHsl(hexToHsl(token))};const applySolid=()=>{if(!selectedColor)return;const css=hslToCss(...hsl,alpha),next=replaceOccurrence(code,selectedColor.token,selectedColor.occurrence,css);apply(next);addFile(`Color edit ${css}`,next);setMsg('Color applied.')};const applyGradient=()=>{if(!selectedColor)return;try{const next=addGradient(code,selectedColor.token,selectedColor.occurrence,stops,gradAngle,gradType);apply(next);addFile('Gradient edit',next);setMsg('Gradient applied.')}catch(e){setMsg(e.message)}};
 const previewProps={Scene,error,code,ratio,res,fps,dur,frame,setFrame,playing,setPlaying,busy,msg,fsSupported,fs,toggleFs,player,t};
 return <div className="app"><div className="top"><div className="head rise" style={{'--i':0}}><button className="logo" onClick={onBack} aria-label="Home"><img src="/logo.png" alt="NAW Studio"/></button><div className="brand"><b>NAW <span>STUDIO</span></b><small>{t('tagShort')}</small></div><button className="iconbtn" onClick={toggleTheme} aria-label="Theme">{themeIcon}</button></div></div>
 {tab==='studio'&&<Preview {...previewProps}/>} 
 <div className="body"><div key={tab} className="pane">
 {tab==='studio'&&<>
  <div className="card"><div className="row"><div className="title"><i>✦</i> Scene · 2D</div><button className="link" onClick={()=>apply(DEFAULT_2D)}>{t('reset')}</button></div><div className="row"><div><strong>🔒 {t('sceneLocked')}</strong><div className="msg">{t('baseHint')}</div></div>{baseCode&&<button className="btn o" onClick={()=>apply(baseCode)}>{t('restore')}</button>}</div><div className="btns"><button className="btn" onClick={baseFirst}>Set Current as Base</button></div></div>
  <div className="card"><div className="row"><div className="title"><i>▣</i> {t('codeEdit')}</div><div className="ctools" style={{marginTop:0}}><button onClick={copyCode}>{t('copyAll')}</button><button onClick={pasteCode}>{t('paste')}</button></div></div><textarea className="code" rows={12} spellCheck={false} value={draft} onChange={e=>setDraft(e.target.value)}/><div className="btns"><button className="btn" onClick={()=>{apply(draft);if(!baseCode)baseFirst()}}>{t('applyCode')}</button><button className="btn o" onClick={()=>setDraft(code)}>{t('cancel')}</button><button className="btn dng" onClick={clearCode}>{t('deleteCode')}</button></div></div>
  <div className="card"><div className="row"><div className="title"><i>🎬</i> {t('render')}</div><div className="badge-static">{busy?'ACTIVE':'READY'}</div></div><div className="grid"><Opt label={t('res')}><select value={res} onChange={e=>setRes(+e.target.value)}><option value={1080}>1080p</option><option value={1440}>2K</option><option value={2160}>4K</option></select></Opt><Opt label={t('ratio')}><select value={ratio} onChange={e=>setRatio(e.target.value)}>{Object.keys(RATIOS).map(r=><option key={r}>{r}</option>)}</select></Opt><Opt label={t('fps')}><select value={fps} onChange={e=>setFps(+e.target.value)}><option value={24}>24 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></Opt><Opt label={t('dur')}><select value={dur} onChange={e=>setDur(+e.target.value)}><option value={5}>5 {t('sec')}</option><option value={8}>8 {t('sec')}</option><option value={10}>10 {t('sec')}</option><option value={15}>15 {t('sec')}</option></select></Opt></div><p className="msg">H.264 browser rendering. Resize is a separate tool and does not affect Studio rendering.</p><button className="btn big" disabled={busy} onClick={exportVideo}>{busy?t('rendering'):t('export')}</button>{(busy||prog>0)&&<div className="bar"><i style={{width:Math.round(prog*100)+'%'}}/></div>}<p className="msg">{msg}</p></div>
 </>}
 {tab==='editor'&&<><div className="editor-sticky"><Preview {...previewProps}/></div><div className="card"><div className="row"><div className="title"><i>🎨</i> {t('colorEditor')}</div><div className="seg mini" style={{margin:0}}><button className={colorMode==='solid'?'on':''} onClick={()=>setColorMode('solid')}>{t('solid')}</button><button className={colorMode==='gradient'?'on':''} onClick={()=>setColorMode('gradient')}>{t('gradient')}</button></div></div><div className="msg">{selectedColor?`${t('target')}: ${selectedColor.token} · occurrence ${selectedColor.occurrence}`:t('noColor')}</div><div className="palette-title">{t('palette')}</div><div className="swatches">{PALETTES[palette].map(c=><button key={c} className="swatch" style={{background:c}} aria-label={c} onClick={()=>{setHsl(hexToHsl(c));setAlpha(100)}}/>)}</div><div className="seg mini"><button className={palette==='Basic'?'on':''} onClick={()=>setPalette('Basic')}>Basic</button><button className={palette==='Pastel'?'on':''} onClick={()=>setPalette('Pastel')}>Pastel</button><button className={palette==='Neon'?'on':''} onClick={()=>setPalette('Neon')}>Neon</button><button className={palette==='Cinematic'?'on':''} onClick={()=>setPalette('Cinematic')}>Cine</button><button className={palette==='Medical'?'on':''} onClick={()=>setPalette('Medical')}>Medical</button></div><div className="color-list">{colors.map((c,i)=><button key={`${c.index}-${i}`} className={'color-row '+(selectedColor?.index===c.index?'on':'')} onClick={()=>selectColor(c.value,c.occurrence,c.index)}><span className="color-dot" style={{background:c.value}}/><span>{c.value}</span><small>#{c.occurrence}</small></button>)}</div>{selectedColor&&colorMode==='solid'&&<><div className="slider-row"><label>{t('hue')}</label><input type="range" min="0" max="360" value={hsl[0]} onChange={e=>setHsl([+e.target.value,hsl[1],hsl[2]])}/><b>{hsl[0]}°</b></div><div className="slider-row"><label>{t('sat')}</label><input type="range" min="0" max="100" value={hsl[1]} onChange={e=>setHsl([hsl[0],+e.target.value,hsl[2]])}/><b>{hsl[1]}%</b></div><div className="slider-row"><label>{t('light')}</label><input type="range" min="0" max="100" value={hsl[2]} onChange={e=>setHsl([hsl[0],hsl[1],+e.target.value])}/><b>{hsl[2]}%</b></div><div className="slider-row"><label>{t('alpha')}</label><input type="range" min="0" max="100" value={alpha} onChange={e=>setAlpha(+e.target.value)}/><b>{alpha}%</b></div><div className="color-preview" style={{background:hslToCss(...hsl,alpha)}}><code>{hslToCss(...hsl,alpha)}</code></div><button className="btn big" onClick={applySolid}>{t('apply')}</button></>}{selectedColor&&colorMode==='gradient'&&<><div className="grid"><Opt label={t('gradientType')}><select value={gradType} onChange={e=>setGradType(e.target.value)}><option value="linear">{t('linear')}</option><option value="radial">{t('radial')}</option></select></Opt><Opt label={t('angle')}><input type="number" min="0" max="360" value={gradAngle} onChange={e=>setGradAngle(+e.target.value)}/></Opt></div><div className="gradient-preview" style={{background:gradType==='radial'?`radial-gradient(circle,${stops.map(s=>s.color+' '+s.pos+'%').join(',')})`:`linear-gradient(${gradAngle}deg,${stops.map(s=>s.color+' '+s.pos+'%').join(',')})`}}/><div className="stops">{stops.map((s,i)=><div className="stop-row" key={i}><input type="color" value={s.color} onChange={e=>setStops(p=>p.map((x,j)=>j===i?{...x,color:e.target.value}:x))}/><input type="range" min="0" max="100" value={s.pos} onChange={e=>setStops(p=>p.map((x,j)=>j===i?{...x,pos:+e.target.value}:x))}/><b>{s.pos}%</b>{stops.length>2&&<button className="link" onClick={()=>setStops(p=>p.filter((_,j)=>j!==i))}>×</button>}</div>)}<button className="btn o" onClick={()=>setStops(p=>[...p,{pos:50,color:'#ffffff'}])}>{t('addStop')}</button></div><button className="btn big" onClick={applyGradient}>{t('apply')}</button><p className="msg">{t('gradient2d')}</p></>}</div></>}
 {tab==='resize'&&<ResizePanel t={t} busy={busy} setBusy={setBusy} setMsg={setMsg} msg={msg} prog={prog} setProg={setProg}/>}
 </div></div><nav className="tabbar">{[['studio','tabStudio'],['editor','tabEditor'],['resize','tabResize']].map(([k,l])=><button key={k} className={'tab '+(tab===k?'on':'')} onClick={()=>setTab(k)}><Ico n={k}/><span>{t(l)}</span></button>)}</nav></div>
}

function ResizePanel({t,busy,setBusy,setMsg,msg,prog,setProg}){
 const [items,setItems]=useState([]),[target,setTarget]=useState(50),[custom,setCustom]=useState(''),[localBusy,setLocalBusy]=useState(false);
 const inputRef=useRef(null);
 const choose=e=>{const incoming=Array.from(e.target.files||[]).filter(f=>/^video\//.test(f.type)||/\.mp4$/i.test(f.name));setItems(p=>[...p,...incoming.map(file=>({file,id:`${file.name}-${file.size}-${file.lastModified}-${Math.random()}`,status:'ready',out:null,error:null}))]);e.target.value=''};
 const remove=id=>setItems(p=>p.filter(x=>x.id!==id));
 const targetMb=Math.max(1,Number(custom)||Number(target)||50);
 const formatMb=n=>(n/1000000).toFixed(1)+' MB';
 const saveBlobToGallery=async(blob,name,onProgress)=>{
   await NativeMedia.startVideoSave({displayName:name,mimeType:'video/mp4'});
   try{
     const bytes=new Uint8Array(await blob.arrayBuffer()),CHUNK_SIZE=256*1024;
     for(let offset=0;offset<bytes.length;offset+=CHUNK_SIZE){
       const end=Math.min(offset+CHUNK_SIZE,bytes.length),chunk=bytes.subarray(offset,end);let binary='';
       for(let i=0;i<chunk.length;i+=0x8000)binary+=String.fromCharCode(...chunk.subarray(i,Math.min(i+0x8000,chunk.length)));
       await NativeMedia.writeVideoChunk({base64:btoa(binary)});onProgress?.(end/bytes.length);
     }
     await NativeMedia.finishVideoSave();
   }catch(e){try{await NativeMedia.abortVideoSave()}catch{}throw e}
 };
 const processOne=async item=>{
   const input=new Input({formats:ALL_FORMATS,source:new BlobSource(item.file)});
   try{
     const videoTrack=await input.getPrimaryVideoTrack();
     if(!videoTrack)throw new Error('No video track found.');
     const duration=await input.computeDuration();
     if(!isFinite(duration)||duration<=0)throw new Error('Invalid video duration.');
     if(item.file.size>=targetMb*1000000)throw new Error(`Target ${targetMb} MB must be larger than the original ${formatMb(item.file.size)}.`);
     const width=await videoTrack.getDisplayWidth(),height=await videoTrack.getDisplayHeight();
     const fpsMetrics=await videoTrack.computeFrameRateMetrics();
     const fps=Math.max(1,Math.min(120,Number(fpsMetrics?.bestGuessFrameRate||30)));
     const audioTrack=await input.getPrimaryAudioTrack();
     const audioBitrate=audioTrack?Number(await audioTrack.getAverageBitrate()||128000):0;
     const targetBits=targetMb*1000000*8;
     // Reserve the original audio budget plus a small MP4/container margin.
     let bitrate=Math.floor((targetBits/duration-audioBitrate)*0.975);
     bitrate=Math.max(300000,bitrate);
     const encodable=await canEncodeVideo('avc',{width,height,frameRate:fps,bitrate,hardwareAcceleration:'no-preference'});
     if(!encodable)throw new Error(`4K H.264 encoder is not available in this browser/device for ${width}×${height} @ ${fps.toFixed(2)} fps.`);
     const output=new Output({format:new Mp4OutputFormat({fastStart:'in-memory'}),target:new BufferTarget()});
     const conversion=await Conversion.init({
       input,output,tracks:'all',
       video:{codec:'avc',bitrate,bitrateMode:'constant',forceTranscode:true,hardwareAcceleration:'no-preference',keyFrameInterval:1},
       audio:{},
     });
     if(!conversion.isValid){
       const reasons=(conversion.discardedTracks||[]).map(x=>x.reason).filter(Boolean).join('; ');
       throw new Error(reasons||'This video cannot be converted to H.264 MP4 in this environment.');
     }
     conversion.onProgress=(p,processedTime)=>{
       setProg(Math.min(0.96,Math.max(0,p)));
       setMsg(`${t('resizing')} ${item.file.name}: ${Math.round(p*100)}% · ${width}×${height} · ${fps.toFixed(2)} fps · CBR ${Math.round(bitrate/1000000)} Mbps`);
     };
     await conversion.execute();
     await output.finalize();
     const buffer=output.target.buffer;if(!buffer)throw new Error('Resize produced no MP4 output.');
     const blob=new Blob([buffer],{type:'video/mp4'});
     const name=`${item.file.name.replace(/\.[^.]+$/,'')}_resize_${targetMb}MB.mp4`;
     setMsg(`${t('resizing')} ${item.file.name}: saving to Gallery…`);
     await saveBlobToGallery(blob,name,p=>setProg(0.96+p*0.04));
     return {name,bytes:blob.size,uri:''};
   }finally{input.dispose()}
 };
 const processAll=async()=>{if(!items.length||localBusy)return;setLocalBusy(true);setBusy(true);setProg(0);setMsg('Preparing resize…');for(let idx=0;idx<items.length;idx++){const item=items[idx];setItems(p=>p.map(x=>x.id===item.id?{...x,status:'processing'}:x));try{const out=await processOne(item);setItems(p=>p.map(x=>x.id===item.id?{...x,status:'done',out,error:null}:x))}catch(e){console.error(e);setItems(p=>p.map(x=>x.id===item.id?{...x,status:'error',error:e?.message||String(e)}:x))}}setProg(1);setMsg('Resize complete.');setBusy(false);setLocalBusy(false)};
 return <>
   <div className="card"><div className="row"><div className="title"><i>↗</i> {t('resizeTitle')}</div><span className="badge-static">MP4</span></div><p className="msg">Upload one or multiple MP4 videos, then increase file size without changing resolution, FPS or duration.</p><input ref={inputRef} className="hidden-file" type="file" accept="video/mp4,video/*" multiple onChange={choose}/><button className="btn big" disabled={busy} onClick={()=>inputRef.current?.click()}>＋ {t('addVideos')}</button></div>
   <div className="card"><div className="row"><div className="title"><i>▣</i> {t('targetSize')}</div><span className="value-right">{targetMb} MB</span></div><div className="seg mini"><button className={!custom&&target===20?'on':''} onClick={()=>{setCustom('');setTarget(20)}}>20 MB</button><button className={!custom&&target===50?'on':''} onClick={()=>{setCustom('');setTarget(50)}}>50 MB</button><button className={!custom&&target===100?'on':''} onClick={()=>{setCustom('');setTarget(100)}}>100 MB</button><button className={!custom&&target===200?'on':''} onClick={()=>{setCustom('');setTarget(200)}}>200 MB</button></div><div className="opt resize-custom"><label>{t('customMB')}</label><input type="number" min="1" step="1" value={custom} placeholder="50" onChange={e=>setCustom(e.target.value)}/></div><p className="msg">The output keeps the source resolution, frame rate, duration and aspect ratio. H.264 bitrate is changed; audio is preserved when supported.</p></div>
   <div className="card"><div className="row"><div className="title"><i>▤</i> {t('selectedVideos')} ({items.length})</div>{items.length>0&&<button className="link" disabled={busy} onClick={()=>setItems([])}>{t('clearAll')}</button>}</div>{items.length?items.map(x=><div className="resize-file" key={x.id}><div className="resize-icon">MP4</div><div className="resize-info"><b>{x.file.name}</b><small>{formatMb(x.file.size)}{x.status==='done'&&x.out?` → ${formatMb(x.out.bytes)}`:''}</small>{x.status==='processing'&&<span className="resize-status">{t('processing')}</span>}{x.status==='done'&&<span className="resize-status done">✓ {t('complete')}</span>}{x.status==='error'&&<span className="resize-status error">{x.error}</span>}</div><button className="link resize-remove" disabled={busy} onClick={()=>remove(x.id)}>×</button></div>):<div className="empty">{t('noVideos')}</div>}<button className="btn big" disabled={busy||!items.length} onClick={processAll}>{busy?t('resizingAll'):t('processAll')}</button>{(busy||prog>0)&&<div className="bar"><i style={{width:Math.round(prog*100)+'%'}}/></div>}<p className="msg">{msg}</p></div>
 </>;
}
function FilesPanel({t,files,setFiles,onOpen}){const [sub,setSub]=useState('gen');const [q,setQ]=useState('');const gen=files.filter(f=>!f.trashed),trash=files.filter(f=>f.trashed),list=(sub==='gen'?gen:trash).filter(f=>!q||String(f.name||'').toLowerCase().includes(q.toLowerCase()));const upd=(id,p)=>setFiles(a=>a.map(f=>f.id===id?{...f,...p}:f));const del=id=>setFiles(a=>a.filter(f=>f.id!==id));const rename=f=>{const n=window.prompt(t('renamePrompt'),f.name);if(n&&n.trim())upd(f.id,{name:n.trim().slice(0,60)})};return <div className="card" style={{marginTop:0}}><div className="seg" style={{marginTop:4}}><button className={sub==='gen'?'on':''} onClick={()=>setSub('gen')}>📁 {t('filesGen')} ({gen.length})</button><button className={sub==='trash'?'on':''} onClick={()=>setSub('trash')}>🗑 {t('filesTrash')} ({trash.length})</button></div>{sub==='trash'&&<p className="msg">{t('trashNote')}</p>}<input className="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search scenes..."/>{list.length?list.map(f=><div className="file" key={f.id}><div className="thumb m2d"><span>2D</span></div><div className="finfo"><b>{f.name}</b><small>{new Date(f.ts).toLocaleDateString()} · 2D</small><div className="facts">{sub==='gen'?<><button onClick={()=>onOpen(f)}>{t('open')}</button><button onClick={()=>rename(f)}>{t('rename')}</button><button className="dng" onClick={()=>upd(f.id,{trashed:true,trashedAt:Date.now()})}>{t('del')}</button></>:<><button onClick={()=>upd(f.id,{trashed:false,trashedAt:null})}>{t('restore')}</button><button className="dng" onClick={()=>del(f.id)}>{t('delForever')}</button></>}</div></div></div>):<div className="empty">{sub==='gen'?t('emptyGen'):t('emptyTrash')}</div>}</div>}
