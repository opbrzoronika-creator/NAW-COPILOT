# NAW STUDIO v22.3.0

## Changes
- Removed the Resize tab completely. The app now has exactly two tabs: Studio and Edit Warna.
- Studio codec choices: H.264 MP4 and ProRes MOV 422 LT.
- H.264 uses the working browser `renderMediaOnWeb()` path.
- ProRes renders a high-bitrate H.264 intermediate, transfers it to the native Android renderer, and encodes it with FFmpeg `prores_ks` to ProRes 422 LT.
- ProRes output is MOV and saved to `Movies/NAW STUDIO`.
- The ProRes path uses 80 Mbps UHD/4K source bitrate (scaled by FPS) to reduce quality loss before the ProRes conversion.
- No AI/API key is required.
- Scene Lock remains; Unlock remains removed.

## Adobe Stock context
Adobe Stock currently recommends ProRes or H.264 for video submissions. Native resolution and frame rate should be preserved.

## Alpha Background
- Render > Background > Transparent / Alpha enables a transparent VP9/WebM intermediate with alpha preserved.
- The Android native render plugin then converts that transparent source to ProRes 4444 MOV (`yuva444p10le`).
- H.264 remains unchanged and is disabled automatically while Transparent / Alpha is selected.
- The scene code itself must not paint an opaque full-canvas background; the renderer does not chroma-key or erase colors after rendering.
